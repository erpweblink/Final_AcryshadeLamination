-- Structure for table [DB_AcryshadeLaminatesTestAWS].[dbo].[AUTH_TOKEN_MASTER]
SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
CREATE TABLE [dbo].[AUTH_TOKEN_MASTER](
	[ID] [bigint] IDENTITY(1,1) NOT NULL,
	[UserName] [nvarchar](max) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[TokenExpiry] [datetime] NOT NULL,
	[Sek] [nvarchar](max) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[ClientId] [nvarchar](max) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[AuthToken] [nvarchar](max) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
 CONSTRAINT [PK_AUTH_TOKEN_MASTER] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]


-- Data for table [DB_AcryshadeLaminatesTestAWS].[dbo].[AUTH_TOKEN_MASTER]
SET IDENTITY_INSERT dbo.AUTH_TOKEN_MASTER ON;

INSERT INTO dbo.AUTH_TOKEN_MASTER (ID, UserName, TokenExpiry, Sek, ClientId, AuthToken) VALUES (10011, 'API_WLSPL', '7/22/2026 10:33:17 PM', 'CC5REB8n1hpVN9tS5g5h0Db4quVnEL5V6gvZjbymof3yYruRYyRKeva7wAPkTscv', 'TERAS67GSPNMFGP', '1czlPt9tvMzPsl3Vf9OUk2fdH');

SET IDENTITY_INSERT dbo.AUTH_TOKEN_MASTER OFF;


-- Structure for table [DB_AcryshadeLaminatesTestAWS].[dbo].[tbl_AssignedMachines]
SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
CREATE TABLE [dbo].[tbl_AssignedMachines](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[MachineID] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[OperatorID] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[FromDate] [date] NULL,
	[ToDate] [date] NULL,
	[FromTime] [time](0) NULL,
	[ToTime] [time](0) NULL,
	[CreatedBy] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[CreatedOn] [datetime] NULL,
	[IsDeleted] [bit] NULL,
	[DeletedBy] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[DeletedOn] [datetime] NULL,
PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]


-- Data for table [DB_AcryshadeLaminatesTestAWS].[dbo].[tbl_AssignedMachines]
SET IDENTITY_INSERT dbo.tbl_AssignedMachines ON;

INSERT INTO dbo.tbl_AssignedMachines (ID, MachineID, OperatorID, FromDate, ToDate, FromTime, ToTime, CreatedBy, CreatedOn, IsDeleted, DeletedBy, DeletedOn) VALUES (1, '1', '309', '7/13/2026 12:00:00 AM', '7/31/2026 12:00:00 AM', 09:00:00, 21:00:00, '1', '7/13/2026 2:17:07 PM', 0, NULL, NULL);
INSERT INTO dbo.tbl_AssignedMachines (ID, MachineID, OperatorID, FromDate, ToDate, FromTime, ToTime, CreatedBy, CreatedOn, IsDeleted, DeletedBy, DeletedOn) VALUES (2, '2', '310', '7/13/2026 12:00:00 AM', '7/31/2026 12:00:00 AM', 09:00:00, 21:00:00, '1', '7/13/2026 2:17:38 PM', 0, NULL, NULL);
INSERT INTO dbo.tbl_AssignedMachines (ID, MachineID, OperatorID, FromDate, ToDate, FromTime, ToTime, CreatedBy, CreatedOn, IsDeleted, DeletedBy, DeletedOn) VALUES (3, '3', '311', '7/13/2026 12:00:00 AM', '7/31/2026 12:00:00 AM', 09:00:00, 21:00:00, '1', '7/13/2026 2:18:00 PM', 0, NULL, NULL);

SET IDENTITY_INSERT dbo.tbl_AssignedMachines OFF;


-- Structure for table [DB_AcryshadeLaminatesTestAWS].[dbo].[tbl_AuthPages]
SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
CREATE TABLE [dbo].[tbl_AuthPages](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[MenuName] [nvarchar](max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[PageName] [nvarchar](max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]


-- Data for table [DB_AcryshadeLaminatesTestAWS].[dbo].[tbl_AuthPages]
SET IDENTITY_INSERT dbo.tbl_AuthPages ON;

INSERT INTO dbo.tbl_AuthPages (ID, MenuName, PageName) VALUES (1, 'Dashboard', 'Dashboard.aspx');
INSERT INTO dbo.tbl_AuthPages (ID, MenuName, PageName) VALUES (2, 'Roles', 'RoleMaster.aspx');
INSERT INTO dbo.tbl_AuthPages (ID, MenuName, PageName) VALUES (3, 'Users', 'UserList.aspx');
INSERT INTO dbo.tbl_AuthPages (ID, MenuName, PageName) VALUES (4, 'Dealers', 'DealerList.aspx');
INSERT INTO dbo.tbl_AuthPages (ID, MenuName, PageName) VALUES (5, 'Sub Dealers', 'CompanyList.aspx');
INSERT INTO dbo.tbl_AuthPages (ID, MenuName, PageName) VALUES (6, 'Stages', 'StageList.aspx');
INSERT INTO dbo.tbl_AuthPages (ID, MenuName, PageName) VALUES (7, 'Machine', 'MachineList.aspx');
INSERT INTO dbo.tbl_AuthPages (ID, MenuName, PageName) VALUES (8, 'Raw Material', 'RawMaterialList.aspx');
INSERT INTO dbo.tbl_AuthPages (ID, MenuName, PageName) VALUES (9, 'Products', 'ProductList.aspx');
INSERT INTO dbo.tbl_AuthPages (ID, MenuName, PageName) VALUES (10, 'Transporter', 'TransporterList.aspx');
INSERT INTO dbo.tbl_AuthPages (ID, MenuName, PageName) VALUES (11, 'Work Order', 'WorkOrderList.aspx');
INSERT INTO dbo.tbl_AuthPages (ID, MenuName, PageName) VALUES (12, 'Place Order', 'PlaceOrder.aspx');
INSERT INTO dbo.tbl_AuthPages (ID, MenuName, PageName) VALUES (13, 'Assign Machine', 'AssignMachine.aspx');
INSERT INTO dbo.tbl_AuthPages (ID, MenuName, PageName) VALUES (14, 'Approve Designs', 'WorkOrdrForDesign.aspx');
INSERT INTO dbo.tbl_AuthPages (ID, MenuName, PageName) VALUES (15, 'Start Production', 'AssignWorkOrder.aspx');
INSERT INTO dbo.tbl_AuthPages (ID, MenuName, PageName) VALUES (16, 'Production Stage 1', 'WoProductionS1.aspx');
INSERT INTO dbo.tbl_AuthPages (ID, MenuName, PageName) VALUES (17, 'Production Stage 2', 'WoProductionS2.aspx');
INSERT INTO dbo.tbl_AuthPages (ID, MenuName, PageName) VALUES (18, 'Packaging', 'Packaging.aspx');
INSERT INTO dbo.tbl_AuthPages (ID, MenuName, PageName) VALUES (19, 'User Authorization', 'UserAuthorization.aspx');
INSERT INTO dbo.tbl_AuthPages (ID, MenuName, PageName) VALUES (21, 'Delivery Page', 'Delivery.aspx');
INSERT INTO dbo.tbl_AuthPages (ID, MenuName, PageName) VALUES (22, 'Production Reports', 'ProductionReport.aspx');
INSERT INTO dbo.tbl_AuthPages (ID, MenuName, PageName) VALUES (23, 'Machine Break Down', 'MachineBreakdown.aspx');
INSERT INTO dbo.tbl_AuthPages (ID, MenuName, PageName) VALUES (24, 'Trending Product Reports', 'TrendingReports.aspx');

SET IDENTITY_INSERT dbo.tbl_AuthPages OFF;


-- Structure for table [DB_AcryshadeLaminatesTestAWS].[dbo].[tbl_CompanyContactDtls]
SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
CREATE TABLE [dbo].[tbl_CompanyContactDtls](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[HeaderID] [nvarchar](20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[FName] [nvarchar](200) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[MobileNo] [nvarchar](15) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[EmialID] [nvarchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Department] [nvarchar](200) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Designation] [nvarchar](200) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]


-- Data for table [DB_AcryshadeLaminatesTestAWS].[dbo].[tbl_CompanyContactDtls]
SET IDENTITY_INSERT dbo.tbl_CompanyContactDtls ON;

INSERT INTO dbo.tbl_CompanyContactDtls (ID, HeaderID, FName, MobileNo, EmialID, Department, Designation) VALUES (3, '1', 'Mrugesh', '8765432100', 'murgesh@gmail.com', 'Admin', 'CEO');

SET IDENTITY_INSERT dbo.tbl_CompanyContactDtls OFF;


-- Structure for table [DB_AcryshadeLaminatesTestAWS].[dbo].[tbl_CompanyDetails]
SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
CREATE TABLE [dbo].[tbl_CompanyDetails](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[HeaderID] [nvarchar](20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[BillAddress] [nvarchar](max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[BillArea] [nvarchar](max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[BillPinCode] [nvarchar](25) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[BillCity] [nvarchar](200) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[BillState] [nvarchar](200) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[BillCountry] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[BillGSTNo] [nvarchar](500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[ShipAddress] [nvarchar](max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[ShipArea] [nvarchar](max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[ShipPinCode] [nvarchar](25) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[ShipCity] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[ShipState] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[ShipCountry] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[ShipGSTNo] [nvarchar](500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
 CONSTRAINT [PK__tbl_Comp__3214EC278DED5DF9] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]


-- Data for table [DB_AcryshadeLaminatesTestAWS].[dbo].[tbl_CompanyDetails]
SET IDENTITY_INSERT dbo.tbl_CompanyDetails ON;

INSERT INTO dbo.tbl_CompanyDetails (ID, HeaderID, BillAddress, BillArea, BillPinCode, BillCity, BillState, BillCountry, BillGSTNo, ShipAddress, ShipArea, ShipPinCode, ShipCity, ShipState, ShipCountry, ShipGSTNo) VALUES (4, '1', 'Plot No. 144-A, Gate No. 2, Sector 7, PCNTDA, MIDC, Bhosari, Pune - 411026, MH, India', 'Bhosari I.E., Indrayaninagar', '411026', 'Pune', 'Maharashtra', 'India', '', 'Plot No. 144-A, Gate No. 2, Sector 7, PCNTDA, MIDC, Bhosari, Pune - 411026, MH, India', 'Bhosari I.E., Indrayaninagar', '411026', 'Pune', 'Maharashtra', 'India', '27AAUFK6791L1Z9');
INSERT INTO dbo.tbl_CompanyDetails (ID, HeaderID, BillAddress, BillArea, BillPinCode, BillCity, BillState, BillCountry, BillGSTNo, ShipAddress, ShipArea, ShipPinCode, ShipCity, ShipState, ShipCountry, ShipGSTNo) VALUES (5, '1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Hinjewadi Phase 1', 'Infotech  Park (Hinjawadi), Marunji, Wakad', '411057', 'Pune', 'Maharashtra', 'India', '');
INSERT INTO dbo.tbl_CompanyDetails (ID, HeaderID, BillAddress, BillArea, BillPinCode, BillCity, BillState, BillCountry, BillGSTNo, ShipAddress, ShipArea, ShipPinCode, ShipCity, ShipState, ShipCountry, ShipGSTNo) VALUES (6, '2', 'sdfsdfsdf', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO dbo.tbl_CompanyDetails (ID, HeaderID, BillAddress, BillArea, BillPinCode, BillCity, BillState, BillCountry, BillGSTNo, ShipAddress, ShipArea, ShipPinCode, ShipCity, ShipState, ShipCountry, ShipGSTNo) VALUES (8, '3', 'sadsadsadsadsads', '', '', '', '', '', '', '', '', '', '', '', '', '');

SET IDENTITY_INSERT dbo.tbl_CompanyDetails OFF;


-- Structure for table [DB_AcryshadeLaminatesTestAWS].[dbo].[tbl_CompanyMain]
SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
CREATE TABLE [dbo].[tbl_CompanyMain](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[CompanyCode] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[CompanyName] [nvarchar](500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[OwnerName] [nvarchar](500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[CompanyOrigin] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[CompanyEmialId] [nvarchar](200) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[CompanyPanCard] [nvarchar](20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[PaymentTerms] [nvarchar](1000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[UDYAMNo] [nvarchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[CINNo] [nvarchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[WebsiteLink] [nvarchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[IsDeleted] [bit] NULL,
	[CreatedBy] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[CreatedOn] [datetime] NULL,
	[UpdatedBy] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[UpdatedOn] [datetime] NULL,
 CONSTRAINT [PK__tbl_Comp__3214EC27D03F1F2E] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]


-- Data for table [DB_AcryshadeLaminatesTestAWS].[dbo].[tbl_CompanyMain]
SET IDENTITY_INSERT dbo.tbl_CompanyMain ON;

INSERT INTO dbo.tbl_CompanyMain (ID, CompanyCode, CompanyName, OwnerName, CompanyOrigin, CompanyEmialId, CompanyPanCard, PaymentTerms, UDYAMNo, CINNo, WebsiteLink, IsDeleted, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn) VALUES (1, '2026-27/001', 'Key Automation', 'Mrugesh', 'Domestic', '', '', '30 days', '', NULL, '', 0, '1', '7/1/2026 10:27:27 AM', '1', '7/1/2026 10:28:19 AM');
INSERT INTO dbo.tbl_CompanyMain (ID, CompanyCode, CompanyName, OwnerName, CompanyOrigin, CompanyEmialId, CompanyPanCard, PaymentTerms, UDYAMNo, CINNo, WebsiteLink, IsDeleted, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn) VALUES (2, '2026-27/002', 'dsfdsfsdf', 'sdfdsf', 'Domestic', '', '', '', '', NULL, '', 1, '1', '7/17/2026 2:10:58 PM', NULL, NULL);
INSERT INTO dbo.tbl_CompanyMain (ID, CompanyCode, CompanyName, OwnerName, CompanyOrigin, CompanyEmialId, CompanyPanCard, PaymentTerms, UDYAMNo, CINNo, WebsiteLink, IsDeleted, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn) VALUES (3, '2026-27/003', 'asdsdassa', 'sadasdsadsasa', 'Domestic', '', '', '', '', NULL, '', 1, '1', '7/17/2026 4:13:15 PM', '1', '7/17/2026 4:13:57 PM');

SET IDENTITY_INSERT dbo.tbl_CompanyMain OFF;


-- Structure for table [DB_AcryshadeLaminatesTestAWS].[dbo].[tbl_DealersOrderDTLs]
SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
CREATE TABLE [dbo].[tbl_DealersOrderDTLs](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[HeaderID] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[ProductID] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[ProductName] [nvarchar](max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[ProductType] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Size] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Qty] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[ProductNote] [nvarchar](max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[ImagePathName] [nvarchar](max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]


-- Data for table [DB_AcryshadeLaminatesTestAWS].[dbo].[tbl_DealersOrderDTLs]
SET IDENTITY_INSERT dbo.tbl_DealersOrderDTLs ON;

INSERT INTO dbo.tbl_DealersOrderDTLs (ID, HeaderID, ProductID, ProductName, ProductType, Size, Qty, ProductNote, ImagePathName) VALUES (1, '1', '81', 'AS HD 044(A) Textura Sheet', 'Regular', '8x4', '10', 'Regular-N/A', '~/MyProducts/f8cf0809-c424-4a6c-85b1-b59da9261ff8_AS HD 044A.jpg');
INSERT INTO dbo.tbl_DealersOrderDTLs (ID, HeaderID, ProductID, ProductName, ProductType, Size, Qty, ProductNote, ImagePathName) VALUES (2, '2', '24', 'AS HD 012(B) Textura Sheet', 'Regular', '8x2', '20', 'Regular-N/A', '~/MyProducts/7ff1382c-ea61-47b8-bfb0-342d7fed7e10_AS HD 012B.jpg');
INSERT INTO dbo.tbl_DealersOrderDTLs (ID, HeaderID, ProductID, ProductName, ProductType, Size, Qty, ProductNote, ImagePathName) VALUES (3, '2', '77', 'AS HD 042(A) Textura Sheet', 'Custom', '8x2', '30', 'Size change', '~/MyProducts/3dc5fcd9-bc3d-4829-ac03-b97687ec8b8d_AS HD 042A.jpg');
INSERT INTO dbo.tbl_DealersOrderDTLs (ID, HeaderID, ProductID, ProductName, ProductType, Size, Qty, ProductNote, ImagePathName) VALUES (4, '3', '96', 'AS HD 058(A) Textura Sheet', 'Regular', '8x4', '20', 'Regular-N/A', '~/MyProducts/b0eaaa68-e165-42bd-8b1b-a92e4ac9840b_AS HD 058A.jpg');

SET IDENTITY_INSERT dbo.tbl_DealersOrderDTLs OFF;


-- Structure for table [DB_AcryshadeLaminatesTestAWS].[dbo].[tbl_DealersOrderHDR]
SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
CREATE TABLE [dbo].[tbl_DealersOrderHDR](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[OrderID] [nvarchar](max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[DealerID] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[CreatedDate] [datetime] NULL,
	[OrderStatus] [nvarchar](200) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[DesginStatus] [nvarchar](200) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[ProductionStatus] [nvarchar](200) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[PackagingStatus] [nvarchar](200) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[DispatchedStatus] [nvarchar](200) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[ApproveOrNotDate] [datetime] NULL,
	[EstimatedDeliveryDate] [datetime] NULL,
	[InvoicePath] [nvarchar](500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[HoldStatus] [bit] NULL,
	[HoldDate] [datetime] NULL,
	[Canceldate] [datetime] NULL,
 CONSTRAINT [PK__tbl_Deal__3214EC2777D7B772] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]


-- Data for table [DB_AcryshadeLaminatesTestAWS].[dbo].[tbl_DealersOrderHDR]
SET IDENTITY_INSERT dbo.tbl_DealersOrderHDR ON;

INSERT INTO dbo.tbl_DealersOrderHDR (ID, OrderID, DealerID, CreatedDate, OrderStatus, DesginStatus, ProductionStatus, PackagingStatus, DispatchedStatus, ApproveOrNotDate, EstimatedDeliveryDate, InvoicePath, HoldStatus, HoldDate, Canceldate) VALUES (1, 'ORD000011', '3', '7/24/2026 5:49:34 PM', 'Order Approved', 'Design Approved', 'Production Started', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO dbo.tbl_DealersOrderHDR (ID, OrderID, DealerID, CreatedDate, OrderStatus, DesginStatus, ProductionStatus, PackagingStatus, DispatchedStatus, ApproveOrNotDate, EstimatedDeliveryDate, InvoicePath, HoldStatus, HoldDate, Canceldate) VALUES (2, 'ORD000012', '313', '7/25/2026 9:59:26 AM', 'Order Approved', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO dbo.tbl_DealersOrderHDR (ID, OrderID, DealerID, CreatedDate, OrderStatus, DesginStatus, ProductionStatus, PackagingStatus, DispatchedStatus, ApproveOrNotDate, EstimatedDeliveryDate, InvoicePath, HoldStatus, HoldDate, Canceldate) VALUES (3, 'ORD000013', '42', '7/25/2026 10:00:02 AM', 'Order Approved', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL);

SET IDENTITY_INSERT dbo.tbl_DealersOrderHDR OFF;


-- Structure for table [DB_AcryshadeLaminatesTestAWS].[dbo].[tbl_DealersOrderTemp]
SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
CREATE TABLE [dbo].[tbl_DealersOrderTemp](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[ProductID] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[ProductName] [nvarchar](max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[ProductType] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Size] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Qty] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[ProductNote] [nvarchar](max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[ImagePathName] [nvarchar](max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[DealersID] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[AddedDate] [datetime] NULL,
PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]


-- Data for table [DB_AcryshadeLaminatesTestAWS].[dbo].[tbl_DealersOrderTemp]
SET IDENTITY_INSERT dbo.tbl_DealersOrderTemp ON;


SET IDENTITY_INSERT dbo.tbl_DealersOrderTemp OFF;


-- Structure for table [DB_AcryshadeLaminatesTestAWS].[dbo].[tbl_FileBackup]
SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
CREATE TABLE [dbo].[tbl_FileBackup](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[FolderName] [nvarchar](300) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[FileName] [nvarchar](500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[FullFileName] [nvarchar](500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[RelativePath] [nvarchar](max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Extension] [nvarchar](20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[FileSize] [bigint] NULL,
	[FileData] [varbinary](max) NULL,
	[BackupDate] [datetime] NULL,
PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

ALTER TABLE [dbo].[tbl_FileBackup] ADD  DEFAULT (getdate()) FOR [BackupDate]

-- Data for table [DB_AcryshadeLaminatesTestAWS].[dbo].[tbl_FileBackup]
SET IDENTITY_INSERT dbo.tbl_FileBackup ON;

INSERT INTO dbo.tbl_FileBackup (ID, FolderName, FileName, FullFileName, RelativePath, Extension, FileSize, FileData, BackupDate) VALUES (1, 'MachineImages', 'images.jfif', '41dd3661-1763-4c4a-935a-549aa9a9bad0_images.jfif', 'Content\MachineImages\41dd3661-1763-4c4a-935a-549aa9a9bad0_images.jfif', '.jfif', 10503, System.Byte[], '7/21/2026 3:45:09 PM');
INSERT INTO dbo.tbl_FileBackup (ID, FolderName, FileName, FullFileName, RelativePath, Extension, FileSize, FileData, BackupDate) VALUES (2, 'MachineImages', 'videoframe_6064.png', 'afd89a41-0798-4fb7-a811-be6cf800cee4_videoframe_6064.png', 'Content\MachineImages\afd89a41-0798-4fb7-a811-be6cf800cee4_videoframe_6064.png', '.png', 304748, System.Byte[], '7/21/2026 3:45:09 PM');
INSERT INTO dbo.tbl_FileBackup (ID, FolderName, FileName, FullFileName, RelativePath, Extension, FileSize, FileData, BackupDate) VALUES (3, 'MyProducts', 'AS HD 087 B.jpg', '0127099e-fb75-4bd8-8671-ccdc728b7a8d_AS HD 087 B.jpg', 'Content\MyProducts\0127099e-fb75-4bd8-8671-ccdc728b7a8d_AS HD 087 B.jpg', '.jpg', 105624, System.Byte[], '7/21/2026 3:45:09 PM');
INSERT INTO dbo.tbl_FileBackup (ID, FolderName, FileName, FullFileName, RelativePath, Extension, FileSize, FileData, BackupDate) VALUES (4, 'MyProducts', 'AS HD 016B.jpg', '044e251d-757a-4e8e-9f04-46fd0db70dcf_AS HD 016B.jpg', 'Content\MyProducts\044e251d-757a-4e8e-9f04-46fd0db70dcf_AS HD 016B.jpg', '.jpg', 250600, System.Byte[], '7/21/2026 3:45:09 PM');
INSERT INTO dbo.tbl_FileBackup (ID, FolderName, FileName, FullFileName, RelativePath, Extension, FileSize, FileData, BackupDate) VALUES (5, 'MyProducts', 'AS HD 030A.jpg', '075a0cfa-835c-42ee-a3c3-79f0901391cf_AS HD 030A.jpg', 'Content\MyProducts\075a0cfa-835c-42ee-a3c3-79f0901391cf_AS HD 030A.jpg', '.jpg', 184111, System.Byte[], '7/21/2026 3:45:09 PM');
INSERT INTO dbo.tbl_FileBackup (ID, FolderName, FileName, FullFileName, RelativePath, Extension, FileSize, FileData, BackupDate) VALUES (6, 'MyProducts', 'AS HD 073C.jpg', '080103da-2be5-4025-8379-5f46d889f3c9_AS HD 073C.jpg', 'Content\MyProducts\080103da-2be5-4025-8379-5f46d889f3c9_AS HD 073C.jpg', '.jpg', 155340, System.Byte[], '7/21/2026 3:45:09 PM');
INSERT INTO dbo.tbl_FileBackup (ID, FolderName, FileName, FullFileName, RelativePath, Extension, FileSize, FileData, BackupDate) VALUES (7, 'MyProducts', 'AS HD 026B.jpg', '0a28e3cb-09d1-4633-8237-6d1f49e3b7a0_AS HD 026B.jpg', 'Content\MyProducts\0a28e3cb-09d1-4633-8237-6d1f49e3b7a0_AS HD 026B.jpg', '.jpg', 174564, System.Byte[], '7/21/2026 3:45:09 PM');
INSERT INTO dbo.tbl_FileBackup (ID, FolderName, FileName, FullFileName, RelativePath, Extension, FileSize, FileData, BackupDate) VALUES (8, 'MyProducts', 'AS HD 040A.jpg', '0d051625-8f29-4470-a354-237e10c7ea7c_AS HD 040A.jpg', 'Content\MyProducts\0d051625-8f29-4470-a354-237e10c7ea7c_AS HD 040A.jpg', '.jpg', 138773, System.Byte[], '7/21/2026 3:45:09 PM');
INSERT INTO dbo.tbl_FileBackup (ID, FolderName, FileName, FullFileName, RelativePath, Extension, FileSize, FileData, BackupDate) VALUES (9, 'MyProducts', 'AS HD 008A.jpg', '0e2ec31d-584b-477c-9459-af22bcc99371_AS HD 008A.jpg', 'Content\MyProducts\0e2ec31d-584b-477c-9459-af22bcc99371_AS HD 008A.jpg', '.jpg', 325927, System.Byte[], '7/21/2026 3:45:09 PM');
INSERT INTO dbo.tbl_FileBackup (ID, FolderName, FileName, FullFileName, RelativePath, Extension, FileSize, FileData, BackupDate) VALUES (10, 'MyProducts', 'AS HD 063A.jpg', '132fe554-5fb1-40b8-a7b7-f415267872fa_AS HD 063A.jpg', 'Content\MyProducts\132fe554-5fb1-40b8-a7b7-f415267872fa_AS HD 063A.jpg', '.jpg', 283787, System.Byte[], '7/21/2026 3:45:09 PM');
INSERT INTO dbo.tbl_FileBackup (ID, FolderName, FileName, FullFileName, RelativePath, Extension, FileSize, FileData, BackupDate) VALUES (11, 'MyProducts', 'AS HD 043B.jpg', '13ba995f-c220-45ba-91cf-f7c0676f3242_AS HD 043B.jpg', 'Content\MyProducts\13ba995f-c220-45ba-91cf-f7c0676f3242_AS HD 043B.jpg', '.jpg', 158613, System.Byte[], '7/21/2026 3:45:09 PM');
INSERT INTO dbo.tbl_FileBackup (ID, FolderName, FileName, FullFileName, RelativePath, Extension, FileSize, FileData, BackupDate) VALUES (12, 'MyProducts', 'AS HD 084 A.jpg', '1437757e-ab29-49cb-9fc9-e308ab6bf202_AS HD 084 A.jpg', 'Content\MyProducts\1437757e-ab29-49cb-9fc9-e308ab6bf202_AS HD 084 A.jpg', '.jpg', 136483, System.Byte[], '7/21/2026 3:45:09 PM');
INSERT INTO dbo.tbl_FileBackup (ID, FolderName, FileName, FullFileName, RelativePath, Extension, FileSize, FileData, BackupDate) VALUES (13, 'MyProducts', 'AS HD 078A.jpg', '1503d9cc-a67c-40c3-a962-b18043b8d884_AS HD 078A.jpg', 'Content\MyProducts\1503d9cc-a67c-40c3-a962-b18043b8d884_AS HD 078A.jpg', '.jpg', 147850, System.Byte[], '7/21/2026 3:45:09 PM');
INSERT INTO dbo.tbl_FileBackup (ID, FolderName, FileName, FullFileName, RelativePath, Extension, FileSize, FileData, BackupDate) VALUES (14, 'MyProducts', 'AS HD 079.jpg', '15a92a20-aceb-4b11-bb32-8c0227d91c97_AS HD 079.jpg', 'Content\MyProducts\15a92a20-aceb-4b11-bb32-8c0227d91c97_AS HD 079.jpg', '.jpg', 192606, System.Byte[], '7/21/2026 3:45:09 PM');
INSERT INTO dbo.tbl_FileBackup (ID, FolderName, FileName, FullFileName, RelativePath, Extension, FileSize, FileData, BackupDate) VALUES (15, 'MyProducts', 'AS HD 001B.jpg', '17f77871-b949-4608-b0ef-18478cac855e_AS HD 001B.jpg', 'Content\MyProducts\17f77871-b949-4608-b0ef-18478cac855e_AS HD 001B.jpg', '.jpg', 421552, System.Byte[], '7/21/2026 3:45:09 PM');
INSERT INTO dbo.tbl_FileBackup (ID, FolderName, FileName, FullFileName, RelativePath, Extension, FileSize, FileData, BackupDate) VALUES (16, 'MyProducts', 'AS HD 073A.jpg', '191e2453-a114-4def-a9ee-052999ccd9e4_AS HD 073A.jpg', 'Content\MyProducts\191e2453-a114-4def-a9ee-052999ccd9e4_AS HD 073A.jpg', '.jpg', 144759, System.Byte[], '7/21/2026 3:45:09 PM');
INSERT INTO dbo.tbl_FileBackup (ID, FolderName, FileName, FullFileName, RelativePath, Extension, FileSize, FileData, BackupDate) VALUES (17, 'MyProducts', 'AS HD 004B.jpg', '1a0614a2-3f61-4219-92eb-58665d16e677_AS HD 004B.jpg', 'Content\MyProducts\1a0614a2-3f61-4219-92eb-58665d16e677_AS HD 004B.jpg', '.jpg', 471807, System.Byte[], '7/21/2026 3:45:09 PM');
INSERT INTO dbo.tbl_FileBackup (ID, FolderName, FileName, FullFileName, RelativePath, Extension, FileSize, FileData, BackupDate) VALUES (18, 'MyProducts', 'AS HD 065A.jpg', '1a9dd96a-2a80-4a08-a24e-3411b91883e9_AS HD 065A.jpg', 'Content\MyProducts\1a9dd96a-2a80-4a08-a24e-3411b91883e9_AS HD 065A.jpg', '.jpg', 225964, System.Byte[], '7/21/2026 3:45:09 PM');
INSERT INTO dbo.tbl_FileBackup (ID, FolderName, FileName, FullFileName, RelativePath, Extension, FileSize, FileData, BackupDate) VALUES (19, 'MyProducts', 'AS HD 059B.jpg', '1b185d41-e7a8-4c31-b104-114df13845d3_AS HD 059B.jpg', 'Content\MyProducts\1b185d41-e7a8-4c31-b104-114df13845d3_AS HD 059B.jpg', '.jpg', 241273, System.Byte[], '7/21/2026 3:45:09 PM');
INSERT INTO dbo.tbl_FileBackup (ID, FolderName, FileName, FullFileName, RelativePath, Extension, FileSize, FileData, BackupDate) VALUES (20, 'MyProducts', 'AS HD 018A.jpg', '1b7b68d4-0c23-48ee-8a06-fddad7a13490_AS HD 018A.jpg', 'Content\MyProducts\1b7b68d4-0c23-48ee-8a06-fddad7a13490_AS HD 018A.jpg', '.jpg', 165175, System.Byte[], '7/21/2026 3:45:09 PM');
INSERT INTO dbo.tbl_FileBackup (ID, FolderName, FileName, FullFileName, RelativePath, Extension, FileSize, FileData, BackupDate) VALUES (21, 'MyProducts', 'AS HD 034A.jpg', '1ba13544-96ac-4dc5-8236-05da7fb34c31_AS HD 034A.jpg', 'Content\MyProducts\1ba13544-96ac-4dc5-8236-05da7fb34c31_AS HD 034A.jpg', '.jpg', 88671, System.Byte[], '7/21/2026 3:45:09 PM');
INSERT INTO dbo.tbl_FileBackup (ID, FolderName, FileName, FullFileName, RelativePath, Extension, FileSize, FileData, BackupDate) VALUES (22, 'MyProducts', 'AS HD 023A.jpg', '1cede658-bf7c-4243-94be-850c9cedf264_AS HD 023A.jpg', 'Content\MyProducts\1cede658-bf7c-4243-94be-850c9cedf264_AS HD 023A.jpg', '.jpg', 247650, System.Byte[], '7/21/2026 3:45:09 PM');
INSERT INTO dbo.tbl_FileBackup (ID, FolderName, FileName, FullFileName, RelativePath, Extension, FileSize, FileData, BackupDate) VALUES (23, 'MyProducts', 'AS HD 087 A.jpg', '1f8d2c74-174f-458a-89d3-26fc5d5e34e0_AS HD 087 A.jpg', 'Content\MyProducts\1f8d2c74-174f-458a-89d3-26fc5d5e34e0_AS HD 087 A.jpg', '.jpg', 101748, System.Byte[], '7/21/2026 3:45:09 PM');
INSERT INTO dbo.tbl_FileBackup (ID, FolderName, FileName, FullFileName, RelativePath, Extension, FileSize, FileData, BackupDate) VALUES (24, 'MyProducts', 'AS HD 005B.jpg', '2347b4ba-5ce0-435e-9b64-77166bc432a3_AS HD 005B.jpg', 'Content\MyProducts\2347b4ba-5ce0-435e-9b64-77166bc432a3_AS HD 005B.jpg', '.jpg', 528731, System.Byte[], '7/21/2026 3:45:09 PM');
INSERT INTO dbo.tbl_FileBackup (ID, FolderName, FileName, FullFileName, RelativePath, Extension, FileSize, FileData, BackupDate) VALUES (25, 'MyProducts', 'AS HD 067A.jpg', '248507ca-1d38-4ae6-8426-2922036d8c97_AS HD 067A.jpg', 'Content\MyProducts\248507ca-1d38-4ae6-8426-2922036d8c97_AS HD 067A.jpg', '.jpg', 380087, System.Byte[], '7/21/2026 3:45:09 PM');
INSERT INTO dbo.tbl_FileBackup (ID, FolderName, FileName, FullFileName, RelativePath, Extension, FileSize, FileData, BackupDate) VALUES (26, 'MyProducts', 'AS HD 068B.jpg', '260b04c8-a7b1-40e0-9ce0-e8d531daf6c8_AS HD 068B.jpg', 'Content\MyProducts\260b04c8-a7b1-40e0-9ce0-e8d531daf6c8_AS HD 068B.jpg', '.jpg', 194148, System.Byte[], '7/21/2026 3:45:09 PM');
INSERT INTO dbo.tbl_FileBackup (ID, FolderName, FileName, FullFileName, RelativePath, Extension, FileSize, FileData, BackupDate) VALUES (27, 'MyProducts', 'AS HD 013B.jpg', '296a4122-bc4c-4c55-82fe-24e7de9f2e41_AS HD 013B.jpg', 'Content\MyProducts\296a4122-bc4c-4c55-82fe-24e7de9f2e41_AS HD 013B.jpg', '.jpg', 239541, System.Byte[], '7/21/2026 3:45:09 PM');
INSERT INTO dbo.tbl_FileBackup (ID, FolderName, FileName, FullFileName, RelativePath, Extension, FileSize, FileData, BackupDate) VALUES (28, 'MyProducts', 'AS HD 036D.jpg', '29a9a9d4-499d-4ddd-9661-57ba6b6280ac_AS HD 036D.jpg', 'Content\MyProducts\29a9a9d4-499d-4ddd-9661-57ba6b6280ac_AS HD 036D.jpg', '.jpg', 141594, System.Byte[], '7/21/2026 3:45:09 PM');
INSERT INTO dbo.tbl_FileBackup (ID, FolderName, FileName, FullFileName, RelativePath, Extension, FileSize, FileData, BackupDate) VALUES (29, 'MyProducts', 'AS HD 016A.jpg', '2ed2a9dc-f2ca-4b26-ba57-61bebabfee10_AS HD 016A.jpg', 'Content\MyProducts\2ed2a9dc-f2ca-4b26-ba57-61bebabfee10_AS HD 016A.jpg', '.jpg', 251659, System.Byte[], '7/21/2026 3:45:09 PM');
INSERT INTO dbo.tbl_FileBackup (ID, FolderName, FileName, FullFileName, RelativePath, Extension, FileSize, FileData, BackupDate) VALUES (30, 'MyProducts', 'AS HD 012A.jpg', '2fe8bd7f-5baa-40ec-8451-26eea499a551_AS HD 012A.jpg', 'Content\MyProducts\2fe8bd7f-5baa-40ec-8451-26eea499a551_AS HD 012A.jpg', '.jpg', 532793, System.Byte[], '7/21/2026 3:45:09 PM');
INSERT INTO dbo.tbl_FileBackup (ID, FolderName, FileName, FullFileName, RelativePath, Extension, FileSize, FileData, BackupDate) VALUES (31, 'MyProducts', 'AS HD 046A.jpg', '31739f02-05be-4cd7-b8b7-65da31c5505e_AS HD 046A.jpg', 'Content\MyProducts\31739f02-05be-4cd7-b8b7-65da31c5505e_AS HD 046A.jpg', '.jpg', 166006, System.Byte[], '7/21/2026 3:45:09 PM');
INSERT INTO dbo.tbl_FileBackup (ID, FolderName, FileName, FullFileName, RelativePath, Extension, FileSize, FileData, BackupDate) VALUES (32, 'MyProducts', 'AS HD 049B.jpg', '32bc841d-8566-4ed0-9dd7-2b47a76b9ee7_AS HD 049B.jpg', 'Content\MyProducts\32bc841d-8566-4ed0-9dd7-2b47a76b9ee7_AS HD 049B.jpg', '.jpg', 116780, System.Byte[], '7/21/2026 3:45:09 PM');
INSERT INTO dbo.tbl_FileBackup (ID, FolderName, FileName, FullFileName, RelativePath, Extension, FileSize, FileData, BackupDate) VALUES (33, 'MyProducts', 'AS HD 043C.jpg', '3667d019-7afd-443b-bd14-7ca5dfd72043_AS HD 043C.jpg', 'Content\MyProducts\3667d019-7afd-443b-bd14-7ca5dfd72043_AS HD 043C.jpg', '.jpg', 149597, System.Byte[], '7/21/2026 3:45:09 PM');
INSERT INTO dbo.tbl_FileBackup (ID, FolderName, FileName, FullFileName, RelativePath, Extension, FileSize, FileData, BackupDate) VALUES (34, 'MyProducts', 'AS HD 043A.jpg', '37397a81-ec44-4da4-997b-af3df5ce0772_AS HD 043A.jpg', 'Content\MyProducts\37397a81-ec44-4da4-997b-af3df5ce0772_AS HD 043A.jpg', '.jpg', 171487, System.Byte[], '7/21/2026 3:45:09 PM');
INSERT INTO dbo.tbl_FileBackup (ID, FolderName, FileName, FullFileName, RelativePath, Extension, FileSize, FileData, BackupDate) VALUES (35, 'MyProducts', 'AS HD 037C.jpg', '3774fd7b-5878-426a-8eee-7434e963e799_AS HD 037C.jpg', 'Content\MyProducts\3774fd7b-5878-426a-8eee-7434e963e799_AS HD 037C.jpg', '.jpg', 193329, System.Byte[], '7/21/2026 3:45:09 PM');
INSERT INTO dbo.tbl_FileBackup (ID, FolderName, FileName, FullFileName, RelativePath, Extension, FileSize, FileData, BackupDate) VALUES (36, 'MyProducts', 'AS HD 074A.jpg', '37fd524f-c1d5-4a7a-b8b9-bfcdeb8961ac_AS HD 074A.jpg', 'Content\MyProducts\37fd524f-c1d5-4a7a-b8b9-bfcdeb8961ac_AS HD 074A.jpg', '.jpg', 152814, System.Byte[], '7/21/2026 3:45:09 PM');
INSERT INTO dbo.tbl_FileBackup (ID, FolderName, FileName, FullFileName, RelativePath, Extension, FileSize, FileData, BackupDate) VALUES (37, 'MyProducts', 'AS HD 019B.jpg', '3ba396f5-dfa4-4a4a-8705-6ac15054edeb_AS HD 019B.jpg', 'Content\MyProducts\3ba396f5-dfa4-4a4a-8705-6ac15054edeb_AS HD 019B.jpg', '.jpg', 172675, System.Byte[], '7/21/2026 3:45:09 PM');
INSERT INTO dbo.tbl_FileBackup (ID, FolderName, FileName, FullFileName, RelativePath, Extension, FileSize, FileData, BackupDate) VALUES (38, 'MyProducts', 'AS HD 042A.jpg', '3dc5fcd9-bc3d-4829-ac03-b97687ec8b8d_AS HD 042A.jpg', 'Content\MyProducts\3dc5fcd9-bc3d-4829-ac03-b97687ec8b8d_AS HD 042A.jpg', '.jpg', 161219, System.Byte[], '7/21/2026 3:45:09 PM');
INSERT INTO dbo.tbl_FileBackup (ID, FolderName, FileName, FullFileName, RelativePath, Extension, FileSize, FileData, BackupDate) VALUES (39, 'MyProducts', 'AS HD 035C.jpg', '3e0b1e4a-be22-46b8-8645-6bbaf08d0d8c_AS HD 035C.jpg', 'Content\MyProducts\3e0b1e4a-be22-46b8-8645-6bbaf08d0d8c_AS HD 035C.jpg', '.jpg', 106503, System.Byte[], '7/21/2026 3:45:09 PM');
INSERT INTO dbo.tbl_FileBackup (ID, FolderName, FileName, FullFileName, RelativePath, Extension, FileSize, FileData, BackupDate) VALUES (40, 'MyProducts', 'AS HD 061A.jpg', '3e28c6ac-12b0-4651-86c0-34340f1e077b_AS HD 061A.jpg', 'Content\MyProducts\3e28c6ac-12b0-4651-86c0-34340f1e077b_AS HD 061A.jpg', '.jpg', 141386, System.Byte[], '7/21/2026 3:45:09 PM');
INSERT INTO dbo.tbl_FileBackup (ID, FolderName, FileName, FullFileName, RelativePath, Extension, FileSize, FileData, BackupDate) VALUES (41, 'MyProducts', 'AS HD 036B.jpg', '3e332b29-7850-42f0-bba2-1c340e6f12c6_AS HD 036B.jpg', 'Content\MyProducts\3e332b29-7850-42f0-bba2-1c340e6f12c6_AS HD 036B.jpg', '.jpg', 162229, System.Byte[], '7/21/2026 3:45:09 PM');
INSERT INTO dbo.tbl_FileBackup (ID, FolderName, FileName, FullFileName, RelativePath, Extension, FileSize, FileData, BackupDate) VALUES (42, 'MyProducts', 'AS HD 010A.jpg', '3f5bb052-ec3f-469e-b0dc-caafb7aafe48_AS HD 010A.jpg', 'Content\MyProducts\3f5bb052-ec3f-469e-b0dc-caafb7aafe48_AS HD 010A.jpg', '.jpg', 508588, System.Byte[], '7/21/2026 3:45:09 PM');
INSERT INTO dbo.tbl_FileBackup (ID, FolderName, FileName, FullFileName, RelativePath, Extension, FileSize, FileData, BackupDate) VALUES (43, 'MyProducts', 'AS HD 031A.jpg', '3f803870-f619-4ae1-8c7f-a938c8cf5c71_AS HD 031A.jpg', 'Content\MyProducts\3f803870-f619-4ae1-8c7f-a938c8cf5c71_AS HD 031A.jpg', '.jpg', 155293, System.Byte[], '7/21/2026 3:45:09 PM');
INSERT INTO dbo.tbl_FileBackup (ID, FolderName, FileName, FullFileName, RelativePath, Extension, FileSize, FileData, BackupDate) VALUES (44, 'MyProducts', 'AS HD 017A.jpg', '404478b4-22f8-4e45-9c59-e41f85dd8b98_AS HD 017A.jpg', 'Content\MyProducts\404478b4-22f8-4e45-9c59-e41f85dd8b98_AS HD 017A.jpg', '.jpg', 170209, System.Byte[], '7/21/2026 3:45:09 PM');
INSERT INTO dbo.tbl_FileBackup (ID, FolderName, FileName, FullFileName, RelativePath, Extension, FileSize, FileData, BackupDate) VALUES (45, 'MyProducts', 'AS HD 085 B.jpg', '429251c5-7bcd-446c-97b1-88933bb42519_AS HD 085 B.jpg', 'Content\MyProducts\429251c5-7bcd-446c-97b1-88933bb42519_AS HD 085 B.jpg', '.jpg', 137196, System.Byte[], '7/21/2026 3:45:09 PM');
INSERT INTO dbo.tbl_FileBackup (ID, FolderName, FileName, FullFileName, RelativePath, Extension, FileSize, FileData, BackupDate) VALUES (46, 'MyProducts', 'AS HD 008B.jpg', '442d7ba5-e73e-4119-b795-896a0731bf36_AS HD 008B.jpg', 'Content\MyProducts\442d7ba5-e73e-4119-b795-896a0731bf36_AS HD 008B.jpg', '.jpg', 326623, System.Byte[], '7/21/2026 3:45:09 PM');
INSERT INTO dbo.tbl_FileBackup (ID, FolderName, FileName, FullFileName, RelativePath, Extension, FileSize, FileData, BackupDate) VALUES (47, 'MyProducts', 'AS HD 047A.jpg', '463c346d-e901-42a8-b15a-2cff619361c4_AS HD 047A.jpg', 'Content\MyProducts\463c346d-e901-42a8-b15a-2cff619361c4_AS HD 047A.jpg', '.jpg', 180223, System.Byte[], '7/21/2026 3:45:09 PM');
INSERT INTO dbo.tbl_FileBackup (ID, FolderName, FileName, FullFileName, RelativePath, Extension, FileSize, FileData, BackupDate) VALUES (48, 'MyProducts', 'AS HD 028A.jpg', '47840755-6c82-423d-a27f-16c115eddf4f_AS HD 028A.jpg', 'Content\MyProducts\47840755-6c82-423d-a27f-16c115eddf4f_AS HD 028A.jpg', '.jpg', 164756, System.Byte[], '7/21/2026 3:45:09 PM');
INSERT INTO dbo.tbl_FileBackup (ID, FolderName, FileName, FullFileName, RelativePath, Extension, FileSize, FileData, BackupDate) VALUES (49, 'MyProducts', 'AS HD 007B.jpg', '47a9ae51-86ca-4975-866f-bae39655e92b_AS HD 007B.jpg', 'Content\MyProducts\47a9ae51-86ca-4975-866f-bae39655e92b_AS HD 007B.jpg', '.jpg', 550042, System.Byte[], '7/21/2026 3:45:09 PM');
INSERT INTO dbo.tbl_FileBackup (ID, FolderName, FileName, FullFileName, RelativePath, Extension, FileSize, FileData, BackupDate) VALUES (50, 'MyProducts', 'AS HD 034D.jpg', '48826690-e66b-42ab-a1ce-509a0641cd01_AS HD 034D.jpg', 'Content\MyProducts\48826690-e66b-42ab-a1ce-509a0641cd01_AS HD 034D.jpg', '.jpg', 99492, System.Byte[], '7/21/2026 3:45:09 PM');
INSERT INTO dbo.tbl_FileBackup (ID, FolderName, FileName, FullFileName, RelativePath, Extension, FileSize, FileData, BackupDate) VALUES (51, 'MyProducts', 'AS HD 062A.jpg', '494b1768-6a5f-4add-9ddd-94909a435258_AS HD 062A.jpg', 'Content\MyProducts\494b1768-6a5f-4add-9ddd-94909a435258_AS HD 062A.jpg', '.jpg', 145507, System.Byte[], '7/21/2026 3:45:09 PM');
INSERT INTO dbo.tbl_FileBackup (ID, FolderName, FileName, FullFileName, RelativePath, Extension, FileSize, FileData, BackupDate) VALUES (52, 'MyProducts', 'AS HD 033A.jpg', '4aa83eca-9edf-4c17-a430-233272a44d7c_AS HD 033A.jpg', 'Content\MyProducts\4aa83eca-9edf-4c17-a430-233272a44d7c_AS HD 033A.jpg', '.jpg', 156763, System.Byte[], '7/21/2026 3:45:09 PM');
INSERT INTO dbo.tbl_FileBackup (ID, FolderName, FileName, FullFileName, RelativePath, Extension, FileSize, FileData, BackupDate) VALUES (53, 'MyProducts', 'AS HD 014B.jpg', '4c944651-9732-4077-80aa-4e2a30763f44_AS HD 014B.jpg', 'Content\MyProducts\4c944651-9732-4077-80aa-4e2a30763f44_AS HD 014B.jpg', '.jpg', 430787, System.Byte[], '7/21/2026 3:45:09 PM');
INSERT INTO dbo.tbl_FileBackup (ID, FolderName, FileName, FullFileName, RelativePath, Extension, FileSize, FileData, BackupDate) VALUES (54, 'MyProducts', 'AS HD 059A.jpg', '4d4faea8-0ca3-44df-a444-903dd8d10072_AS HD 059A.jpg', 'Content\MyProducts\4d4faea8-0ca3-44df-a444-903dd8d10072_AS HD 059A.jpg', '.jpg', 241534, System.Byte[], '7/21/2026 3:45:09 PM');
INSERT INTO dbo.tbl_FileBackup (ID, FolderName, FileName, FullFileName, RelativePath, Extension, FileSize, FileData, BackupDate) VALUES (55, 'MyProducts', 'AS HD 018B.jpg', '4da3a31c-8232-425e-aca9-756ae574cba2_AS HD 018B.jpg', 'Content\MyProducts\4da3a31c-8232-425e-aca9-756ae574cba2_AS HD 018B.jpg', '.jpg', 165321, System.Byte[], '7/21/2026 3:45:09 PM');
INSERT INTO dbo.tbl_FileBackup (ID, FolderName, FileName, FullFileName, RelativePath, Extension, FileSize, FileData, BackupDate) VALUES (56, 'MyProducts', 'AS HD 074B.jpg', '4e5d84f3-db88-47b0-97fa-26f290d083ab_AS HD 074B.jpg', 'Content\MyProducts\4e5d84f3-db88-47b0-97fa-26f290d083ab_AS HD 074B.jpg', '.jpg', 152610, System.Byte[], '7/21/2026 3:45:09 PM');
INSERT INTO dbo.tbl_FileBackup (ID, FolderName, FileName, FullFileName, RelativePath, Extension, FileSize, FileData, BackupDate) VALUES (57, 'MyProducts', 'AS HD 081.jpg', '4f72b734-26ae-4624-9bb0-500609f3945e_AS HD 081.jpg', 'Content\MyProducts\4f72b734-26ae-4624-9bb0-500609f3945e_AS HD 081.jpg', '.jpg', 166669, System.Byte[], '7/21/2026 3:45:09 PM');
INSERT INTO dbo.tbl_FileBackup (ID, FolderName, FileName, FullFileName, RelativePath, Extension, FileSize, FileData, BackupDate) VALUES (58, 'MyProducts', 'AS HD 061A.jpg', '507af36e-48c5-4963-b134-5170a09a652f_AS HD 061A.jpg', 'Content\MyProducts\507af36e-48c5-4963-b134-5170a09a652f_AS HD 061A.jpg', '.jpg', 141386, System.Byte[], '7/21/2026 3:45:09 PM');
INSERT INTO dbo.tbl_FileBackup (ID, FolderName, FileName, FullFileName, RelativePath, Extension, FileSize, FileData, BackupDate) VALUES (59, 'MyProducts', 'AS HD 082.jpg', '52a9a0d3-a65f-43d9-adf0-144903c9ac0b_AS HD 082.jpg', 'Content\MyProducts\52a9a0d3-a65f-43d9-adf0-144903c9ac0b_AS HD 082.jpg', '.jpg', 171679, System.Byte[], '7/21/2026 3:45:09 PM');
INSERT INTO dbo.tbl_FileBackup (ID, FolderName, FileName, FullFileName, RelativePath, Extension, FileSize, FileData, BackupDate) VALUES (60, 'MyProducts', 'AS HD 005A.jpg', '53bf55c7-8f2a-40bd-817c-fb5c3e292413_AS HD 005A.jpg', 'Content\MyProducts\53bf55c7-8f2a-40bd-817c-fb5c3e292413_AS HD 005A.jpg', '.jpg', 528366, System.Byte[], '7/21/2026 3:45:09 PM');
INSERT INTO dbo.tbl_FileBackup (ID, FolderName, FileName, FullFileName, RelativePath, Extension, FileSize, FileData, BackupDate) VALUES (61, 'MyProducts', 'AS HD 064A.jpg', '55578f50-f955-4ee5-b1c9-a50d844c1194_AS HD 064A.jpg', 'Content\MyProducts\55578f50-f955-4ee5-b1c9-a50d844c1194_AS HD 064A.jpg', '.jpg', 224811, System.Byte[], '7/21/2026 3:45:09 PM');
INSERT INTO dbo.tbl_FileBackup (ID, FolderName, FileName, FullFileName, RelativePath, Extension, FileSize, FileData, BackupDate) VALUES (62, 'MyProducts', 'AS HD 010B.jpg', '5822b8a2-8e41-4957-b0a1-9040c32bf89d_AS HD 010B.jpg', 'Content\MyProducts\5822b8a2-8e41-4957-b0a1-9040c32bf89d_AS HD 010B.jpg', '.jpg', 508456, System.Byte[], '7/21/2026 3:45:09 PM');
INSERT INTO dbo.tbl_FileBackup (ID, FolderName, FileName, FullFileName, RelativePath, Extension, FileSize, FileData, BackupDate) VALUES (63, 'MyProducts', 'AS HD 056A.jpg', '59b603c6-07b5-4053-8b2f-dde3b25eed4b_AS HD 056A.jpg', 'Content\MyProducts\59b603c6-07b5-4053-8b2f-dde3b25eed4b_AS HD 056A.jpg', '.jpg', 150662, System.Byte[], '7/21/2026 3:45:09 PM');
INSERT INTO dbo.tbl_FileBackup (ID, FolderName, FileName, FullFileName, RelativePath, Extension, FileSize, FileData, BackupDate) VALUES (64, 'MyProducts', 'AS HD 020A.jpg', '5b30f378-1e62-4ae7-ae97-0d3ad6249ebb_AS HD 020A.jpg', 'Content\MyProducts\5b30f378-1e62-4ae7-ae97-0d3ad6249ebb_AS HD 020A.jpg', '.jpg', 182254, System.Byte[], '7/21/2026 3:45:09 PM');
INSERT INTO dbo.tbl_FileBackup (ID, FolderName, FileName, FullFileName, RelativePath, Extension, FileSize, FileData, BackupDate) VALUES (65, 'MyProducts', 'AS HD 035A.jpg', '5c0f7443-9d58-4517-8034-faeb0920ae22_AS HD 035A.jpg', 'Content\MyProducts\5c0f7443-9d58-4517-8034-faeb0920ae22_AS HD 035A.jpg', '.jpg', 115167, System.Byte[], '7/21/2026 3:45:09 PM');
INSERT INTO dbo.tbl_FileBackup (ID, FolderName, FileName, FullFileName, RelativePath, Extension, FileSize, FileData, BackupDate) VALUES (66, 'MyProducts', 'AS HD 061B.jpg', '5d32514a-6c9e-48e7-946b-eae71a5e0c43_AS HD 061B.jpg', 'Content\MyProducts\5d32514a-6c9e-48e7-946b-eae71a5e0c43_AS HD 061B.jpg', '.jpg', 140679, System.Byte[], '7/21/2026 3:45:09 PM');
INSERT INTO dbo.tbl_FileBackup (ID, FolderName, FileName, FullFileName, RelativePath, Extension, FileSize, FileData, BackupDate) VALUES (67, 'MyProducts', 'AS HD 007A.jpg', '5d91818f-25fc-4688-b316-b988091154e6_AS HD 007A.jpg', 'Content\MyProducts\5d91818f-25fc-4688-b316-b988091154e6_AS HD 007A.jpg', '.jpg', 548549, System.Byte[], '7/21/2026 3:45:09 PM');
INSERT INTO dbo.tbl_FileBackup (ID, FolderName, FileName, FullFileName, RelativePath, Extension, FileSize, FileData, BackupDate) VALUES (68, 'MyProducts', 'AS HD 056B.jpg', '6071b8cd-28b0-49e7-915d-b911ae4e7e1c_AS HD 056B.jpg', 'Content\MyProducts\6071b8cd-28b0-49e7-915d-b911ae4e7e1c_AS HD 056B.jpg', '.jpg', 149387, System.Byte[], '7/21/2026 3:45:09 PM');
INSERT INTO dbo.tbl_FileBackup (ID, FolderName, FileName, FullFileName, RelativePath, Extension, FileSize, FileData, BackupDate) VALUES (69, 'MyProducts', 'AS HD 080.jpg', '61693884-c7dd-4b52-9c9b-2f780d10bd0e_AS HD 080.jpg', 'Content\MyProducts\61693884-c7dd-4b52-9c9b-2f780d10bd0e_AS HD 080.jpg', '.jpg', 175772, System.Byte[], '7/21/2026 3:45:09 PM');
INSERT INTO dbo.tbl_FileBackup (ID, FolderName, FileName, FullFileName, RelativePath, Extension, FileSize, FileData, BackupDate) VALUES (70, 'MyProducts', 'AS HD 073B.jpg', '634a5316-d0a4-46da-8a15-4b540ccf282f_AS HD 073B.jpg', 'Content\MyProducts\634a5316-d0a4-46da-8a15-4b540ccf282f_AS HD 073B.jpg', '.jpg', 154054, System.Byte[], '7/21/2026 3:45:09 PM');
INSERT INTO dbo.tbl_FileBackup (ID, FolderName, FileName, FullFileName, RelativePath, Extension, FileSize, FileData, BackupDate) VALUES (71, 'MyProducts', 'AS HD 072A.jpg', '6a05b798-3820-4887-a491-c48eb902b992_AS HD 072A.jpg', 'Content\MyProducts\6a05b798-3820-4887-a491-c48eb902b992_AS HD 072A.jpg', '.jpg', 164509, System.Byte[], '7/21/2026 3:45:09 PM');
INSERT INTO dbo.tbl_FileBackup (ID, FolderName, FileName, FullFileName, RelativePath, Extension, FileSize, FileData, BackupDate) VALUES (72, 'MyProducts', 'AS HD 072B.jpg', '6a53537d-261a-4d87-8f92-01d3201788f3_AS HD 072B.jpg', 'Content\MyProducts\6a53537d-261a-4d87-8f92-01d3201788f3_AS HD 072B.jpg', '.jpg', 162571, System.Byte[], '7/21/2026 3:45:09 PM');
INSERT INTO dbo.tbl_FileBackup (ID, FolderName, FileName, FullFileName, RelativePath, Extension, FileSize, FileData, BackupDate) VALUES (73, 'MyProducts', 'AS HD 055A.jpg', '6b0cc4ed-a1fc-4563-9426-8a4fc94f371f_AS HD 055A.jpg', 'Content\MyProducts\6b0cc4ed-a1fc-4563-9426-8a4fc94f371f_AS HD 055A.jpg', '.jpg', 160880, System.Byte[], '7/21/2026 3:45:09 PM');
INSERT INTO dbo.tbl_FileBackup (ID, FolderName, FileName, FullFileName, RelativePath, Extension, FileSize, FileData, BackupDate) VALUES (74, 'MyProducts', 'AS HD 069B.jpg', '6e6e3e1c-9701-4d84-af10-caa008638498_AS HD 069B.jpg', 'Content\MyProducts\6e6e3e1c-9701-4d84-af10-caa008638498_AS HD 069B.jpg', '.jpg', 111003, System.Byte[], '7/21/2026 3:45:09 PM');
INSERT INTO dbo.tbl_FileBackup (ID, FolderName, FileName, FullFileName, RelativePath, Extension, FileSize, FileData, BackupDate) VALUES (75, 'MyProducts', 'AS HD 011B.jpg', '724546af-3e3e-4ccb-a63d-9903f98520c6_AS HD 011B.jpg', 'Content\MyProducts\724546af-3e3e-4ccb-a63d-9903f98520c6_AS HD 011B.jpg', '.jpg', 208907, System.Byte[], '7/21/2026 3:45:09 PM');
INSERT INTO dbo.tbl_FileBackup (ID, FolderName, FileName, FullFileName, RelativePath, Extension, FileSize, FileData, BackupDate) VALUES (76, 'MyProducts', 'AS HD 071A.jpg', '733ba225-c2f3-4190-9631-934b5e3bb470_AS HD 071A.jpg', 'Content\MyProducts\733ba225-c2f3-4190-9631-934b5e3bb470_AS HD 071A.jpg', '.jpg', 202449, System.Byte[], '7/21/2026 3:45:09 PM');
INSERT INTO dbo.tbl_FileBackup (ID, FolderName, FileName, FullFileName, RelativePath, Extension, FileSize, FileData, BackupDate) VALUES (77, 'MyProducts', 'AS HD 086 A.jpg', '7491a61e-252d-4f59-ab96-508b79d0e481_AS HD 086 A.jpg', 'Content\MyProducts\7491a61e-252d-4f59-ab96-508b79d0e481_AS HD 086 A.jpg', '.jpg', 161819, System.Byte[], '7/21/2026 3:45:09 PM');
INSERT INTO dbo.tbl_FileBackup (ID, FolderName, FileName, FullFileName, RelativePath, Extension, FileSize, FileData, BackupDate) VALUES (78, 'MyProducts', 'AS HD 085 A.jpg', '74ed3ddc-4f57-4369-bf96-94d21c0003c6_AS HD 085 A.jpg', 'Content\MyProducts\74ed3ddc-4f57-4369-bf96-94d21c0003c6_AS HD 085 A.jpg', '.jpg', 138557, System.Byte[], '7/21/2026 3:45:09 PM');
INSERT INTO dbo.tbl_FileBackup (ID, FolderName, FileName, FullFileName, RelativePath, Extension, FileSize, FileData, BackupDate) VALUES (79, 'MyProducts', 'AS HD 069A.jpg', '79209439-16ff-4063-a47c-c34c13dbe022_AS HD 069A.jpg', 'Content\MyProducts\79209439-16ff-4063-a47c-c34c13dbe022_AS HD 069A.jpg', '.jpg', 111594, System.Byte[], '7/21/2026 3:45:09 PM');
INSERT INTO dbo.tbl_FileBackup (ID, FolderName, FileName, FullFileName, RelativePath, Extension, FileSize, FileData, BackupDate) VALUES (80, 'MyProducts', 'AS HD 038A.jpg', '7cbec528-f817-474a-adf3-f36b750d0788_AS HD 038A.jpg', 'Content\MyProducts\7cbec528-f817-474a-adf3-f36b750d0788_AS HD 038A.jpg', '.jpg', 274067, System.Byte[], '7/21/2026 3:45:09 PM');
INSERT INTO dbo.tbl_FileBackup (ID, FolderName, FileName, FullFileName, RelativePath, Extension, FileSize, FileData, BackupDate) VALUES (81, 'MyProducts', 'AS HD 038B.jpg', '7d682cef-7624-4ee8-a547-dc78bf4d4ed0_AS HD 038B.jpg', 'Content\MyProducts\7d682cef-7624-4ee8-a547-dc78bf4d4ed0_AS HD 038B.jpg', '.jpg', 274697, System.Byte[], '7/21/2026 3:45:09 PM');
INSERT INTO dbo.tbl_FileBackup (ID, FolderName, FileName, FullFileName, RelativePath, Extension, FileSize, FileData, BackupDate) VALUES (82, 'MyProducts', 'AS HD 077B.jpg', '7da2c3c9-cbbe-482b-ac37-9a7d185829ff_AS HD 077B.jpg', 'Content\MyProducts\7da2c3c9-cbbe-482b-ac37-9a7d185829ff_AS HD 077B.jpg', '.jpg', 158573, System.Byte[], '7/21/2026 3:45:09 PM');
INSERT INTO dbo.tbl_FileBackup (ID, FolderName, FileName, FullFileName, RelativePath, Extension, FileSize, FileData, BackupDate) VALUES (83, 'MyProducts', 'AS HD 077A.jpg', '7fa6582e-c0b2-4f9b-a6c5-c6da0c1bf0ee_AS HD 077A.jpg', 'Content\MyProducts\7fa6582e-c0b2-4f9b-a6c5-c6da0c1bf0ee_AS HD 077A.jpg', '.jpg', 158903, System.Byte[], '7/21/2026 3:45:09 PM');
INSERT INTO dbo.tbl_FileBackup (ID, FolderName, FileName, FullFileName, RelativePath, Extension, FileSize, FileData, BackupDate) VALUES (84, 'MyProducts', 'AS HD 049A.jpg', '7fd74afa-bd24-4c06-b217-4b92f83cb95b_AS HD 049A.jpg', 'Content\MyProducts\7fd74afa-bd24-4c06-b217-4b92f83cb95b_AS HD 049A.jpg', '.jpg', 123398, System.Byte[], '7/21/2026 3:45:09 PM');
INSERT INTO dbo.tbl_FileBackup (ID, FolderName, FileName, FullFileName, RelativePath, Extension, FileSize, FileData, BackupDate) VALUES (85, 'MyProducts', 'AS HD 012B.jpg', '7ff1382c-ea61-47b8-bfb0-342d7fed7e10_AS HD 012B.jpg', 'Content\MyProducts\7ff1382c-ea61-47b8-bfb0-342d7fed7e10_AS HD 012B.jpg', '.jpg', 533529, System.Byte[], '7/21/2026 3:45:09 PM');
INSERT INTO dbo.tbl_FileBackup (ID, FolderName, FileName, FullFileName, RelativePath, Extension, FileSize, FileData, BackupDate) VALUES (86, 'MyProducts', 'AS HD 004A.jpg', '820830fb-e7b7-4708-8eb8-41429fe2158b_AS HD 004A.jpg', 'Content\MyProducts\820830fb-e7b7-4708-8eb8-41429fe2158b_AS HD 004A.jpg', '.jpg', 470236, System.Byte[], '7/21/2026 3:45:09 PM');
INSERT INTO dbo.tbl_FileBackup (ID, FolderName, FileName, FullFileName, RelativePath, Extension, FileSize, FileData, BackupDate) VALUES (87, 'MyProducts', 'AS HD 029A.jpg', '8434b840-f339-42f4-b7b2-5660cd2a6da5_AS HD 029A.jpg', 'Content\MyProducts\8434b840-f339-42f4-b7b2-5660cd2a6da5_AS HD 029A.jpg', '.jpg', 200000, System.Byte[], '7/21/2026 3:45:09 PM');
INSERT INTO dbo.tbl_FileBackup (ID, FolderName, FileName, FullFileName, RelativePath, Extension, FileSize, FileData, BackupDate) VALUES (88, 'MyProducts', 'AS HD 030B.jpg', '88c4d74b-50b9-4f93-a822-221d94bf4a67_AS HD 030B.jpg', 'Content\MyProducts\88c4d74b-50b9-4f93-a822-221d94bf4a67_AS HD 030B.jpg', '.jpg', 174151, System.Byte[], '7/21/2026 3:45:09 PM');
INSERT INTO dbo.tbl_FileBackup (ID, FolderName, FileName, FullFileName, RelativePath, Extension, FileSize, FileData, BackupDate) VALUES (89, 'MyProducts', 'AS HD 054A.jpg', '88c99405-c341-4820-97e3-7353aac6bd1b_AS HD 054A.jpg', 'Content\MyProducts\88c99405-c341-4820-97e3-7353aac6bd1b_AS HD 054A.jpg', '.jpg', 170531, System.Byte[], '7/21/2026 3:45:09 PM');
INSERT INTO dbo.tbl_FileBackup (ID, FolderName, FileName, FullFileName, RelativePath, Extension, FileSize, FileData, BackupDate) VALUES (90, 'MyProducts', 'AS HD 041A.jpg', '89367188-9608-4375-aa51-e10384a6a28b_AS HD 041A.jpg', 'Content\MyProducts\89367188-9608-4375-aa51-e10384a6a28b_AS HD 041A.jpg', '.jpg', 179571, System.Byte[], '7/21/2026 3:45:09 PM');
INSERT INTO dbo.tbl_FileBackup (ID, FolderName, FileName, FullFileName, RelativePath, Extension, FileSize, FileData, BackupDate) VALUES (91, 'MyProducts', 'AS HD 086 B.jpg', '8afd5786-e44a-491c-b937-752200859beb_AS HD 086 B.jpg', 'Content\MyProducts\8afd5786-e44a-491c-b937-752200859beb_AS HD 086 B.jpg', '.jpg', 160624, System.Byte[], '7/21/2026 3:45:09 PM');
INSERT INTO dbo.tbl_FileBackup (ID, FolderName, FileName, FullFileName, RelativePath, Extension, FileSize, FileData, BackupDate) VALUES (92, 'MyProducts', 'AS HD 035D.jpg', '8e3d57b3-c69b-4e3f-ac58-7839b3286f50_AS HD 035D.jpg', 'Content\MyProducts\8e3d57b3-c69b-4e3f-ac58-7839b3286f50_AS HD 035D.jpg', '.jpg', 102442, System.Byte[], '7/21/2026 3:45:09 PM');
INSERT INTO dbo.tbl_FileBackup (ID, FolderName, FileName, FullFileName, RelativePath, Extension, FileSize, FileData, BackupDate) VALUES (93, 'MyProducts', 'AS HD 037B.jpg', '9005ab83-cea7-4050-a2f5-a3ba2a5d6225_AS HD 037B.jpg', 'Content\MyProducts\9005ab83-cea7-4050-a2f5-a3ba2a5d6225_AS HD 037B.jpg', '.jpg', 191181, System.Byte[], '7/21/2026 3:45:09 PM');
INSERT INTO dbo.tbl_FileBackup (ID, FolderName, FileName, FullFileName, RelativePath, Extension, FileSize, FileData, BackupDate) VALUES (94, 'MyProducts', 'AS HD 015B.jpg', '99f41577-477c-495b-b2e2-74d18fd3080e_AS HD 015B.jpg', 'Content\MyProducts\99f41577-477c-495b-b2e2-74d18fd3080e_AS HD 015B.jpg', '.jpg', 329063, System.Byte[], '7/21/2026 3:45:09 PM');
INSERT INTO dbo.tbl_FileBackup (ID, FolderName, FileName, FullFileName, RelativePath, Extension, FileSize, FileData, BackupDate) VALUES (95, 'MyProducts', 'AS HD 015A.jpg', '9b653033-5ccb-4a70-9232-ff9130bf32bd_AS HD 015A.jpg', 'Content\MyProducts\9b653033-5ccb-4a70-9232-ff9130bf32bd_AS HD 015A.jpg', '.jpg', 328229, System.Byte[], '7/21/2026 3:45:09 PM');
INSERT INTO dbo.tbl_FileBackup (ID, FolderName, FileName, FullFileName, RelativePath, Extension, FileSize, FileData, BackupDate) VALUES (96, 'MyProducts', 'AS HD 037D.jpg', '9de1b4e4-9adf-41c3-88aa-55c8dab11f89_AS HD 037D.jpg', 'Content\MyProducts\9de1b4e4-9adf-41c3-88aa-55c8dab11f89_AS HD 037D.jpg', '.jpg', 196628, System.Byte[], '7/21/2026 3:45:09 PM');
INSERT INTO dbo.tbl_FileBackup (ID, FolderName, FileName, FullFileName, RelativePath, Extension, FileSize, FileData, BackupDate) VALUES (97, 'MyProducts', 'AS HD 009B.jpg', '9f1146f0-c197-4166-be2a-13e25d213572_AS HD 009B.jpg', 'Content\MyProducts\9f1146f0-c197-4166-be2a-13e25d213572_AS HD 009B.jpg', '.jpg', 480689, System.Byte[], '7/21/2026 3:45:09 PM');
INSERT INTO dbo.tbl_FileBackup (ID, FolderName, FileName, FullFileName, RelativePath, Extension, FileSize, FileData, BackupDate) VALUES (98, 'MyProducts', 'AS HD 039A.jpg', 'a290c5b9-0eff-40b4-a506-91b46e6b609b_AS HD 039A.jpg', 'Content\MyProducts\a290c5b9-0eff-40b4-a506-91b46e6b609b_AS HD 039A.jpg', '.jpg', 253592, System.Byte[], '7/21/2026 3:45:09 PM');
INSERT INTO dbo.tbl_FileBackup (ID, FolderName, FileName, FullFileName, RelativePath, Extension, FileSize, FileData, BackupDate) VALUES (99, 'MyProducts', 'AS HD 035B.jpg', 'a82b075a-783f-43b5-b4a1-3aa185fd2782_AS HD 035B.jpg', 'Content\MyProducts\a82b075a-783f-43b5-b4a1-3aa185fd2782_AS HD 035B.jpg', '.jpg', 113028, System.Byte[], '7/21/2026 3:45:09 PM');
INSERT INTO dbo.tbl_FileBackup (ID, FolderName, FileName, FullFileName, RelativePath, Extension, FileSize, FileData, BackupDate) VALUES (100, 'MyProducts', 'AS HD 068A.jpg', 'aa7e1b55-b9ea-4ba4-ab04-79f2372d960a_AS HD 068A.jpg', 'Content\MyProducts\aa7e1b55-b9ea-4ba4-ab04-79f2372d960a_AS HD 068A.jpg', '.jpg', 194487, System.Byte[], '7/21/2026 3:45:09 PM');
INSERT INTO dbo.tbl_FileBackup (ID, FolderName, FileName, FullFileName, RelativePath, Extension, FileSize, FileData, BackupDate) VALUES (101, 'MyProducts', 'AS HD 026A.jpg', 'aad4ebe7-da15-4806-ae04-28ab84876f8b_AS HD 026A.jpg', 'Content\MyProducts\aad4ebe7-da15-4806-ae04-28ab84876f8b_AS HD 026A.jpg', '.jpg', 200994, System.Byte[], '7/21/2026 3:45:09 PM');
INSERT INTO dbo.tbl_FileBackup (ID, FolderName, FileName, FullFileName, RelativePath, Extension, FileSize, FileData, BackupDate) VALUES (102, 'MyProducts', 'AS HD 009A.jpg', 'abf60e66-3169-451f-af71-0f130a868d11_AS HD 009A.jpg', 'Content\MyProducts\abf60e66-3169-451f-af71-0f130a868d11_AS HD 009A.jpg', '.jpg', 483005, System.Byte[], '7/21/2026 3:45:09 PM');
INSERT INTO dbo.tbl_FileBackup (ID, FolderName, FileName, FullFileName, RelativePath, Extension, FileSize, FileData, BackupDate) VALUES (103, 'MyProducts', 'AS HD 034C.jpg', 'b049c6bd-c52a-4884-9755-257afe7a6a02_AS HD 034C.jpg', 'Content\MyProducts\b049c6bd-c52a-4884-9755-257afe7a6a02_AS HD 034C.jpg', '.jpg', 97434, System.Byte[], '7/21/2026 3:45:09 PM');
INSERT INTO dbo.tbl_FileBackup (ID, FolderName, FileName, FullFileName, RelativePath, Extension, FileSize, FileData, BackupDate) VALUES (104, 'MyProducts', 'AS HD 058A.jpg', 'b0eaaa68-e165-42bd-8b1b-a92e4ac9840b_AS HD 058A.jpg', 'Content\MyProducts\b0eaaa68-e165-42bd-8b1b-a92e4ac9840b_AS HD 058A.jpg', '.jpg', 303984, System.Byte[], '7/21/2026 3:45:09 PM');
INSERT INTO dbo.tbl_FileBackup (ID, FolderName, FileName, FullFileName, RelativePath, Extension, FileSize, FileData, BackupDate) VALUES (105, 'MyProducts', 'AS HD 045A.jpg', 'b1cf7f8a-dfbd-4327-b781-103209d08b9b_AS HD 045A.jpg', 'Content\MyProducts\b1cf7f8a-dfbd-4327-b781-103209d08b9b_AS HD 045A.jpg', '.jpg', 186860, System.Byte[], '7/21/2026 3:45:09 PM');
INSERT INTO dbo.tbl_FileBackup (ID, FolderName, FileName, FullFileName, RelativePath, Extension, FileSize, FileData, BackupDate) VALUES (106, 'MyProducts', 'AS HD 076A.jpg', 'b2a4f41e-a18a-4da5-922b-d67a4518a084_AS HD 076A.jpg', 'Content\MyProducts\b2a4f41e-a18a-4da5-922b-d67a4518a084_AS HD 076A.jpg', '.jpg', 237771, System.Byte[], '7/21/2026 3:45:09 PM');
INSERT INTO dbo.tbl_FileBackup (ID, FolderName, FileName, FullFileName, RelativePath, Extension, FileSize, FileData, BackupDate) VALUES (107, 'MyProducts', 'AS HD 058A.jpg', 'b2bd374c-c2aa-4b8a-ac91-475b4b9a9e2d_AS HD 058A.jpg', 'Content\MyProducts\b2bd374c-c2aa-4b8a-ac91-475b4b9a9e2d_AS HD 058A.jpg', '.jpg', 303984, System.Byte[], '7/21/2026 3:45:09 PM');
INSERT INTO dbo.tbl_FileBackup (ID, FolderName, FileName, FullFileName, RelativePath, Extension, FileSize, FileData, BackupDate) VALUES (108, 'MyProducts', 'AS HD 019A.jpg', 'b44f53ef-a4f2-4f16-bdcf-967a8d476d2c_AS HD 019A.jpg', 'Content\MyProducts\b44f53ef-a4f2-4f16-bdcf-967a8d476d2c_AS HD 019A.jpg', '.jpg', 174474, System.Byte[], '7/21/2026 3:45:09 PM');
INSERT INTO dbo.tbl_FileBackup (ID, FolderName, FileName, FullFileName, RelativePath, Extension, FileSize, FileData, BackupDate) VALUES (109, 'MyProducts', 'AS HD 002B.jpg', 'b589c599-a55a-4efb-947b-eabb47deb6fe_AS HD 002B.jpg', 'Content\MyProducts\b589c599-a55a-4efb-947b-eabb47deb6fe_AS HD 002B.jpg', '.jpg', 479469, System.Byte[], '7/21/2026 3:45:09 PM');
INSERT INTO dbo.tbl_FileBackup (ID, FolderName, FileName, FullFileName, RelativePath, Extension, FileSize, FileData, BackupDate) VALUES (110, 'MyProducts', 'AS HD 022A.jpg', 'b5a83747-4d7a-41db-943f-26f105dd83ec_AS HD 022A.jpg', 'Content\MyProducts\b5a83747-4d7a-41db-943f-26f105dd83ec_AS HD 022A.jpg', '.jpg', 174094, System.Byte[], '7/21/2026 3:45:09 PM');
INSERT INTO dbo.tbl_FileBackup (ID, FolderName, FileName, FullFileName, RelativePath, Extension, FileSize, FileData, BackupDate) VALUES (111, 'MyProducts', 'AS HD 020B.jpg', 'bafe4225-0085-4344-84bb-39ee6aff9bb5_AS HD 020B.jpg', 'Content\MyProducts\bafe4225-0085-4344-84bb-39ee6aff9bb5_AS HD 020B.jpg', '.jpg', 183621, System.Byte[], '7/21/2026 3:45:09 PM');
INSERT INTO dbo.tbl_FileBackup (ID, FolderName, FileName, FullFileName, RelativePath, Extension, FileSize, FileData, BackupDate) VALUES (112, 'MyProducts', 'AS HD 083.jpg', 'bb976a4d-fff2-497d-9067-bbff686e2365_AS HD 083.jpg', 'Content\MyProducts\bb976a4d-fff2-497d-9067-bbff686e2365_AS HD 083.jpg', '.jpg', 167420, System.Byte[], '7/21/2026 3:45:09 PM');
INSERT INTO dbo.tbl_FileBackup (ID, FolderName, FileName, FullFileName, RelativePath, Extension, FileSize, FileData, BackupDate) VALUES (113, 'MyProducts', 'AS HD 084 B.jpg', 'c0645b95-5c80-4f82-826a-cbcbdd92fe45_AS HD 084 B.jpg', 'Content\MyProducts\c0645b95-5c80-4f82-826a-cbcbdd92fe45_AS HD 084 B.jpg', '.jpg', 134437, System.Byte[], '7/21/2026 3:45:09 PM');
INSERT INTO dbo.tbl_FileBackup (ID, FolderName, FileName, FullFileName, RelativePath, Extension, FileSize, FileData, BackupDate) VALUES (114, 'MyProducts', 'AS HD 003A.jpg', 'c5a87391-2a9d-4791-b387-ba36416ad69f_AS HD 003A.jpg', 'Content\MyProducts\c5a87391-2a9d-4791-b387-ba36416ad69f_AS HD 003A.jpg', '.jpg', 370292, System.Byte[], '7/21/2026 3:45:09 PM');
INSERT INTO dbo.tbl_FileBackup (ID, FolderName, FileName, FullFileName, RelativePath, Extension, FileSize, FileData, BackupDate) VALUES (115, 'MyProducts', 'AS HD 006A.jpg', 'c5b66702-c0a7-4a16-a88a-78b1c96e8db9_AS HD 006A.jpg', 'Content\MyProducts\c5b66702-c0a7-4a16-a88a-78b1c96e8db9_AS HD 006A.jpg', '.jpg', 214518, System.Byte[], '7/21/2026 3:45:09 PM');
INSERT INTO dbo.tbl_FileBackup (ID, FolderName, FileName, FullFileName, RelativePath, Extension, FileSize, FileData, BackupDate) VALUES (116, 'MyProducts', 'AS HD 070B.jpg', 'c7e8d5f2-c7b4-428c-8ece-773cf782a694_AS HD 070B.jpg', 'Content\MyProducts\c7e8d5f2-c7b4-428c-8ece-773cf782a694_AS HD 070B.jpg', '.jpg', 107250, System.Byte[], '7/21/2026 3:45:09 PM');
INSERT INTO dbo.tbl_FileBackup (ID, FolderName, FileName, FullFileName, RelativePath, Extension, FileSize, FileData, BackupDate) VALUES (117, 'MyProducts', 'AS HD 052A.jpg', 'c89ad05f-8bf8-45b2-9e06-942badc9e158_AS HD 052A.jpg', 'Content\MyProducts\c89ad05f-8bf8-45b2-9e06-942badc9e158_AS HD 052A.jpg', '.jpg', 167960, System.Byte[], '7/21/2026 3:45:09 PM');
INSERT INTO dbo.tbl_FileBackup (ID, FolderName, FileName, FullFileName, RelativePath, Extension, FileSize, FileData, BackupDate) VALUES (118, 'MyProducts', 'AS HD 011A.jpg', 'cc3b32e3-e747-4c19-91af-c634f39727b5_AS HD 011A.jpg', 'Content\MyProducts\cc3b32e3-e747-4c19-91af-c634f39727b5_AS HD 011A.jpg', '.jpg', 209109, System.Byte[], '7/21/2026 3:45:09 PM');
INSERT INTO dbo.tbl_FileBackup (ID, FolderName, FileName, FullFileName, RelativePath, Extension, FileSize, FileData, BackupDate) VALUES (119, 'MyProducts', 'AS HD 047B.jpg', 'cd453cee-b5f4-475b-8033-44104f6b10b8_AS HD 047B.jpg', 'Content\MyProducts\cd453cee-b5f4-475b-8033-44104f6b10b8_AS HD 047B.jpg', '.jpg', 164608, System.Byte[], '7/21/2026 3:45:09 PM');
INSERT INTO dbo.tbl_FileBackup (ID, FolderName, FileName, FullFileName, RelativePath, Extension, FileSize, FileData, BackupDate) VALUES (120, 'MyProducts', 'AS HD 028B.jpg', 'd05c93a3-c697-4a7d-a51a-97c9ebb8cf70_AS HD 028B.jpg', 'Content\MyProducts\d05c93a3-c697-4a7d-a51a-97c9ebb8cf70_AS HD 028B.jpg', '.jpg', 163182, System.Byte[], '7/21/2026 3:45:09 PM');
INSERT INTO dbo.tbl_FileBackup (ID, FolderName, FileName, FullFileName, RelativePath, Extension, FileSize, FileData, BackupDate) VALUES (121, 'MyProducts', 'AS HD 048A.jpg', 'd13ef849-6f39-4ee6-a709-6ac958f0fb20_AS HD 048A.jpg', 'Content\MyProducts\d13ef849-6f39-4ee6-a709-6ac958f0fb20_AS HD 048A.jpg', '.jpg', 171000, System.Byte[], '7/21/2026 3:45:09 PM');
INSERT INTO dbo.tbl_FileBackup (ID, FolderName, FileName, FullFileName, RelativePath, Extension, FileSize, FileData, BackupDate) VALUES (122, 'MyProducts', 'AS HD 006B.jpg', 'd698ccfb-a11b-42fb-a4d2-dd67a11cd62d_AS HD 006B.jpg', 'Content\MyProducts\d698ccfb-a11b-42fb-a4d2-dd67a11cd62d_AS HD 006B.jpg', '.jpg', 214660, System.Byte[], '7/21/2026 3:45:09 PM');
INSERT INTO dbo.tbl_FileBackup (ID, FolderName, FileName, FullFileName, RelativePath, Extension, FileSize, FileData, BackupDate) VALUES (123, 'MyProducts', 'AS HD 060A.jpg', 'd7f83126-cf17-491d-b4f3-104ab5610f27_AS HD 060A.jpg', 'Content\MyProducts\d7f83126-cf17-491d-b4f3-104ab5610f27_AS HD 060A.jpg', '.jpg', 259903, System.Byte[], '7/21/2026 3:45:09 PM');
INSERT INTO dbo.tbl_FileBackup (ID, FolderName, FileName, FullFileName, RelativePath, Extension, FileSize, FileData, BackupDate) VALUES (124, 'MyProducts', 'AS HD 037A.jpg', 'dbcd1c40-b103-4494-95a0-56fc1af7a5e1_AS HD 037A.jpg', 'Content\MyProducts\dbcd1c40-b103-4494-95a0-56fc1af7a5e1_AS HD 037A.jpg', '.jpg', 190509, System.Byte[], '7/21/2026 3:45:09 PM');
INSERT INTO dbo.tbl_FileBackup (ID, FolderName, FileName, FullFileName, RelativePath, Extension, FileSize, FileData, BackupDate) VALUES (125, 'MyProducts', 'AS HD 053A.jpg', 'df90a281-1a6f-4a17-be02-1992cd44f5c2_AS HD 053A.jpg', 'Content\MyProducts\df90a281-1a6f-4a17-be02-1992cd44f5c2_AS HD 053A.jpg', '.jpg', 181908, System.Byte[], '7/21/2026 3:45:09 PM');
INSERT INTO dbo.tbl_FileBackup (ID, FolderName, FileName, FullFileName, RelativePath, Extension, FileSize, FileData, BackupDate) VALUES (126, 'MyProducts', 'AS HD 013A.jpg', 'e0c06431-e8ad-4b5f-8291-e8a8c737ecc0_AS HD 013A.jpg', 'Content\MyProducts\e0c06431-e8ad-4b5f-8291-e8a8c737ecc0_AS HD 013A.jpg', '.jpg', 239716, System.Byte[], '7/21/2026 3:45:09 PM');
INSERT INTO dbo.tbl_FileBackup (ID, FolderName, FileName, FullFileName, RelativePath, Extension, FileSize, FileData, BackupDate) VALUES (127, 'MyProducts', 'AS HD 032A.jpg', 'e162b70e-0486-41c1-b2dd-3d08252df6a0_AS HD 032A.jpg', 'Content\MyProducts\e162b70e-0486-41c1-b2dd-3d08252df6a0_AS HD 032A.jpg', '.jpg', 175251, System.Byte[], '7/21/2026 3:45:09 PM');
INSERT INTO dbo.tbl_FileBackup (ID, FolderName, FileName, FullFileName, RelativePath, Extension, FileSize, FileData, BackupDate) VALUES (128, 'MyProducts', 'AS HD 036C.jpg', 'e1a9498f-f986-414f-8ec5-976766ca4ba3_AS HD 036C.jpg', 'Content\MyProducts\e1a9498f-f986-414f-8ec5-976766ca4ba3_AS HD 036C.jpg', '.jpg', 161143, System.Byte[], '7/21/2026 3:45:09 PM');
INSERT INTO dbo.tbl_FileBackup (ID, FolderName, FileName, FullFileName, RelativePath, Extension, FileSize, FileData, BackupDate) VALUES (129, 'MyProducts', 'AS HD 025A.jpg', 'e4c774ed-83f7-42ce-8a43-fcf501e01a7c_AS HD 025A.jpg', 'Content\MyProducts\e4c774ed-83f7-42ce-8a43-fcf501e01a7c_AS HD 025A.jpg', '.jpg', 265820, System.Byte[], '7/21/2026 3:45:09 PM');
INSERT INTO dbo.tbl_FileBackup (ID, FolderName, FileName, FullFileName, RelativePath, Extension, FileSize, FileData, BackupDate) VALUES (130, 'MyProducts', 'AS HD 034B.jpg', 'e62b5ff3-9f76-4d38-ab72-7743438854e2_AS HD 034B.jpg', 'Content\MyProducts\e62b5ff3-9f76-4d38-ab72-7743438854e2_AS HD 034B.jpg', '.jpg', 94756, System.Byte[], '7/21/2026 3:45:09 PM');
INSERT INTO dbo.tbl_FileBackup (ID, FolderName, FileName, FullFileName, RelativePath, Extension, FileSize, FileData, BackupDate) VALUES (131, 'MyProducts', 'AS HD 002A.jpg', 'e9938272-eeca-4f5a-9c69-45a56bde31e5_AS HD 002A.jpg', 'Content\MyProducts\e9938272-eeca-4f5a-9c69-45a56bde31e5_AS HD 002A.jpg', '.jpg', 479379, System.Byte[], '7/21/2026 3:45:09 PM');
INSERT INTO dbo.tbl_FileBackup (ID, FolderName, FileName, FullFileName, RelativePath, Extension, FileSize, FileData, BackupDate) VALUES (132, 'MyProducts', 'AS HD 003B.jpg', 'e9c23f47-629d-4321-a544-86e0a55422cd_AS HD 003B.jpg', 'Content\MyProducts\e9c23f47-629d-4321-a544-86e0a55422cd_AS HD 003B.jpg', '.jpg', 372590, System.Byte[], '7/21/2026 3:45:09 PM');
INSERT INTO dbo.tbl_FileBackup (ID, FolderName, FileName, FullFileName, RelativePath, Extension, FileSize, FileData, BackupDate) VALUES (133, 'MyProducts', 'AS HD 001A.jpg', 'e9c8720c-5a89-4860-acc4-2b34617dea18_AS HD 001A.jpg', 'Content\MyProducts\e9c8720c-5a89-4860-acc4-2b34617dea18_AS HD 001A.jpg', '.jpg', 421319, System.Byte[], '7/21/2026 3:45:09 PM');
INSERT INTO dbo.tbl_FileBackup (ID, FolderName, FileName, FullFileName, RelativePath, Extension, FileSize, FileData, BackupDate) VALUES (134, 'MyProducts', 'AS HD 029B.jpg', 'ee80421f-f2ac-4901-84bd-6899d6c6cd7e_AS HD 029B.jpg', 'Content\MyProducts\ee80421f-f2ac-4901-84bd-6899d6c6cd7e_AS HD 029B.jpg', '.jpg', 185886, System.Byte[], '7/21/2026 3:45:09 PM');
INSERT INTO dbo.tbl_FileBackup (ID, FolderName, FileName, FullFileName, RelativePath, Extension, FileSize, FileData, BackupDate) VALUES (135, 'MyProducts', 'AS HD 070A.jpg', 'eede6968-83b7-487a-9e98-18a3e50f957b_AS HD 070A.jpg', 'Content\MyProducts\eede6968-83b7-487a-9e98-18a3e50f957b_AS HD 070A.jpg', '.jpg', 107864, System.Byte[], '7/21/2026 3:45:09 PM');
INSERT INTO dbo.tbl_FileBackup (ID, FolderName, FileName, FullFileName, RelativePath, Extension, FileSize, FileData, BackupDate) VALUES (136, 'MyProducts', 'AS HD 066A.jpg', 'f1c82867-8e5f-490c-9290-449bf9e68e25_AS HD 066A.jpg', 'Content\MyProducts\f1c82867-8e5f-490c-9290-449bf9e68e25_AS HD 066A.jpg', '.jpg', 298061, System.Byte[], '7/21/2026 3:45:09 PM');
INSERT INTO dbo.tbl_FileBackup (ID, FolderName, FileName, FullFileName, RelativePath, Extension, FileSize, FileData, BackupDate) VALUES (137, 'MyProducts', 'AS HD 036A.jpg', 'f554eff7-bf39-448f-8c78-f804e6a68e87_AS HD 036A.jpg', 'Content\MyProducts\f554eff7-bf39-448f-8c78-f804e6a68e87_AS HD 036A.jpg', '.jpg', 157328, System.Byte[], '7/21/2026 3:45:09 PM');
INSERT INTO dbo.tbl_FileBackup (ID, FolderName, FileName, FullFileName, RelativePath, Extension, FileSize, FileData, BackupDate) VALUES (138, 'MyProducts', 'AS HD 051A.jpg', 'f5563b86-b30c-4d0c-8754-7f5276e9b48a_AS HD 051A.jpg', 'Content\MyProducts\f5563b86-b30c-4d0c-8754-7f5276e9b48a_AS HD 051A.jpg', '.jpg', 166817, System.Byte[], '7/21/2026 3:45:09 PM');
INSERT INTO dbo.tbl_FileBackup (ID, FolderName, FileName, FullFileName, RelativePath, Extension, FileSize, FileData, BackupDate) VALUES (139, 'MyProducts', 'AS HD 024A.jpg', 'f70991ee-7233-450c-85cb-0f9776c947b9_AS HD 024A.jpg', 'Content\MyProducts\f70991ee-7233-450c-85cb-0f9776c947b9_AS HD 024A.jpg', '.jpg', 133985, System.Byte[], '7/21/2026 3:45:09 PM');
INSERT INTO dbo.tbl_FileBackup (ID, FolderName, FileName, FullFileName, RelativePath, Extension, FileSize, FileData, BackupDate) VALUES (140, 'MyProducts', 'AS HD 044A.jpg', 'f8cf0809-c424-4a6c-85b1-b59da9261ff8_AS HD 044A.jpg', 'Content\MyProducts\f8cf0809-c424-4a6c-85b1-b59da9261ff8_AS HD 044A.jpg', '.jpg', 230661, System.Byte[], '7/21/2026 3:45:09 PM');
INSERT INTO dbo.tbl_FileBackup (ID, FolderName, FileName, FullFileName, RelativePath, Extension, FileSize, FileData, BackupDate) VALUES (141, 'MyProducts', 'AS HD 014A.jpg', 'fdf467a6-30f5-414b-9935-4f98475cb306_AS HD 014A.jpg', 'Content\MyProducts\fdf467a6-30f5-414b-9935-4f98475cb306_AS HD 014A.jpg', '.jpg', 427118, System.Byte[], '7/21/2026 3:45:09 PM');

SET IDENTITY_INSERT dbo.tbl_FileBackup OFF;


-- Structure for table [DB_AcryshadeLaminatesTestAWS].[dbo].[tbl_MachineBreakDown]
SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
CREATE TABLE [dbo].[tbl_MachineBreakDown](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[MachineID] [nvarchar](200) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[AssignedWorkOrdersIds] [nvarchar](max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[BDStatus] [bit] NULL,
	[BDReason] [nvarchar](max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[BDDate] [datetime] NULL,
	[BDTime] [time](7) NULL,
	[CreatedBy] [nvarchar](max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]


-- Data for table [DB_AcryshadeLaminatesTestAWS].[dbo].[tbl_MachineBreakDown]
SET IDENTITY_INSERT dbo.tbl_MachineBreakDown ON;

INSERT INTO dbo.tbl_MachineBreakDown (ID, MachineID, AssignedWorkOrdersIds, BDStatus, BDReason, BDDate, BDTime, CreatedBy) VALUES (1, '2', '1', 0, 'test', '7/25/2026 11:54:46 AM', 11:54:46.1600000, '1');
INSERT INTO dbo.tbl_MachineBreakDown (ID, MachineID, AssignedWorkOrdersIds, BDStatus, BDReason, BDDate, BDTime, CreatedBy) VALUES (2, '2', '1', 1, '', '7/25/2026 12:08:53 PM', 12:08:53.9500000, '1');
INSERT INTO dbo.tbl_MachineBreakDown (ID, MachineID, AssignedWorkOrdersIds, BDStatus, BDReason, BDDate, BDTime, CreatedBy) VALUES (3, '2', '1', 0, 'Machine not working properly it is making noise', '7/25/2026 12:09:31 PM', 12:09:31.0830000, '1');
INSERT INTO dbo.tbl_MachineBreakDown (ID, MachineID, AssignedWorkOrdersIds, BDStatus, BDReason, BDDate, BDTime, CreatedBy) VALUES (4, '1', '', 0, 'Machine is Not working Machine is Not working Machine is Not working Machine is Not working', '7/25/2026 12:11:02 PM', 12:11:02.8570000, '1');

SET IDENTITY_INSERT dbo.tbl_MachineBreakDown OFF;


-- Structure for table [DB_AcryshadeLaminatesTestAWS].[dbo].[tbl_MachineCapacityLog]
SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
CREATE TABLE [dbo].[tbl_MachineCapacityLog](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[MachineID] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[MachinePerHRCap] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[MachineHRQt] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[CreatedOn] [datetime] NULL,
	[CreatedBy] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]


-- Data for table [DB_AcryshadeLaminatesTestAWS].[dbo].[tbl_MachineCapacityLog]
SET IDENTITY_INSERT dbo.tbl_MachineCapacityLog ON;


SET IDENTITY_INSERT dbo.tbl_MachineCapacityLog OFF;


-- Structure for table [DB_AcryshadeLaminatesTestAWS].[dbo].[tbl_MachineMaster]
SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
CREATE TABLE [dbo].[tbl_MachineMaster](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[MachineName] [nvarchar](max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[MachineDescription] [nvarchar](max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[MachinePerHRQty] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[MachineRunningHR] [nvarchar](10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[AllocatedStage] [nvarchar](10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[IsActive] [bit] NULL,
	[IsActivateDate] [datetime] NULL,
	[IsDeactiveDate] [datetime] NULL,
	[IsDeleted] [bit] NULL,
	[CreatedBy] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[CreatedOn] [datetime] NULL,
	[UpdatedBy] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[UpdatedOn] [datetime] NULL,
	[MachineImageName] [nvarchar](max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]


-- Data for table [DB_AcryshadeLaminatesTestAWS].[dbo].[tbl_MachineMaster]
SET IDENTITY_INSERT dbo.tbl_MachineMaster ON;

INSERT INTO dbo.tbl_MachineMaster (ID, MachineName, MachineDescription, MachinePerHRQty, MachineRunningHR, AllocatedStage, IsActive, IsActivateDate, IsDeactiveDate, IsDeleted, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, MachineImageName) VALUES (1, 'Machine 1 (Texture)', 'Creates Texture', '120', '9', 'Stage 1', 1, '7/1/2026 10:34:34 AM', NULL, 0, '1', '7/1/2026 10:34:34 AM', '1', '7/17/2026 4:38:29 PM', '~/MachineImages/41dd3661-1763-4c4a-935a-549aa9a9bad0_images.jfif');
INSERT INTO dbo.tbl_MachineMaster (ID, MachineName, MachineDescription, MachinePerHRQty, MachineRunningHR, AllocatedStage, IsActive, IsActivateDate, IsDeactiveDate, IsDeleted, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, MachineImageName) VALUES (2, 'Machine 2 (Texture)', 'Creates Texture', '30', '8', 'Stage 1', 1, '7/1/2026 10:40:17 AM', NULL, 0, '1', '7/1/2026 10:40:17 AM', '1', '7/17/2026 4:37:57 PM', '');
INSERT INTO dbo.tbl_MachineMaster (ID, MachineName, MachineDescription, MachinePerHRQty, MachineRunningHR, AllocatedStage, IsActive, IsActivateDate, IsDeactiveDate, IsDeleted, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, MachineImageName) VALUES (3, 'Machine 1 (Painting)', 'Creates Paints', '90', '8', 'Stage 2', 1, '7/1/2026 10:40:48 AM', NULL, 0, '1', '7/1/2026 10:40:48 AM', '1', '7/17/2026 4:38:12 PM', '');
INSERT INTO dbo.tbl_MachineMaster (ID, MachineName, MachineDescription, MachinePerHRQty, MachineRunningHR, AllocatedStage, IsActive, IsActivateDate, IsDeactiveDate, IsDeleted, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, MachineImageName) VALUES (4, 'Machine 2 (Painting)', 'Testing', '120', '8', 'Stage 2', 1, '7/17/2026 5:07:56 PM', NULL, 1, '1', '7/17/2026 5:07:56 PM', NULL, NULL, NULL);

SET IDENTITY_INSERT dbo.tbl_MachineMaster OFF;


-- Structure for table [DB_AcryshadeLaminatesTestAWS].[dbo].[tbl_MachineProductionAllocation]
SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
CREATE TABLE [dbo].[tbl_MachineProductionAllocation](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[ProductDtlID] [nvarchar](max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[MachineID] [nvarchar](max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[AllocatedQty] [nvarchar](max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[AllocatedSqFeet] [nvarchar](max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[CompletedQty] [nvarchar](max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[CompletedSqFeet] [nvarchar](max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[CompletedDate] [datetime] NULL,
	[NextStageId] [nvarchar](max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[RevertQty] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[PackagingQty] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[PackagingDate] [datetime] NULL,
	[PackagingRevertQty] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[StageName] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]


-- Data for table [DB_AcryshadeLaminatesTestAWS].[dbo].[tbl_MachineProductionAllocation]
SET IDENTITY_INSERT dbo.tbl_MachineProductionAllocation ON;

INSERT INTO dbo.tbl_MachineProductionAllocation (ID, ProductDtlID, MachineID, AllocatedQty, AllocatedSqFeet, CompletedQty, CompletedSqFeet, CompletedDate, NextStageId, RevertQty, PackagingQty, PackagingDate, PackagingRevertQty, StageName) VALUES (1, '1', '2', '10', '320', '10', '320', '7/25/2026 10:11:59 AM', NULL, NULL, NULL, NULL, NULL, 'Stage 1');
INSERT INTO dbo.tbl_MachineProductionAllocation (ID, ProductDtlID, MachineID, AllocatedQty, AllocatedSqFeet, CompletedQty, CompletedSqFeet, CompletedDate, NextStageId, RevertQty, PackagingQty, PackagingDate, PackagingRevertQty, StageName) VALUES (2, '1', '3', '10', '320', '3', '96', NULL, '1', NULL, NULL, NULL, NULL, 'Stage 2');

SET IDENTITY_INSERT dbo.tbl_MachineProductionAllocation OFF;


-- Structure for table [DB_AcryshadeLaminatesTestAWS].[dbo].[tbl_MachineProductionDTLS]
SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
CREATE TABLE [dbo].[tbl_MachineProductionDTLS](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[HeaderID] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[ProductName] [nvarchar](max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Size] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[TotalQty] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[SqFeet] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[AllocatedQty] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[AllocatedSqFeet] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Stage1MachineID] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Stage1CompletedQty] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Stage1CompetedSqFeet] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Stage1CompletedDate] [datetime] NULL,
	[Stage2MachineID] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Stage2CompletedQty] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Stage2CompetedSqFeet] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Stage2CompletedDate] [datetime] NULL,
 CONSTRAINT [PK__tbl_Mach__3214EC2792253968] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]


-- Data for table [DB_AcryshadeLaminatesTestAWS].[dbo].[tbl_MachineProductionDTLS]
SET IDENTITY_INSERT dbo.tbl_MachineProductionDTLS ON;

INSERT INTO dbo.tbl_MachineProductionDTLS (ID, HeaderID, ProductName, Size, TotalQty, SqFeet, AllocatedQty, AllocatedSqFeet, Stage1MachineID, Stage1CompletedQty, Stage1CompetedSqFeet, Stage1CompletedDate, Stage2MachineID, Stage2CompletedQty, Stage2CompetedSqFeet, Stage2CompletedDate) VALUES (1, '1', 'AS HD 044(A) Textura Sheet', '8x4', '10', '320', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

SET IDENTITY_INSERT dbo.tbl_MachineProductionDTLS OFF;


-- Structure for table [DB_AcryshadeLaminatesTestAWS].[dbo].[tbl_MachineProductionHDR]
SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
CREATE TABLE [dbo].[tbl_MachineProductionHDR](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[WorkOrderID] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[WorkOrderNo] [nvarchar](200) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[RankSrNo] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[AssignedDate] [date] NULL,
	[S1Status] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[S2Status] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[PackagingStatus] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[PackagingFinalDate] [datetime] NULL,
 CONSTRAINT [PK__tbl_Mach__3214EC279B240748] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]


-- Data for table [DB_AcryshadeLaminatesTestAWS].[dbo].[tbl_MachineProductionHDR]
SET IDENTITY_INSERT dbo.tbl_MachineProductionHDR ON;

INSERT INTO dbo.tbl_MachineProductionHDR (ID, WorkOrderID, WorkOrderNo, RankSrNo, AssignedDate, S1Status, S2Status, PackagingStatus, PackagingFinalDate) VALUES (1, '1', 'WO/2026-27/001', NULL, '7/25/2026 12:00:00 AM', 'Completed', NULL, NULL, NULL);

SET IDENTITY_INSERT dbo.tbl_MachineProductionHDR OFF;


-- Structure for table [DB_AcryshadeLaminatesTestAWS].[dbo].[tbl_MachineReturnQtyLogs]
SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
CREATE TABLE [dbo].[tbl_MachineReturnQtyLogs](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[DetailsID] [nvarchar](max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Mistaken] [nvarchar](max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Faulty] [nvarchar](max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[reason] [nvarchar](max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[CreatedDate] [datetime] NULL,
	[RevertedFrom] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[RevertedBy] [nvarchar](200) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]


-- Data for table [DB_AcryshadeLaminatesTestAWS].[dbo].[tbl_MachineReturnQtyLogs]
SET IDENTITY_INSERT dbo.tbl_MachineReturnQtyLogs ON;


SET IDENTITY_INSERT dbo.tbl_MachineReturnQtyLogs OFF;


-- Structure for table [DB_AcryshadeLaminatesTestAWS].[dbo].[tbl_ProdcutMaster]
SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
CREATE TABLE [dbo].[tbl_ProdcutMaster](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[Productcode] [nvarchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[ProductCategory] [nvarchar](500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Productname] [nvarchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Thickness] [nchar](10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[PartNo] [nvarchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[PartName] [nvarchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Size] [nvarchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[ImagenamePath] [nvarchar](500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[IsActive] [bit] NULL,
	[isdeleted] [bit] NULL,
	[Createdon] [datetime] NULL,
	[CreatedBy] [nvarchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[UpdatedBy] [nvarchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[UpdatedOn] [datetime] NULL,
	[FavoriteProduct] [bit] NULL,
	[FavoriteProductRank] [int] NULL,
 CONSTRAINT [PK_tbl_prodcutmaster_1] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]


-- Data for table [DB_AcryshadeLaminatesTestAWS].[dbo].[tbl_ProdcutMaster]
SET IDENTITY_INSERT dbo.tbl_ProdcutMaster ON;

INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (1, 'P001', 'Textura Sheet', 'AS HD 001(A) Textura Sheet', '          ', '', '', '8x2', '~/MyProducts/e9c8720c-5a89-4860-acc4-2b34617dea18_AS HD 001A.jpg', 1, 0, '7/6/2026 12:22:51 PM', '1', '1', '7/21/2026 3:05:09 PM', NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (2, 'P002', 'Textura Sheet', 'AS HD 001(B) Textura Sheet', '          ', '', '', '8x2', '~/MyProducts/17f77871-b949-4608-b0ef-18478cac855e_AS HD 001B.jpg', 1, 0, '7/6/2026 12:23:12 PM', '1', '1', '7/21/2026 3:05:42 PM', NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (3, 'P003', 'Textura Sheet', 'AS HD 002(A) Textura Sheet', '          ', '', '', '8x2', '~/MyProducts/e9938272-eeca-4f5a-9c69-45a56bde31e5_AS HD 002A.jpg', 1, 0, '7/6/2026 12:25:04 PM', '1', '1', '7/21/2026 3:06:13 PM', NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (4, 'P004', 'Textura Sheet', 'AS HD 002(B) Textura Sheet', '          ', '', '', '8x2', '~/MyProducts/b589c599-a55a-4efb-947b-eabb47deb6fe_AS HD 002B.jpg', 1, 0, '7/6/2026 12:25:33 PM', '1', '1', '7/21/2026 3:07:46 PM', NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (5, 'P005', 'Textura Sheet', 'AS HD 003(A) Textura Sheet', '          ', '', '', '8x2', '~/MyProducts/c5a87391-2a9d-4791-b387-ba36416ad69f_AS HD 003A.jpg', 1, 0, '7/6/2026 12:25:57 PM', '1', '1', '7/21/2026 3:08:19 PM', NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (6, 'P006', 'Textura Sheet', 'AS HD 003(B) Textura Sheet', '          ', '', '', '8x2', '~/MyProducts/e9c23f47-629d-4321-a544-86e0a55422cd_AS HD 003B.jpg', 1, 0, '7/6/2026 12:26:17 PM', '1', '1', '7/21/2026 3:08:46 PM', NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (7, 'P007', 'Textura Sheet', 'AS HD 004(A) Textura Sheet', '          ', '', '', '8x2', '~/MyProducts/820830fb-e7b7-4708-8eb8-41429fe2158b_AS HD 004A.jpg', 1, 0, '7/6/2026 12:26:48 PM', '1', '1', '7/21/2026 3:09:13 PM', NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (8, 'P008', 'Textura Sheet', 'AS HD 004(B) Textura Sheet', '          ', '', '', '8x2', '~/MyProducts/1a0614a2-3f61-4219-92eb-58665d16e677_AS HD 004B.jpg', 1, 0, '7/6/2026 12:27:07 PM', '1', '1', '7/21/2026 3:09:39 PM', NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (9, 'P009', 'Textura Sheet', 'AS HD 005(A) Textura Sheet', '          ', '', '', '8x2', '~/MyProducts/53bf55c7-8f2a-40bd-817c-fb5c3e292413_AS HD 005A.jpg', 1, 0, '7/6/2026 12:27:28 PM', '1', '1', '7/21/2026 3:10:05 PM', NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (10, 'P010', 'Textura Sheet', 'AS HD 005(B) Textura Sheet', '          ', '', '', '8x2', '~/MyProducts/2347b4ba-5ce0-435e-9b64-77166bc432a3_AS HD 005B.jpg', 1, 0, '7/6/2026 12:27:47 PM', '1', '1', '7/21/2026 3:10:34 PM', NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (11, 'P011', 'Textura Sheet', 'AS HD 006(A) Textura Sheet', '          ', '', '', '8x2', '~/MyProducts/c5b66702-c0a7-4a16-a88a-78b1c96e8db9_AS HD 006A.jpg', 1, 0, '7/6/2026 12:28:06 PM', '1', '1', '7/21/2026 3:11:04 PM', NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (12, 'P012', 'Textura Sheet', 'AS HD 006(B) Textura Sheet', '          ', '', '', '8x2', '~/MyProducts/d698ccfb-a11b-42fb-a4d2-dd67a11cd62d_AS HD 006B.jpg', 1, 0, '7/6/2026 12:28:23 PM', '1', '1', '7/21/2026 3:11:26 PM', NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (13, 'P013', 'Textura Sheet', 'AS HD 007(A) Textura Sheet', '          ', '', '', '8x2', '~/MyProducts/5d91818f-25fc-4688-b316-b988091154e6_AS HD 007A.jpg', 1, 0, '7/6/2026 12:28:47 PM', '1', '1', '7/21/2026 3:12:27 PM', NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (14, 'P014', 'Textura Sheet', 'AS HD 007(B) Textura Sheet', '          ', '', '', '8x2', '~/MyProducts/47a9ae51-86ca-4975-866f-bae39655e92b_AS HD 007B.jpg', 1, 0, '7/6/2026 12:29:08 PM', '1', '1', '7/21/2026 3:12:54 PM', NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (15, 'P015', 'Textura Sheet', 'AS HD 008(A) Textura Sheet', '          ', '', '', '8x2', '~/MyProducts/0e2ec31d-584b-477c-9459-af22bcc99371_AS HD 008A.jpg', 1, 0, '7/6/2026 12:29:28 PM', '1', '1', '7/21/2026 3:15:20 PM', NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (16, 'P016', 'Textura Sheet', 'AS HD 008(B) Textura Sheet', '          ', '', '', '8x2', '~/MyProducts/442d7ba5-e73e-4119-b795-896a0731bf36_AS HD 008B.jpg', 1, 0, '7/6/2026 12:29:46 PM', '1', '1', '7/21/2026 3:15:44 PM', NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (17, 'P017', 'Textura Sheet', 'AS HD 009(A) Textura Sheet', '          ', '', '', '8x2', '~/MyProducts/abf60e66-3169-451f-af71-0f130a868d11_AS HD 009A.jpg', 1, 0, '7/6/2026 12:30:21 PM', '1', '1', '7/21/2026 3:16:10 PM', NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (18, 'P018', 'Textura Sheet', 'AS HD 009(B) Textura Sheet', '          ', '', '', '8x2', '~/MyProducts/9f1146f0-c197-4166-be2a-13e25d213572_AS HD 009B.jpg', 1, 0, '7/6/2026 12:31:01 PM', '1', '1', '7/21/2026 3:16:33 PM', NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (19, 'P019', 'Textura Sheet', 'AS HD 010(A) Textura Sheet', '          ', '', '', '8x2', '~/MyProducts/3f5bb052-ec3f-469e-b0dc-caafb7aafe48_AS HD 010A.jpg', 1, 0, '7/6/2026 12:31:21 PM', '1', '1', '7/21/2026 3:16:58 PM', NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (20, 'P020', 'Textura Sheet', 'AS HD 010(B) Textura Sheet', '          ', '', '', '8x2', '~/MyProducts/5822b8a2-8e41-4957-b0a1-9040c32bf89d_AS HD 010B.jpg', 1, 0, '7/6/2026 12:31:40 PM', '1', '1', '7/21/2026 3:17:23 PM', NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (21, 'P021', 'Textura Sheet', 'AS HD 011(A) Textura Sheet', '          ', '', '', '8x2', '~/MyProducts/cc3b32e3-e747-4c19-91af-c634f39727b5_AS HD 011A.jpg', 1, 0, '7/6/2026 12:31:58 PM', '1', '1', '7/21/2026 3:17:45 PM', NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (22, 'P022', 'Textura Sheet', 'AS HD 011(B) Textura Sheet', '          ', '', '', '8x2', '~/MyProducts/724546af-3e3e-4ccb-a63d-9903f98520c6_AS HD 011B.jpg', 1, 0, '7/6/2026 12:32:23 PM', '1', '1', '7/21/2026 3:18:07 PM', NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (23, 'P023', 'Textura Sheet', 'AS HD 012(A) Textura Sheet', '          ', '', '', '8x2', '~/MyProducts/2fe8bd7f-5baa-40ec-8451-26eea499a551_AS HD 012A.jpg', 1, 0, '7/6/2026 12:32:43 PM', '1', '1', '7/21/2026 3:18:31 PM', NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (24, 'P024', 'Textura Sheet', 'AS HD 012(B) Textura Sheet', '          ', '', '', '8x2', '~/MyProducts/7ff1382c-ea61-47b8-bfb0-342d7fed7e10_AS HD 012B.jpg', 1, 0, '7/6/2026 12:33:02 PM', '1', '1', '7/21/2026 3:18:59 PM', NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (25, 'P025', 'Textura Sheet', 'AS HD 013(A) Textura Sheet', '          ', '', '', '8x2', '~/MyProducts/e0c06431-e8ad-4b5f-8291-e8a8c737ecc0_AS HD 013A.jpg', 1, 0, '7/6/2026 3:53:52 PM', '1', '1', '7/21/2026 3:19:24 PM', NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (26, 'P026', 'Textura Sheet', 'AS HD 013(B) Textura Sheet', '          ', '', '', '8x2', '~/MyProducts/296a4122-bc4c-4c55-82fe-24e7de9f2e41_AS HD 013B.jpg', 1, 0, '7/6/2026 3:54:09 PM', '1', '1', '7/21/2026 3:19:47 PM', NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (27, 'P027', 'Textura Sheet', 'AS HD 014(A) Textura Sheet', '          ', '', '', '8x2', '~/MyProducts/fdf467a6-30f5-414b-9935-4f98475cb306_AS HD 014A.jpg', 1, 0, '7/6/2026 3:54:28 PM', '1', '1', '7/21/2026 3:20:52 PM', NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (28, 'P028', 'Textura Sheet', 'AS HD 014(B) Textura Sheet', '          ', '', '', '8x2', '~/MyProducts/4c944651-9732-4077-80aa-4e2a30763f44_AS HD 014B.jpg', 1, 0, '7/6/2026 3:54:42 PM', '1', '1', '7/6/2026 5:54:09 PM', NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (29, 'P029', 'Textura Sheet', 'AS HD 015(A) Textura Sheet', '          ', '', '', '8x2', '~/MyProducts/9b653033-5ccb-4a70-9232-ff9130bf32bd_AS HD 015A.jpg', 1, 0, '7/6/2026 3:54:59 PM', '1', '1', '7/6/2026 5:27:37 PM', NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (30, 'P030', 'Textura Sheet', 'AS HD 015(B) Textura Sheet', '          ', '', '', '8x2', '~/MyProducts/99f41577-477c-495b-b2e2-74d18fd3080e_AS HD 015B.jpg', 1, 0, '7/6/2026 3:55:09 PM', '1', '1', '7/6/2026 5:27:06 PM', NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (31, 'P031', 'Textura Sheet', 'AS HD 016(A) Textura Sheet', '          ', '', '', '8x4', '~/MyProducts/2ed2a9dc-f2ca-4b26-ba57-61bebabfee10_AS HD 016A.jpg', 1, 0, '7/6/2026 3:55:29 PM', '1', '1', '7/6/2026 5:26:30 PM', NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (32, 'P032', 'Textura Sheet', 'AS HD 016(B) Textura Sheet', '          ', '', '', '8x4', '~/MyProducts/044e251d-757a-4e8e-9f04-46fd0db70dcf_AS HD 016B.jpg', 1, 0, '7/6/2026 3:55:44 PM', '1', '1', '7/6/2026 5:25:08 PM', NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (33, 'P033', 'Textura Sheet', 'AS HD 017(A) Textura Sheet', '          ', '', '', '8x4', '~/MyProducts/404478b4-22f8-4e45-9c59-e41f85dd8b98_AS HD 017A.jpg', 1, 0, '7/6/2026 3:56:11 PM', '1', '1', '7/6/2026 5:24:18 PM', NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (34, 'P034', 'Textura Sheet', 'AS HD 018(A) Textura Sheet', '          ', '', '', '8x4', '~/MyProducts/1b7b68d4-0c23-48ee-8a06-fddad7a13490_AS HD 018A.jpg', 1, 0, '7/6/2026 5:53:00 PM', '1', NULL, NULL, NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (35, 'P035', 'Textura Sheet', 'AS HD 018(B) Textura Sheet', '          ', '', '', '8x4', '~/MyProducts/4da3a31c-8232-425e-aca9-756ae574cba2_AS HD 018B.jpg', 1, 0, '7/6/2026 6:10:58 PM', '1', NULL, NULL, NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (36, 'P036', 'Textura Sheet', 'AS HD 017(B) Textura Sheet', '          ', '', '', '8x4', '~/MyProducts/57ba0741-4fcc-42c8-a04f-e135b1538d57_AS HD 017B.jpg', 1, 0, '7/6/2026 6:11:58 PM', '1', NULL, NULL, NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (37, 'P037', 'Textura Sheet', 'AS HD 019(A) Textura Sheet', '          ', '', '', '8x4', '~/MyProducts/b44f53ef-a4f2-4f16-bdcf-967a8d476d2c_AS HD 019A.jpg', 1, 0, '7/6/2026 6:17:15 PM', '1', NULL, NULL, NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (38, 'P038', 'Textura Sheet', 'AS HD 019(B) Textura Sheet', '          ', '', '', '8x4', '~/MyProducts/3ba396f5-dfa4-4a4a-8705-6ac15054edeb_AS HD 019B.jpg', 1, 0, '7/6/2026 6:18:00 PM', '1', NULL, NULL, NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (39, 'P039', 'Textura Sheet', 'AS HD 020(A) Textura Sheet', '          ', '', '', '8x4', '~/MyProducts/5b30f378-1e62-4ae7-ae97-0d3ad6249ebb_AS HD 020A.jpg', 1, 0, '7/6/2026 6:19:04 PM', '1', NULL, NULL, NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (40, 'P040', 'Textura Sheet', 'AS HD 020(B) Textura Sheet', '          ', '', '', '8x4', '~/MyProducts/bafe4225-0085-4344-84bb-39ee6aff9bb5_AS HD 020B.jpg', 1, 0, '7/6/2026 6:20:18 PM', '1', NULL, NULL, NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (41, 'P041', 'Textura Sheet', 'AS HD 022(A) Textura Sheet', '          ', '', '', '8x4', '~/MyProducts/b5a83747-4d7a-41db-943f-26f105dd83ec_AS HD 022A.jpg', 1, 0, '7/6/2026 6:22:49 PM', '1', NULL, NULL, NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (42, 'P042', 'Textura Sheet', 'AS HD 023(A) Textura Sheet', '          ', '', '', '8x4', '~/MyProducts/1cede658-bf7c-4243-94be-850c9cedf264_AS HD 023A.jpg', 1, 0, '7/6/2026 6:51:44 PM', '1', NULL, NULL, NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (43, 'P043', 'Textura Sheet', 'AS HD 024(A) Textura Sheet', '          ', '', '', '8x4', '~/MyProducts/f70991ee-7233-450c-85cb-0f9776c947b9_AS HD 024A.jpg', 1, 0, '7/6/2026 6:53:16 PM', '1', NULL, NULL, NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (44, 'P044', 'Textura Sheet', 'AS HD 025(A) Textura Sheet', '          ', '', '', '8x4', '~/MyProducts/e4c774ed-83f7-42ce-8a43-fcf501e01a7c_AS HD 025A.jpg', 1, 0, '7/6/2026 6:53:59 PM', '1', NULL, NULL, NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (45, 'P045', 'Textura Sheet', 'AS HD 026(A) Textura Sheet', '          ', '', '', '8x4', '~/MyProducts/aad4ebe7-da15-4806-ae04-28ab84876f8b_AS HD 026A.jpg', 1, 0, '7/6/2026 6:55:16 PM', '1', NULL, NULL, NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (46, 'P046', 'Textura Sheet', 'AS HD 026(B) Textura Sheet', '          ', '', '', '8x4', '~/MyProducts/0a28e3cb-09d1-4633-8237-6d1f49e3b7a0_AS HD 026B.jpg', 1, 0, '7/6/2026 6:56:01 PM', '1', NULL, NULL, NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (47, 'P047', 'Textura Sheet', 'AS HD 028(A) Textura Sheet', '          ', '', '', '8x4', '~/MyProducts/47840755-6c82-423d-a27f-16c115eddf4f_AS HD 028A.jpg', 1, 0, '7/6/2026 6:56:37 PM', '1', NULL, NULL, NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (48, 'P048', 'Textura Sheet', 'AS HD 028(B) Textura Sheet', '          ', '', '', '8x4', '~/MyProducts/d05c93a3-c697-4a7d-a51a-97c9ebb8cf70_AS HD 028B.jpg', 1, 0, '7/6/2026 6:57:19 PM', '1', NULL, NULL, NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (49, 'P049', 'Textura Sheet', 'AS HD 029(A) Textura Sheet', '          ', '', '', '8x4', '~/MyProducts/8434b840-f339-42f4-b7b2-5660cd2a6da5_AS HD 029A.jpg', 1, 0, '7/6/2026 6:57:55 PM', '1', NULL, NULL, NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (50, 'P050', 'Textura Sheet', 'AS HD 029(B) Textura Sheet', '          ', '', '', '8x4', '~/MyProducts/ee80421f-f2ac-4901-84bd-6899d6c6cd7e_AS HD 029B.jpg', 1, 0, '7/6/2026 6:58:38 PM', '1', NULL, NULL, NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (51, 'P051', 'Textura Sheet', 'AS HD 030(A) Textura Sheet', '          ', '', '', '8x4', '~/MyProducts/075a0cfa-835c-42ee-a3c3-79f0901391cf_AS HD 030A.jpg', 1, 0, '7/6/2026 6:59:45 PM', '1', NULL, NULL, NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (52, 'P052', 'Textura Sheet', 'AS HD 030(B) Textura Sheet', '          ', '', '', '8x4', '~/MyProducts/88c4d74b-50b9-4f93-a822-221d94bf4a67_AS HD 030B.jpg', 1, 0, '7/6/2026 7:00:24 PM', '1', NULL, NULL, NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (53, 'P053', 'Textura Sheet', 'AS HD 031(A) Textura Sheet', '          ', '', '', '8x2', '~/MyProducts/3f803870-f619-4ae1-8c7f-a938c8cf5c71_AS HD 031A.jpg', 1, 0, '7/6/2026 7:00:59 PM', '1', NULL, NULL, NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (54, 'P054', 'Textura Sheet', 'AS HD 032(A) Textura Sheet', '          ', '', '', '8x2', '~/MyProducts/e162b70e-0486-41c1-b2dd-3d08252df6a0_AS HD 032A.jpg', 1, 0, '7/6/2026 7:01:40 PM', '1', NULL, NULL, NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (55, 'P055', 'Textura Sheet', 'AS HD 033(A) Textura Sheet', '          ', '', '', '8x2', '~/MyProducts/4aa83eca-9edf-4c17-a430-233272a44d7c_AS HD 033A.jpg', 1, 0, '7/6/2026 7:02:15 PM', '1', NULL, NULL, NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (56, 'P056', 'Textura Sheet', 'AS HD 034(A) Textura Sheet', '          ', '', '', '8x4', '~/MyProducts/1ba13544-96ac-4dc5-8236-05da7fb34c31_AS HD 034A.jpg', 1, 0, '7/6/2026 7:02:51 PM', '1', NULL, NULL, NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (57, 'P057', 'Textura Sheet', 'AS HD 034(B) Textura Sheet', '          ', '', '', '8x4', '~/MyProducts/e62b5ff3-9f76-4d38-ab72-7743438854e2_AS HD 034B.jpg', 1, 0, '7/6/2026 7:03:25 PM', '1', NULL, NULL, NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (58, 'P058', 'Textura Sheet', 'AS HD 034(C) Textura Sheet', '          ', '', '', '8x4', '~/MyProducts/b049c6bd-c52a-4884-9755-257afe7a6a02_AS HD 034C.jpg', 1, 0, '7/6/2026 7:03:58 PM', '1', NULL, NULL, NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (59, 'P059', 'Textura Sheet', 'AS HD 034(D) Textura Sheet', '          ', '', '', '8x4', '~/MyProducts/48826690-e66b-42ab-a1ce-509a0641cd01_AS HD 034D.jpg', 1, 0, '7/6/2026 7:04:28 PM', '1', NULL, NULL, NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (60, 'P060', 'Textura Sheet', 'AS HD 035(A) Textura Sheet', '          ', '', '', '8x4', '~/MyProducts/5c0f7443-9d58-4517-8034-faeb0920ae22_AS HD 035A.jpg', 1, 0, '7/6/2026 7:05:07 PM', '1', NULL, NULL, NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (61, 'P061', 'Textura Sheet', 'AS HD 035(B) Textura Sheet', '          ', '', '', '8x4', '~/MyProducts/a82b075a-783f-43b5-b4a1-3aa185fd2782_AS HD 035B.jpg', 1, 0, '7/6/2026 7:05:40 PM', '1', NULL, NULL, NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (62, 'P062', 'Textura Sheet', 'AS HD 035(C) Textura Sheet', '          ', '', '', '8x4', '~/MyProducts/3e0b1e4a-be22-46b8-8645-6bbaf08d0d8c_AS HD 035C.jpg', 1, 0, '7/6/2026 7:06:16 PM', '1', NULL, NULL, NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (63, 'P063', 'Textura Sheet', 'AS HD 035(D) Textura Sheet', '          ', '', '', '8x4', '~/MyProducts/8e3d57b3-c69b-4e3f-ac58-7839b3286f50_AS HD 035D.jpg', 1, 0, '7/6/2026 7:06:47 PM', '1', NULL, NULL, NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (64, 'P064', 'Textura Sheet', 'AS HD 036(A) Textura Sheet', '          ', '', '', '8x4', '~/MyProducts/f554eff7-bf39-448f-8c78-f804e6a68e87_AS HD 036A.jpg', 1, 0, '7/6/2026 7:07:34 PM', '1', NULL, NULL, NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (65, 'P065', 'Textura Sheet', 'AS HD 036(B) Textura Sheet', '          ', '', '', '8x4', '~/MyProducts/3e332b29-7850-42f0-bba2-1c340e6f12c6_AS HD 036B.jpg', 1, 0, '7/6/2026 7:08:14 PM', '1', NULL, NULL, NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (66, 'P066', 'Textura Sheet', 'AS HD 036(C) Textura Sheet', '          ', '', '', '8x4', '~/MyProducts/e1a9498f-f986-414f-8ec5-976766ca4ba3_AS HD 036C.jpg', 1, 0, '7/6/2026 7:08:50 PM', '1', NULL, NULL, NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (67, 'P067', 'Textura Sheet', 'AS HD 036(D) Textura Sheet', '          ', '', '', '8x4', '~/MyProducts/29a9a9d4-499d-4ddd-9661-57ba6b6280ac_AS HD 036D.jpg', 1, 0, '7/6/2026 7:09:22 PM', '1', NULL, NULL, NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (68, 'P068', 'Textura Sheet', 'AS HD 037(A) Textura Sheet', '          ', '', '', '8x4', '~/MyProducts/dbcd1c40-b103-4494-95a0-56fc1af7a5e1_AS HD 037A.jpg', 1, 0, '7/6/2026 7:10:03 PM', '1', NULL, NULL, NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (69, 'P069', 'Textura Sheet', 'AS HD 037(B) Textura Sheet', '          ', '', '', '8x4', '~/MyProducts/9005ab83-cea7-4050-a2f5-a3ba2a5d6225_AS HD 037B.jpg', 1, 0, '7/6/2026 7:10:45 PM', '1', NULL, NULL, NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (70, 'P070', 'Textura Sheet', 'AS HD 037(C) Textura Sheet', '          ', '', '', '8x4', '~/MyProducts/3774fd7b-5878-426a-8eee-7434e963e799_AS HD 037C.jpg', 1, 0, '7/6/2026 7:11:24 PM', '1', NULL, NULL, NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (71, 'P071', 'Textura Sheet', 'AS HD 037(D) Textura Sheet', '          ', '', '', '8x4', '~/MyProducts/9de1b4e4-9adf-41c3-88aa-55c8dab11f89_AS HD 037D.jpg', 1, 0, '7/6/2026 7:11:59 PM', '1', NULL, NULL, NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (72, 'P072', 'Textura Sheet', 'AS HD 038(A) Textura Sheet', '          ', '', '', '8x4', '~/MyProducts/7cbec528-f817-474a-adf3-f36b750d0788_AS HD 038A.jpg', 1, 0, '7/6/2026 7:12:47 PM', '1', NULL, NULL, NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (73, 'P073', 'Textura Sheet', 'AS HD 038(B) Textura Sheet', '          ', '', '', '8x4', '~/MyProducts/7d682cef-7624-4ee8-a547-dc78bf4d4ed0_AS HD 038B.jpg', 1, 0, '7/6/2026 7:13:42 PM', '1', NULL, NULL, NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (74, 'P074', 'Textura Sheet', 'AS HD 039(A) Textura Sheet', '          ', '', '', '8x4', '~/MyProducts/a290c5b9-0eff-40b4-a506-91b46e6b609b_AS HD 039A.jpg', 1, 0, '7/6/2026 7:14:19 PM', '1', NULL, NULL, NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (75, 'P075', 'Textura Sheet', 'AS HD 040(A) Textura Sheet', '          ', '', '', '8x4', '~/MyProducts/0d051625-8f29-4470-a354-237e10c7ea7c_AS HD 040A.jpg', 1, 0, '7/6/2026 7:14:55 PM', '1', NULL, NULL, NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (76, 'P076', 'Textura Sheet', 'AS HD 041(A) Textura Sheet', '          ', '', '', '8x4', '~/MyProducts/89367188-9608-4375-aa51-e10384a6a28b_AS HD 041A.jpg', 1, 0, '7/6/2026 7:15:28 PM', '1', NULL, NULL, NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (77, 'P077', 'Textura Sheet', 'AS HD 042(A) Textura Sheet', '          ', '', '', '8x4', '~/MyProducts/3dc5fcd9-bc3d-4829-ac03-b97687ec8b8d_AS HD 042A.jpg', 1, 0, '7/6/2026 7:16:04 PM', '1', NULL, NULL, NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (78, 'P078', 'Textura Sheet', 'AS HD 043(A) Textura Sheet', '          ', '', '', '8x4', '~/MyProducts/37397a81-ec44-4da4-997b-af3df5ce0772_AS HD 043A.jpg', 1, 0, '7/6/2026 7:16:42 PM', '1', NULL, NULL, NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (79, 'P079', 'Textura Sheet', 'AS HD 043(B) Textura Sheet', '          ', '', '', '8x4', '~/MyProducts/13ba995f-c220-45ba-91cf-f7c0676f3242_AS HD 043B.jpg', 1, 0, '7/6/2026 7:17:21 PM', '1', NULL, NULL, NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (80, 'P080', 'Textura Sheet', 'AS HD 043(C) Textura Sheet', '          ', '', '', '8x4', '~/MyProducts/3667d019-7afd-443b-bd14-7ca5dfd72043_AS HD 043C.jpg', 1, 0, '7/6/2026 7:17:55 PM', '1', NULL, NULL, NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (81, 'P081', 'Textura Sheet', 'AS HD 044(A) Textura Sheet', '          ', '', '', '8x4', '~/MyProducts/f8cf0809-c424-4a6c-85b1-b59da9261ff8_AS HD 044A.jpg', 1, 0, '7/6/2026 7:18:31 PM', '1', NULL, NULL, NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (82, 'P082', 'Textura Sheet', 'AS HD 045(A) Textura Sheet', '          ', '', '', '8x4', '~/MyProducts/b1cf7f8a-dfbd-4327-b781-103209d08b9b_AS HD 045A.jpg', 1, 0, '7/6/2026 7:19:06 PM', '1', NULL, NULL, NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (83, 'P083', 'Textura Sheet', 'AS HD 046(A) Textura Sheet', '          ', '', '', '8x4', '~/MyProducts/31739f02-05be-4cd7-b8b7-65da31c5505e_AS HD 046A.jpg', 1, 0, '7/6/2026 7:19:43 PM', '1', NULL, NULL, NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (84, 'P084', 'Textura Sheet', 'AS HD 047(A) Textura Sheet', '          ', '', '', '8x4', '~/MyProducts/463c346d-e901-42a8-b15a-2cff619361c4_AS HD 047A.jpg', 1, 0, '7/6/2026 7:20:28 PM', '1', NULL, NULL, NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (85, 'P085', 'Textura Sheet', 'AS HD 047(B) Textura Sheet', '          ', '', '', '8x4', '~/MyProducts/cd453cee-b5f4-475b-8033-44104f6b10b8_AS HD 047B.jpg', 1, 0, '7/6/2026 7:21:07 PM', '1', NULL, NULL, NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (86, 'P086', 'Textura Sheet', 'AS HD 048(A) Textura Sheet', '          ', '', '', '8x4', '~/MyProducts/d13ef849-6f39-4ee6-a709-6ac958f0fb20_AS HD 048A.jpg', 1, 0, '7/6/2026 7:21:49 PM', '1', '1', '7/6/2026 7:22:24 PM', NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (87, 'P087', 'Textura Sheet', 'AS HD 049(A) Textura Sheet', '          ', '', '', '8x4', '~/MyProducts/7fd74afa-bd24-4c06-b217-4b92f83cb95b_AS HD 049A.jpg', 1, 0, '7/6/2026 7:23:05 PM', '1', NULL, NULL, NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (88, 'P088', 'Textura Sheet', 'AS HD 049(B) Textura Sheet', '          ', '', '', '8x4', '~/MyProducts/32bc841d-8566-4ed0-9dd7-2b47a76b9ee7_AS HD 049B.jpg', 1, 0, '7/6/2026 7:23:43 PM', '1', NULL, NULL, NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (89, 'P089', 'Textura Sheet', 'AS HD 051(A) Textura Sheet', '          ', '', '', '8x4', '~/MyProducts/f5563b86-b30c-4d0c-8754-7f5276e9b48a_AS HD 051A.jpg', 1, 0, '7/6/2026 7:25:03 PM', '1', NULL, NULL, NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (90, 'P090', 'Textura Sheet', 'AS HD 052(A) Textura Sheet', '          ', '', '', '8x4', '~/MyProducts/c89ad05f-8bf8-45b2-9e06-942badc9e158_AS HD 052A.jpg', 1, 0, '7/6/2026 7:25:53 PM', '1', NULL, NULL, NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (91, 'P091', 'Textura Sheet', 'AS HD 053(A) Textura Sheet', '          ', '', '', '8x4', '~/MyProducts/df90a281-1a6f-4a17-be02-1992cd44f5c2_AS HD 053A.jpg', 1, 0, '7/6/2026 7:26:41 PM', '1', NULL, NULL, NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (92, 'P092', 'Textura Sheet', 'AS HD 054(A) Textura Sheet', '          ', '', '', '8x4', '~/MyProducts/88c99405-c341-4820-97e3-7353aac6bd1b_AS HD 054A.jpg', 1, 0, '7/6/2026 7:27:31 PM', '1', NULL, NULL, NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (93, 'P093', 'Textura Sheet', 'AS HD 055(A) Textura Sheet', '          ', '', '', '8x4', '~/MyProducts/6b0cc4ed-a1fc-4563-9426-8a4fc94f371f_AS HD 055A.jpg', 1, 0, '7/6/2026 7:28:15 PM', '1', NULL, NULL, NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (94, 'P094', 'Textura Sheet', 'AS HD 056(A) Textura Sheet', '          ', '', '', '8x4', '~/MyProducts/59b603c6-07b5-4053-8b2f-dde3b25eed4b_AS HD 056A.jpg', 1, 0, '7/6/2026 7:29:16 PM', '1', NULL, NULL, NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (95, 'P095', 'Textura Sheet', 'AS HD 056(B) Textura Sheet', '          ', '', '', '8x4', '~/MyProducts/6071b8cd-28b0-49e7-915d-b911ae4e7e1c_AS HD 056B.jpg', 1, 0, '7/6/2026 7:30:56 PM', '1', NULL, NULL, NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (96, 'P096', 'Textura Sheet', 'AS HD 058(A) Textura Sheet', '          ', '', '', '8x4', '~/MyProducts/b0eaaa68-e165-42bd-8b1b-a92e4ac9840b_AS HD 058A.jpg', 1, 0, '7/6/2026 7:31:59 PM', '1', NULL, NULL, NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (97, 'P097', 'Textura Sheet', 'AS HD 058(B) Textura Sheet', '          ', '', '', '8x4', '~/MyProducts/b2bd374c-c2aa-4b8a-ac91-475b4b9a9e2d_AS HD 058A.jpg', 1, 0, '7/6/2026 7:32:50 PM', '1', NULL, NULL, NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (98, 'P098', 'Textura Sheet', 'AS HD 059(A) Textura Sheet', '          ', '', '', '8x4', '~/MyProducts/4d4faea8-0ca3-44df-a444-903dd8d10072_AS HD 059A.jpg', 1, 0, '7/6/2026 7:33:57 PM', '1', NULL, NULL, NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (99, 'P099', 'Textura Sheet', 'AS HD 059(B) Textura Sheet', '          ', '', '', '8x4', '~/MyProducts/1b185d41-e7a8-4c31-b104-114df13845d3_AS HD 059B.jpg', 1, 0, '7/6/2026 7:35:11 PM', '1', NULL, NULL, NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (100, 'P100', 'Textura Sheet', 'AS HD 060(A) Textura Sheet', '          ', '', '', '8x4', '~/MyProducts/d7f83126-cf17-491d-b4f3-104ab5610f27_AS HD 060A.jpg', 1, 0, '7/6/2026 7:38:46 PM', '1', NULL, NULL, NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (101, 'P101', 'Textura Sheet', 'AS HD 061(B) Textura Sheet', '          ', '', '', '8x4', '~/MyProducts/5d32514a-6c9e-48e7-946b-eae71a5e0c43_AS HD 061B.jpg', 1, 0, '7/6/2026 7:39:42 PM', '1', '1', '7/6/2026 7:40:29 PM', NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (102, 'P102', 'Textura Sheet', 'AS HD 061(A) Textura Sheet', '          ', '', '', '8x4', '~/MyProducts/3e28c6ac-12b0-4651-86c0-34340f1e077b_AS HD 061A.jpg', 1, 0, '7/6/2026 7:42:11 PM', '1', NULL, NULL, NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (103, 'P103', 'Textura Sheet', 'AS HD 062(A) Textura Sheet', '          ', '', '', '8x4', '~/MyProducts/494b1768-6a5f-4add-9ddd-94909a435258_AS HD 062A.jpg', 1, 0, '7/6/2026 7:44:21 PM', '1', NULL, NULL, NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (104, 'P104', 'Textura Sheet', 'AS HD 063(A) Textura Sheet', '          ', '', '', '8x4', '~/MyProducts/132fe554-5fb1-40b8-a7b7-f415267872fa_AS HD 063A.jpg', 1, 0, '7/6/2026 7:45:25 PM', '1', NULL, NULL, NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (105, 'P105', 'Textura Sheet', 'AS HD 064(A) Textura Sheet', '          ', '', '', '8x4', '~/MyProducts/55578f50-f955-4ee5-b1c9-a50d844c1194_AS HD 064A.jpg', 1, 0, '7/6/2026 7:46:40 PM', '1', NULL, NULL, NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (106, 'P106', 'Textura Sheet', 'AS HD 065(A) Textura Sheet', '          ', '', '', '8x4', '~/MyProducts/1a9dd96a-2a80-4a08-a24e-3411b91883e9_AS HD 065A.jpg', 1, 0, '7/6/2026 7:48:16 PM', '1', NULL, NULL, NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (107, 'P107', 'Textura Sheet', 'AS HD 066(A) Textura Sheet', '          ', '', '', '8x4', '~/MyProducts/f1c82867-8e5f-490c-9290-449bf9e68e25_AS HD 066A.jpg', 1, 0, '7/6/2026 7:50:40 PM', '1', NULL, NULL, NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (108, 'P108', 'Textura Sheet', 'AS HD 067(A) Textura Sheet', '          ', '', '', '8x4', '~/MyProducts/248507ca-1d38-4ae6-8426-2922036d8c97_AS HD 067A.jpg', 1, 0, '7/6/2026 7:51:49 PM', '1', NULL, NULL, NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (109, 'P109', 'Textura Sheet', 'AS HD 068(A) Textura Sheet', '          ', '', '', '8x4', '~/MyProducts/aa7e1b55-b9ea-4ba4-ab04-79f2372d960a_AS HD 068A.jpg', 1, 0, '7/6/2026 7:55:22 PM', '1', NULL, NULL, NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (110, 'P110', 'Textura Sheet', 'AS HD 068(B) Textura Sheet', '          ', '', '', '8x4', '~/MyProducts/260b04c8-a7b1-40e0-9ce0-e8d531daf6c8_AS HD 068B.jpg', 1, 0, '7/6/2026 7:56:57 PM', '1', NULL, NULL, NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (111, 'P111', 'Textura Sheet', 'AS HD 069(A) Textura Sheet', '          ', '', '', '8x4', '~/MyProducts/79209439-16ff-4063-a47c-c34c13dbe022_AS HD 069A.jpg', 1, 0, '7/6/2026 7:58:17 PM', '1', NULL, NULL, NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (112, 'P112', 'Textura Sheet', 'AS HD 069(B) Textura Sheet', '          ', '', '', '8x4', '~/MyProducts/6e6e3e1c-9701-4d84-af10-caa008638498_AS HD 069B.jpg', 1, 0, '7/6/2026 7:59:05 PM', '1', NULL, NULL, NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (113, 'P113', 'Textura Sheet', 'AS HD 070(A) Textura Sheet', '          ', '', '', '8x4', '~/MyProducts/eede6968-83b7-487a-9e98-18a3e50f957b_AS HD 070A.jpg', 1, 0, '7/6/2026 8:00:04 PM', '1', NULL, NULL, NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (114, 'P114', 'Textura Sheet', 'AS HD 070(B) Textura Sheet', '          ', '', '', '8x4', '~/MyProducts/c7e8d5f2-c7b4-428c-8ece-773cf782a694_AS HD 070B.jpg', 1, 0, '7/6/2026 8:00:54 PM', '1', NULL, NULL, NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (115, 'P115', 'Textura Sheet', 'AS HD 071(A) Textura Sheet', '          ', '', '', '8x4', '~/MyProducts/733ba225-c2f3-4190-9631-934b5e3bb470_AS HD 071A.jpg', 1, 0, '7/6/2026 8:01:31 PM', '1', NULL, NULL, NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (116, 'P116', 'Textura Sheet', 'AS HD 072(A) Textura Sheet', '          ', '', '', '8x4', '~/MyProducts/6a05b798-3820-4887-a491-c48eb902b992_AS HD 072A.jpg', 1, 0, '7/6/2026 8:02:08 PM', '1', NULL, NULL, NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (117, 'P117', 'Textura Sheet', 'AS HD 072(B) Textura Sheet', '          ', '', '', '8x4', '~/MyProducts/6a53537d-261a-4d87-8f92-01d3201788f3_AS HD 072B.jpg', 1, 0, '7/6/2026 8:02:48 PM', '1', NULL, NULL, NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (118, 'P118', 'Textura Sheet', 'AS HD 073(A) Textura Sheet', '          ', '', '', '8x4', '~/MyProducts/191e2453-a114-4def-a9ee-052999ccd9e4_AS HD 073A.jpg', 1, 0, '7/6/2026 8:03:26 PM', '1', NULL, NULL, NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (119, 'P119', 'Textura Sheet', 'AS HD 073(B) Textura Sheet', '          ', '', '', '8x4', '~/MyProducts/634a5316-d0a4-46da-8a15-4b540ccf282f_AS HD 073B.jpg', 1, 0, '7/6/2026 8:03:58 PM', '1', NULL, NULL, NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (120, 'P120', 'Textura Sheet', 'AS HD 073(C) Textura Sheet', '          ', '', '', '8x4', '~/MyProducts/080103da-2be5-4025-8379-5f46d889f3c9_AS HD 073C.jpg', 1, 0, '7/6/2026 8:04:33 PM', '1', NULL, NULL, NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (121, 'P121', 'Textura Sheet', 'AS HD 074(A) Textura Sheet', '          ', '', '', '8x4', '~/MyProducts/37fd524f-c1d5-4a7a-b8b9-bfcdeb8961ac_AS HD 074A.jpg', 1, 0, '7/6/2026 8:05:06 PM', '1', NULL, NULL, NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (122, 'P122', 'Textura Sheet', 'AS HD 074(B) Textura Sheet', '          ', '', '', '8x4', '~/MyProducts/4e5d84f3-db88-47b0-97fa-26f290d083ab_AS HD 074B.jpg', 1, 0, '7/6/2026 8:05:41 PM', '1', NULL, NULL, NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (123, 'P123', 'Textura Sheet', 'AS HD 076(A) Textura Sheet', '          ', '', '', '8x4', '~/MyProducts/b2a4f41e-a18a-4da5-922b-d67a4518a084_AS HD 076A.jpg', 1, 0, '7/6/2026 8:07:13 PM', '1', NULL, NULL, NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (124, 'P124', 'Textura Sheet', 'AS HD 077(A) Textura Sheet', '          ', '', '', '8x4', '~/MyProducts/7fa6582e-c0b2-4f9b-a6c5-c6da0c1bf0ee_AS HD 077A.jpg', 1, 0, '7/6/2026 8:08:27 PM', '1', NULL, NULL, NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (125, 'P125', 'Textura Sheet', 'AS HD 077(B) Textura Sheet', '          ', '', '', '8x4', '~/MyProducts/7da2c3c9-cbbe-482b-ac37-9a7d185829ff_AS HD 077B.jpg', 1, 0, '7/6/2026 8:09:04 PM', '1', NULL, NULL, NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (126, 'P126', 'Textura Sheet', 'AS HD 078(A) Textura Sheet', '          ', '', '', '8x4', '~/MyProducts/1503d9cc-a67c-40c3-a962-b18043b8d884_AS HD 078A.jpg', 1, 0, '7/6/2026 8:09:53 PM', '1', NULL, NULL, NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (127, 'P127', 'Textura Sheet', 'AS HD 079(A) Textura Sheet', '          ', '', '', '8x4', '~/MyProducts/15a92a20-aceb-4b11-bb32-8c0227d91c97_AS HD 079.jpg', 1, 0, '7/6/2026 8:10:36 PM', '1', NULL, NULL, NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (128, 'P128', 'Textura Sheet', 'AS HD 080(A) Textura Sheet', '          ', '', '', '8x4', '~/MyProducts/61693884-c7dd-4b52-9c9b-2f780d10bd0e_AS HD 080.jpg', 1, 0, '7/6/2026 8:11:31 PM', '1', NULL, NULL, NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (129, 'P129', 'Textura Sheet', 'AS HD 081(A) Textura Sheet', '          ', '', '', '8x4', '~/MyProducts/4f72b734-26ae-4624-9bb0-500609f3945e_AS HD 081.jpg', 1, 0, '7/6/2026 8:12:12 PM', '1', NULL, NULL, NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (130, 'P130', 'Textura Sheet', 'AS HD 082(A) Textura Sheet', '          ', '', '', '8x4', '~/MyProducts/52a9a0d3-a65f-43d9-adf0-144903c9ac0b_AS HD 082.jpg', 1, 0, '7/6/2026 8:12:48 PM', '1', NULL, NULL, NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (131, 'P131', 'Textura Sheet', 'AS HD 083(A) Textura Sheet', '          ', '', '', '8x4', '~/MyProducts/bb976a4d-fff2-497d-9067-bbff686e2365_AS HD 083.jpg', 1, 0, '7/6/2026 8:13:57 PM', '1', NULL, NULL, NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (132, 'P132', 'Textura Sheet', 'AS HD 084(A) Textura Sheet', '          ', '', '', '8x4', '~/MyProducts/1437757e-ab29-49cb-9fc9-e308ab6bf202_AS HD 084 A.jpg', 1, 0, '7/6/2026 8:14:53 PM', '1', NULL, NULL, NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (133, 'P133', 'Textura Sheet', 'AS HD 084(B) Textura Sheet', '          ', '', '', '8x4', '~/MyProducts/c0645b95-5c80-4f82-826a-cbcbdd92fe45_AS HD 084 B.jpg', 1, 0, '7/6/2026 8:15:37 PM', '1', NULL, NULL, NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (134, 'P134', 'Textura Sheet', 'AS HD 085(A) Textura Sheet', '          ', '', '', '8x4', '~/MyProducts/74ed3ddc-4f57-4369-bf96-94d21c0003c6_AS HD 085 A.jpg', 1, 0, '7/6/2026 8:16:23 PM', '1', NULL, NULL, NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (135, 'P135', 'Textura Sheet', 'AS HD 085(B) Textura Sheet', '          ', '', '', '8x4', '~/MyProducts/429251c5-7bcd-446c-97b1-88933bb42519_AS HD 085 B.jpg', 1, 0, '7/6/2026 8:17:01 PM', '1', NULL, NULL, NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (136, 'P136', 'Textura Sheet', 'AS HD 086(A) Textura Sheet', '          ', '', '', '8x4', '~/MyProducts/7491a61e-252d-4f59-ab96-508b79d0e481_AS HD 086 A.jpg', 1, 0, '7/6/2026 8:17:44 PM', '1', NULL, NULL, NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (137, 'P137', 'Textura Sheet', 'AS HD 086(B) Textura Sheet', '          ', '', '', '8x4', '~/MyProducts/8afd5786-e44a-491c-b937-752200859beb_AS HD 086 B.jpg', 1, 0, '7/6/2026 8:18:25 PM', '1', NULL, NULL, NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (138, 'P138', 'Textura Sheet', 'AS HD 087(A) Textura Sheet', '          ', '', '', '8x4', '~/MyProducts/1f8d2c74-174f-458a-89d3-26fc5d5e34e0_AS HD 087 A.jpg', 1, 0, '7/6/2026 8:19:05 PM', '1', NULL, NULL, NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (139, 'P139', 'Textura Sheet', 'AS HD 087(B) Textura Sheet', '          ', '', '', '8x4', '~/MyProducts/0127099e-fb75-4bd8-8671-ccdc728b7a8d_AS HD 087 B.jpg', 1, 0, '7/6/2026 8:19:42 PM', '1', NULL, NULL, NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (140, 'P140', 'Textura Sheet', 'AS HD 048(B) Textura Sheet', '          ', '', '', '8x4', NULL, 1, 0, '7/7/2026 10:37:46 AM', '1', '1', '7/7/2026 10:39:51 AM', NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (141, 'P141', 'Textura Sheet', 'AS HD 017(C) Textura Sheet', '          ', '', '', '8x4', NULL, 1, 0, '7/8/2026 10:59:37 AM', '1', '1', '7/8/2026 11:00:33 AM', NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (142, 'P142', 'Textura Sheet', 'AS HD 017(D) Textura Sheet', '          ', '', '', '8x4', NULL, 1, 0, '7/8/2026 11:00:17 AM', '1', NULL, NULL, NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (143, 'P143', 'Textura Sheet', 'AS HD 013(C) Textura Sheet', '          ', '', '', '8x2', NULL, 1, 0, '7/8/2026 11:02:29 AM', '1', NULL, NULL, NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (144, 'P144', 'Textura Sheet', 'AS HD 080(B) TEXTURA SHEET', '          ', '', '', '8x4', NULL, 1, 0, '7/10/2026 2:34:01 PM', '1', '1', '7/10/2026 2:34:15 PM', NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (145, 'P145', 'Textura Sheet', 'AS HD 080(C) TEXTURA SHEET', '          ', '', '', '8x4', NULL, 1, 0, '7/10/2026 2:34:45 PM', '1', NULL, NULL, NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (146, 'P146', 'Textura Sheet', 'AS HD 0043(B) TEXTURA SHEET', '          ', '', '', '8x4', NULL, 1, 0, '7/10/2026 2:40:44 PM', '1', '1', '7/21/2026 3:24:07 PM', NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (147, 'P147', 'Textura Sheet', 'AS HD 042(B) TEXTURA SHEET', '          ', '', '', '8x4', NULL, 1, 0, '7/10/2026 2:44:33 PM', '1', NULL, NULL, NULL, NULL);

SET IDENTITY_INSERT dbo.tbl_ProdcutMaster OFF;


-- Structure for table [DB_AcryshadeLaminatesTestAWS].[dbo].[tbl_ProductionInatial]
SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
CREATE TABLE [dbo].[tbl_ProductionInatial](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[WorkOrderId] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[WorkOrderNo] [nvarchar](200) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[TotalQty] [nvarchar](200) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Size] [nvarchar](200) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]


-- Data for table [DB_AcryshadeLaminatesTestAWS].[dbo].[tbl_ProductionInatial]
SET IDENTITY_INSERT dbo.tbl_ProductionInatial ON;


SET IDENTITY_INSERT dbo.tbl_ProductionInatial OFF;


-- Structure for table [DB_AcryshadeLaminatesTestAWS].[dbo].[tbl_ProductionMachineLoading]
SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
CREATE TABLE [dbo].[tbl_ProductionMachineLoading](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[ProductionPlanId] [int] NULL,
	[WorkOrderId] [int] NULL,
	[MachineId] [int] NULL,
	[AllocatedStage] [varchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[ScheduleDate] [datetime] NULL,
	[PlannedQty] [decimal](18, 2) NULL,
	[ProducedQty] [decimal](18, 2) NULL,
	[Status] [varchar](20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
 CONSTRAINT [PK__tbl_Prod__3214EC0755EFB886] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]

ALTER TABLE [dbo].[tbl_ProductionMachineLoading] ADD  CONSTRAINT [DF__tbl_Produ__Produ__671F4F74]  DEFAULT ((0)) FOR [ProducedQty]

-- Data for table [DB_AcryshadeLaminatesTestAWS].[dbo].[tbl_ProductionMachineLoading]
SET IDENTITY_INSERT dbo.tbl_ProductionMachineLoading ON;


SET IDENTITY_INSERT dbo.tbl_ProductionMachineLoading OFF;


-- Structure for table [DB_AcryshadeLaminatesTestAWS].[dbo].[tbl_ProductionPlan]
SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
CREATE TABLE [dbo].[tbl_ProductionPlan](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[WorkOrderId] [int] NULL,
	[ScheduleDate] [date] NULL,
	[PlannedQty] [decimal](18, 2) NULL,
	[ProducedQty] [decimal](18, 2) NULL,
	[Status] [varchar](20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
 CONSTRAINT [PK__tbl_Prod__3214EC070A46DA88] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]

ALTER TABLE [dbo].[tbl_ProductionPlan] ADD  CONSTRAINT [DF__tbl_Produ__Produ__5D95E53A]  DEFAULT ((0)) FOR [ProducedQty]
ALTER TABLE [dbo].[tbl_ProductionPlan] ADD  CONSTRAINT [DF__tbl_Produ__Statu__5E8A0973]  DEFAULT ('Planned') FOR [Status]

-- Data for table [DB_AcryshadeLaminatesTestAWS].[dbo].[tbl_ProductionPlan]
SET IDENTITY_INSERT dbo.tbl_ProductionPlan ON;


SET IDENTITY_INSERT dbo.tbl_ProductionPlan OFF;


-- Structure for table [DB_AcryshadeLaminatesTestAWS].[dbo].[tbl_RawMaterial_DTLS]
SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
CREATE TABLE [dbo].[tbl_RawMaterial_DTLS](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[HeaderId] [nvarchar](20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[RawMaterialName] [nvarchar](200) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[RawMaterialCode] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[RawMaterialCategory] [nvarchar](500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[RawMaterialDesc] [nvarchar](max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[RawMaterialQty] [nvarchar](20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Unit] [nvarchar](20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[PerQtyRate] [nvarchar](20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[GstPercentage] [nvarchar](20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[GstAmount] [nvarchar](20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
 CONSTRAINT [PK__tbl_RawM__3214EC2783192077] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]


-- Data for table [DB_AcryshadeLaminatesTestAWS].[dbo].[tbl_RawMaterial_DTLS]
SET IDENTITY_INSERT dbo.tbl_RawMaterial_DTLS ON;

INSERT INTO dbo.tbl_RawMaterial_DTLS (ID, HeaderId, RawMaterialName, RawMaterialCode, RawMaterialCategory, RawMaterialDesc, RawMaterialQty, Unit, PerQtyRate, GstPercentage, GstAmount) VALUES (1, '1', 'Wooden Sheet', 'WO-001', 'Wood', 'Wooden sheets ', '500', 'PCS', '0', '0', '0');
INSERT INTO dbo.tbl_RawMaterial_DTLS (ID, HeaderId, RawMaterialName, RawMaterialCode, RawMaterialCategory, RawMaterialDesc, RawMaterialQty, Unit, PerQtyRate, GstPercentage, GstAmount) VALUES (2, '1', 'Glue', 'GU-001', 'Adhesive', 'Pasting Glue', '5', 'LTRS', '0', '0', '0');

SET IDENTITY_INSERT dbo.tbl_RawMaterial_DTLS OFF;


-- Structure for table [DB_AcryshadeLaminatesTestAWS].[dbo].[tbl_RawMaterial_HDR]
SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
CREATE TABLE [dbo].[tbl_RawMaterial_HDR](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[SupplierName] [nvarchar](500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[PurchaseNo] [nvarchar](500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[PurchaseDate] [date] NULL,
	[IsActive] [bit] NULL,
	[IsDeleted] [bit] NULL,
	[CreatedBy] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[CreatedOn] [datetime] NULL,
	[UpdatedBy] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[UpdatedOn] [datetime] NULL,
 CONSTRAINT [PK__tbl_RawM__3214EC27ECBEEA37] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]


-- Data for table [DB_AcryshadeLaminatesTestAWS].[dbo].[tbl_RawMaterial_HDR]
SET IDENTITY_INSERT dbo.tbl_RawMaterial_HDR ON;

INSERT INTO dbo.tbl_RawMaterial_HDR (ID, SupplierName, PurchaseNo, PurchaseDate, IsActive, IsDeleted, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn) VALUES (1, 'Shubham P', 'PO-2026/27-001', '6/12/2026 12:00:00 AM', 1, 0, NULL, '6/5/2026 9:46:13 AM', NULL, NULL);

SET IDENTITY_INSERT dbo.tbl_RawMaterial_HDR OFF;


-- Structure for table [DB_AcryshadeLaminatesTestAWS].[dbo].[tbl_RoleMaster]
SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
CREATE TABLE [dbo].[tbl_RoleMaster](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[Roles] [nvarchar](250) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Departments] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[IsDeleted] [bit] NULL,
 CONSTRAINT [PK__tbl_Role__3214EC27AD0FEC49] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]


-- Data for table [DB_AcryshadeLaminatesTestAWS].[dbo].[tbl_RoleMaster]
SET IDENTITY_INSERT dbo.tbl_RoleMaster ON;

INSERT INTO dbo.tbl_RoleMaster (ID, Roles, Departments, IsDeleted) VALUES (1, 'Admin', 'In-House', 0);
INSERT INTO dbo.tbl_RoleMaster (ID, Roles, Departments, IsDeleted) VALUES (3, 'Dealer', 'Outsourcing', 0);
INSERT INTO dbo.tbl_RoleMaster (ID, Roles, Departments, IsDeleted) VALUES (4, 'Operator', 'Production', 0);
INSERT INTO dbo.tbl_RoleMaster (ID, Roles, Departments, IsDeleted) VALUES (5, 'Manager', 'In-House', 0);
INSERT INTO dbo.tbl_RoleMaster (ID, Roles, Departments, IsDeleted) VALUES (6, 'Supervisor', 'Packaging_Dispatch', 0);

SET IDENTITY_INSERT dbo.tbl_RoleMaster OFF;


-- Structure for table [DB_AcryshadeLaminatesTestAWS].[dbo].[tbl_Stage1Production]
SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
CREATE TABLE [dbo].[tbl_Stage1Production](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[MachineId] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[WOHeaderId] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[ProductName] [nvarchar](500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[PartNo] [nvarchar](200) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Size] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[ReceivedQty] [nvarchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[ReceivedDate] [datetime] NULL,
	[CompletedQty] [nvarchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[CompletedDate] [datetime] NULL,
	[RejectedQty] [nvarchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[WOStatus] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[sheduledate] [date] NULL,
 CONSTRAINT [PK__tbl_Stag__3214EC278DE4B4F9] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]


-- Data for table [DB_AcryshadeLaminatesTestAWS].[dbo].[tbl_Stage1Production]
SET IDENTITY_INSERT dbo.tbl_Stage1Production ON;


SET IDENTITY_INSERT dbo.tbl_Stage1Production OFF;


-- Structure for table [DB_AcryshadeLaminatesTestAWS].[dbo].[tbl_Stage2Production]
SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
CREATE TABLE [dbo].[tbl_Stage2Production](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[Stage1HeaderId] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[MachineId] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[WOHeaderId] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[ProductName] [nvarchar](500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[PartNo] [nvarchar](200) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Size] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[ReceivedQty] [nvarchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[ReceivedDate] [datetime] NULL,
	[CompletedQty] [nvarchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[CompletedDate] [datetime] NULL,
	[RejectedQty] [nvarchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[WOStatus] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
 CONSTRAINT [PK__tbl_Stag__3214EC27A3212BC6] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]


-- Data for table [DB_AcryshadeLaminatesTestAWS].[dbo].[tbl_Stage2Production]
SET IDENTITY_INSERT dbo.tbl_Stage2Production ON;


SET IDENTITY_INSERT dbo.tbl_Stage2Production OFF;


-- Structure for table [DB_AcryshadeLaminatesTestAWS].[dbo].[tbl_StageMaster]
SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
CREATE TABLE [dbo].[tbl_StageMaster](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[SatgeName] [nvarchar](500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[SatgeDescription] [nvarchar](max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[SatgeCapacity] [nvarchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[CapacityUnit] [nvarchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[IsDeleted] [bit] NULL,
	[CreatedBy] [nvarchar](500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[CreatedOn] [datetime] NULL,
	[UpdatedBy] [nvarchar](500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[UpdatedOn] [datetime] NULL,
 CONSTRAINT [PK__tbl_Stag__3214EC2755069901] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]


-- Data for table [DB_AcryshadeLaminatesTestAWS].[dbo].[tbl_StageMaster]
SET IDENTITY_INSERT dbo.tbl_StageMaster ON;

INSERT INTO dbo.tbl_StageMaster (ID, SatgeName, SatgeDescription, SatgeCapacity, CapacityUnit, IsDeleted, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn) VALUES (1, 'Stage 1', 'The phase in which a product is being manufactured, assembled, tested, or prepared for delivery. This stage tracks the progress of production from initiation to completion.', '1080', 'SqFt', 0, '1', '7/1/2026 10:30:19 AM', '1', '7/3/2026 5:53:16 PM');
INSERT INTO dbo.tbl_StageMaster (ID, SatgeName, SatgeDescription, SatgeCapacity, CapacityUnit, IsDeleted, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn) VALUES (2, 'Stage 2', 'Indicates the current status of the manufacturing process (e.g., Planned, In Progress, Quality Check, Completed).', '1080', 'SqFt', 0, '1', '7/1/2026 10:30:43 AM', '1', '7/3/2026 5:53:25 PM');

SET IDENTITY_INSERT dbo.tbl_StageMaster OFF;


-- Structure for table [DB_AcryshadeLaminatesTestAWS].[dbo].[tbl_Transportermaster]
SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
CREATE TABLE [dbo].[tbl_Transportermaster](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[transporter_code] [nvarchar](20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[transporter_name] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[gst_no] [nvarchar](20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[pan_no] [nvarchar](20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[contact_person] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[mobile] [nvarchar](15) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[email] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[address] [nvarchar](max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[city] [nvarchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[state] [nvarchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[pincode] [nvarchar](10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[vehicle_type] [nvarchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[rate_per_km] [decimal](10, 2) NULL,
	[bank_name] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[account_no] [nvarchar](30) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[ifsc_code] [nvarchar](20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[status] [bit] NULL,
	[serviceRoute] [nvarchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[IsDeleted] [bit] NULL,
	[CreatedBy] [nvarchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[CreatedOn] [datetime] NULL,
	[UpdatedBy] [nvarchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[UpdatedOn] [datetime] NULL,
PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]


-- Data for table [DB_AcryshadeLaminatesTestAWS].[dbo].[tbl_Transportermaster]
SET IDENTITY_INSERT dbo.tbl_Transportermaster ON;

INSERT INTO dbo.tbl_Transportermaster (id, transporter_code, transporter_name, gst_no, pan_no, contact_person, mobile, email, address, city, state, pincode, vehicle_type, rate_per_km, bank_name, account_no, ifsc_code, status, serviceRoute, IsDeleted, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn) VALUES (1, 'TR001', 'Sai Transport Services', '7ABCDE1234F1Z5', 'ABCDE1234F', 'Amit Patil', '9876543210', 'saitransport@gmail.com', 'Chakan MIDC, Pune', 'Pune', 'Maharashtra', '410501', 'Container TrucK', 28.50, 'HDFC Bank', '1234567890', 'HDFC0000123', 1, 'Pune To Nashik', 0, NULL, '5/29/2026 12:51:43 PM', '1', '7/11/2026 11:44:19 AM');

SET IDENTITY_INSERT dbo.tbl_Transportermaster OFF;


-- Structure for table [DB_AcryshadeLaminatesTestAWS].[dbo].[tbl_UserMaster]
SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
CREATE TABLE [dbo].[tbl_UserMaster](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[UserCode] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[FullName] [nvarchar](500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[CompanyName] [nvarchar](500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[MobileNo] [nvarchar](10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[EmailId] [nvarchar](250) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[LoginPass] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Type] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[GstNo] [nvarchar](200) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[PanCardNo] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[UANNo] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[BillAddress] [nvarchar](max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[BillArea] [nvarchar](200) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[BillPinCode] [nvarchar](20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[BillState] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[BillCity] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[BillCountry] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[ShipAddress] [nvarchar](max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[ShipArea] [nvarchar](200) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[ShipPinCode] [nvarchar](20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[ShipState] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[ShipCity] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[ShipCountry] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[UserRole] [nvarchar](20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[RelationId] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[IsActivate] [bit] NULL,
	[IsDeleted] [bit] NULL,
	[CreatedOn] [datetime] NULL,
	[CreatedBy] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[UpdatedOn] [datetime] NULL,
	[UpdatedBy] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
UNIQUE NONCLUSTERED 
(
	[EmailId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]


-- Data for table [DB_AcryshadeLaminatesTestAWS].[dbo].[tbl_UserMaster]
SET IDENTITY_INSERT dbo.tbl_UserMaster ON;

INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (1, 'AL/2026-27/001', 'Admin', NULL, '9876543210', 'erpweblink@gmail.com', '123', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Admin', NULL, 1, 0, '5/28/2026 10:15:13 AM', '1', '6/5/2026 9:33:24 AM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (3, 'AL/2026-27/002', 'WEB LINK SERVICES PRIVATE LIMITED', 'WEB LINK SERVICES PRIVATE LIMITED', '9876543210', 'software@gmail.com', '8100', 'Authorized', '27AABCW8929J2ZP', 'AABCW8929J', '', '4 FLAT NO A-506 Aksha Vrundavan CHIKHALI MOSHI ROAD OPP INDIAL OIL PETROL PUMP', 'Pimpri Chinchwad PIMPRI CHINCHWAD', '411062', 'Maharashtra', 'Pimpri Chinchwad PIMPRI CHINCHWAD', 'India', '4 FLAT NO A-506 Aksha Vrundavan CHIKHALI MOSHI ROAD OPP INDIAL OIL PETROL PUMP', 'Pimpri Chinchwad PIMPRI CHINCHWAD', '411062', 'Maharashtra', 'Pimpri Chinchwad PIMPRI CHINCHWAD', 'India', 'Dealer', NULL, 1, 0, '7/1/2026 10:21:26 AM', '1', '7/1/2026 10:22:08 AM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (41, 'AL/2026-27/006', 'Aar-Em Electronics Pvt Ltd', 'Aar-Em Electronics Pvt Ltd', '9158897682', '9158897682@dealer.com', '99E15501', 'Authorized', '27AABCA5148B1Z4', 'AABCA5148B', NULL, 'Aar-Em House Plot No 74-4, Lane No 3, Ramtekdi Industrial Estate, Pune', NULL, '411028', 'Maharashtra', 'Pune', 'India', 'Aar-Em House Plot No 74-4, Lane No 3, Ramtekdi Industrial Estate, Pune', NULL, '411028', 'Maharashtra', 'Pune', 'India', 'Dealer', NULL, 1, 0, '7/3/2026 6:00:25 PM', '1', '7/3/2026 6:00:25 PM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (42, 'AL/2026-27/007', 'Abhishek Plywood & Hardware', 'Abhishek Plywood & Hardware', '7875529895', '7875529895@dealer.com', 'D6356B55', 'Authorized', '27AIJPL4561C1ZC', 'AIJPL4561C', NULL, '1477 Abhishek Plywood & Hardware, Near Sona Sadi Center, Gandhi Chowk, Kopargaon', NULL, '423601', 'Maharashtra', 'Kopargaon', 'India', '1477 Abhishek Plywood & Hardware, Near Sona Sadi Center, Gandhi Chowk, Kopargaon', NULL, '423601', 'Maharashtra', 'Kopargaon', 'India', 'Dealer', NULL, 1, 0, '7/3/2026 6:00:25 PM', '1', '7/3/2026 6:00:25 PM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (43, 'AL/2026-27/008', 'Absolute Studios', 'Absolute Studios', '8400479409', '8400479409@dealer.com', 'C873ED1E', 'Authorized', '09ACAFA8242L1Z7', 'ACAFA8242L', NULL, 'Plot No 94 Govt, Kalpi Road Industrial Estate, Kanpur Nagar', NULL, '208012', 'Uttar Pradesh', 'Kanpur Nagar', 'India', 'Plot No 94 Govt, Kalpi Road Industrial Estate, Kanpur Nagar', NULL, '208012', 'Uttar Pradesh', 'Kanpur Nagar', 'India', 'Dealer', NULL, 1, 0, '7/3/2026 6:00:25 PM', '1', '7/3/2026 6:00:25 PM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (44, 'AL/2026-27/009', 'Agrawal Ply Lam', 'Agrawal Ply Lam', '9823088151', '9823088151@dealer.com', 'D3A48088', 'Authorized', '27ABOFA4688D1Z4', 'ABOFA4688D', NULL, 'KP Square, Pimpri Chinchwad, Pune', NULL, '411019', 'Maharashtra', 'Pune', 'India', 'KP Square, Pimpri Chinchwad, Pune', NULL, '411019', 'Maharashtra', 'Pune', 'India', 'Dealer', NULL, 1, 0, '7/3/2026 6:00:25 PM', '1', '7/3/2026 6:00:25 PM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (45, 'AL/2026-27/010', 'Aj Associates', 'Aj Associates', '9424517668', '9424517668@dealer.com', 'AC0A152A', 'Authorized', '23BCBPJ1178G1ZZ', 'BCBPJ1178G', NULL, 'EW-79 Scheme No 94, Indore', NULL, '452018', 'Madhya Pradesh', 'Indore', 'India', 'EW-79 Scheme No 94, Indore', NULL, '452018', 'Madhya Pradesh', 'Indore', 'India', 'Dealer', NULL, 1, 0, '7/3/2026 6:00:25 PM', '1', '7/3/2026 6:00:25 PM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (46, 'AL/2026-27/011', 'Ajmera Associates', 'Ajmera Associates', '9637817890', '9637817890@dealer.com', 'DFF638BB', 'Authorized', '27AJUPA3579M1ZH', 'AJUPA3579M', NULL, 'Gondia', NULL, '441614', 'Maharashtra', 'Gondia', 'India', 'Gondia', NULL, '441614', 'Maharashtra', 'Gondia', 'India', 'Dealer', NULL, 1, 0, '7/3/2026 6:00:25 PM', '1', '7/3/2026 6:00:25 PM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (47, 'AL/2026-27/012', 'Ajmera Plylam', 'Ajmera Plylam', '8788705766', '8788705766@dealer.com', '31D0875C', 'Authorized', '22DKQPA4357D1ZF', 'DKQPA4357D', NULL, 'New Timber Market, Raipur', NULL, '492005', 'Chhattisgarh', 'Raipur', 'India', 'New Timber Market, Raipur', NULL, '492005', 'Chhattisgarh', 'Raipur', 'India', 'Dealer', NULL, 1, 0, '7/3/2026 6:00:25 PM', '1', '7/3/2026 6:00:25 PM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (48, 'AL/2026-27/013', 'Akshay Pawar', 'Akshay Pawar', '9822344737', '9822344737@dealer.com', '7D3AD43B', 'Authorized', NULL, NULL, NULL, 'Thorat Colony Karvenagar Pune', NULL, '411052', 'Maharashtra', 'Pune', 'India', 'Thorat Colony Karvenagar Pune', NULL, '411052', 'Maharashtra', 'Pune', 'India', 'Dealer', NULL, 1, 0, '7/3/2026 6:00:25 PM', '1', '7/3/2026 6:00:25 PM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (49, 'AL/2026-27/014', 'Alpine Agencies', 'Alpine Agencies', '9968889182', '9968889182@dealer.com', '51193A5C', 'Authorized', '07ALMPG4628F1Z4', 'ALMPG4628F', NULL, 'D.B Gupta Road, Paharganj, Delhi', NULL, '110055', 'Delhi', 'Delhi', 'India', 'D.B Gupta Road, Paharganj, Delhi', NULL, '110055', 'Delhi', 'Delhi', 'India', 'Dealer', NULL, 1, 0, '7/3/2026 6:00:25 PM', '1', '7/3/2026 6:00:25 PM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (50, 'AL/2026-27/015', 'Ambica Trading Company', 'Ambica Trading Company', '9379215766', '9379215766@dealer.com', '5EB7C6EA', 'Authorized', '29AAGFA8276L1ZT', 'AAGFA8276L', NULL, 'Horamavu, Bengaluru', NULL, '560043', 'Karnataka', 'Bengaluru', 'India', 'Horamavu, Bengaluru', NULL, '560043', 'Karnataka', 'Bengaluru', 'India', 'Dealer', NULL, 1, 0, '7/3/2026 6:00:25 PM', '1', '7/3/2026 6:00:25 PM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (51, 'AL/2026-27/016', 'Amogh Wood', 'Amogh Wood', '9891104143', '9891104143@dealer.com', '4E2F008D', 'Authorized', '07AORPJ6834L1Z9', 'AORPJ6834L', NULL, 'Mansarover Garden, New Delhi', NULL, '110015', 'Delhi', 'New Delhi', 'India', 'Mansarover Garden, New Delhi', NULL, '110015', 'Delhi', 'New Delhi', 'India', 'Dealer', NULL, 1, 0, '7/3/2026 6:00:25 PM', '1', '7/3/2026 6:00:25 PM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (52, 'AL/2026-27/017', 'amol bulbule', 'amol bulbule', '9923153003', '9923153003@dealer.com', '920EDE29', 'Authorized', NULL, NULL, NULL, 'Wakad Pune', NULL, '411057', 'Maharashtra', 'Pune', 'India', 'Wakad Pune', NULL, '411057', 'Maharashtra', 'Pune', 'India', 'Dealer', NULL, 1, 0, '7/3/2026 6:00:25 PM', '1', '7/3/2026 6:00:25 PM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (53, 'AL/2026-27/018', 'Anon Infra', 'Anon Infra', '9886223255', '9886223255@dealer.com', 'C8758EC0', 'Authorized', '29DNBPS0948L1ZE', 'DNBPS0948L', NULL, 'JP Nagar 7th Phase, Bengaluru', NULL, '560078', 'Karnataka', 'Bengaluru', 'India', 'JP Nagar 7th Phase, Bengaluru', NULL, '560078', 'Karnataka', 'Bengaluru', 'India', 'Dealer', NULL, 1, 0, '7/3/2026 6:00:25 PM', '1', '7/3/2026 6:00:25 PM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (54, 'AL/2026-27/019', 'Antarang IN', 'Antarang IN', '8208048350', '8208048350@dealer.com', '954176CD', 'Authorized', NULL, NULL, NULL, 'Nigadi Pune', NULL, '411044', 'Maharashtra', 'Pune', 'India', 'Nigadi Pune', NULL, '411044', 'Maharashtra', 'Pune', 'India', 'Dealer', NULL, 1, 0, '7/3/2026 6:00:25 PM', '1', '7/3/2026 6:00:25 PM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (55, 'AL/2026-27/020', 'Anuj Sharma', 'Anuj Sharma', '8806113775', '8806113775@dealer.com', '9E04377A', 'Authorized', '9923809666', NULL, NULL, 'Kharadi Pune', NULL, '411014', 'Maharashtra', 'Pune', 'India', 'Kharadi Pune', NULL, '411014', 'Maharashtra', 'Pune', 'India', 'Dealer', NULL, 1, 0, '7/3/2026 6:00:25 PM', '1', '7/3/2026 6:00:25 PM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (56, 'AL/2026-27/021', 'Anurag Thorat', 'Anurag Thorat', '9890267080', '9890267080@dealer.com', '0E84C018', 'Authorized', NULL, NULL, NULL, 'Tathawade Pune', NULL, '411033', 'Maharashtra', 'Pune', 'India', 'Tathawade Pune', NULL, '411033', 'Maharashtra', 'Pune', 'India', 'Dealer', NULL, 1, 0, '7/3/2026 6:00:25 PM', '1', '7/3/2026 6:00:25 PM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (57, 'AL/2026-27/022', 'Archana Nilesh Waghmare', 'Archana Nilesh Waghmare', '9822244442', '9822244442@dealer.com', 'B1FEAB81', 'Authorized', NULL, NULL, NULL, 'Moshi Pune', NULL, '411070', 'Maharashtra', 'Pune', 'India', 'Moshi Pune', NULL, '411070', 'Maharashtra', 'Pune', 'India', 'Dealer', NULL, 1, 0, '7/3/2026 6:00:25 PM', '1', '7/3/2026 6:00:25 PM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (58, 'AL/2026-27/023', 'Arihant Ply and Laminates', 'Arihant Ply and Laminates', '9595808029', '9595808029@dealer.com', 'CBFFAAD9', 'Authorized', '24AKCPJ0853G1ZK', 'AKCPJ0853G', NULL, 'Udhana Magdalla Road Surat', NULL, '395007', 'Gujarat', 'Surat', 'India', 'Udhana Magdalla Road Surat', NULL, '395007', 'Gujarat', 'Surat', 'India', 'Dealer', NULL, 1, 0, '7/3/2026 6:00:25 PM', '1', '7/3/2026 6:00:25 PM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (59, 'AL/2026-27/024', 'Art Interior', 'Art Interior', '8668543470', '8668543470@dealer.com', 'E90B5401', 'Authorized', '27ACIFA9915A1ZI', 'ACIFA9915A', NULL, 'Chandrapur', NULL, '442401', 'Maharashtra', 'Chandrapur', 'India', 'Chandrapur', NULL, '442401', 'Maharashtra', 'Chandrapur', 'India', 'Dealer', NULL, 1, 0, '7/3/2026 6:00:25 PM', '1', '7/3/2026 6:00:25 PM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (60, 'AL/2026-27/025', 'Artzon', 'Artzon', '9898631202', '9898631202@dealer.com', '37A25F8D', 'Authorized', '24AFJPT9479C1ZY', 'AFJPT9479C', NULL, 'Thaltej Ahmedabad', NULL, '380060', 'Gujarat', 'Ahmedabad', 'India', 'Thaltej Ahmedabad', NULL, '380060', 'Gujarat', 'Ahmedabad', 'India', 'Dealer', NULL, 1, 0, '7/3/2026 6:00:25 PM', '1', '7/3/2026 6:00:25 PM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (61, 'AL/2026-27/026', 'ASHAPURA HOME DECOR', 'ASHAPURA HOME DECOR', '9724951511', '9724951511@dealer.com', '6F8BEF5B', 'Authorized', NULL, NULL, NULL, 'Khedbrahma Highway', NULL, '383255', 'Gujarat', 'Sabarkantha', 'India', 'Khedbrahma Highway', NULL, '383255', 'Gujarat', 'Sabarkantha', 'India', 'Dealer', NULL, 1, 0, '7/3/2026 6:00:25 PM', '1', '7/3/2026 6:00:25 PM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (62, 'AL/2026-27/027', 'Ashish Dhumal', 'Ashish Dhumal', '8356096008', '8356096008@dealer.com', '7A017D56', 'Authorized', NULL, NULL, NULL, 'Bhosari Pune', NULL, '411026', 'Maharashtra', 'Pune', 'India', 'Bhosari Pune', NULL, '411026', 'Maharashtra', 'Pune', 'India', 'Dealer', NULL, 1, 0, '7/3/2026 6:00:25 PM', '1', '7/3/2026 6:00:25 PM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (63, 'AL/2026-27/028', 'AV Furnishing Studio', 'AV Furnishing Studio', '9130000264', '9130000264@dealer.com', 'AA83A1FF', 'Authorized', NULL, NULL, NULL, 'Nanded', NULL, '431605', 'Maharashtra', 'Nanded', 'India', 'Nanded', NULL, '431605', 'Maharashtra', 'Nanded', 'India', 'Dealer', NULL, 1, 0, '7/3/2026 6:00:25 PM', '1', '7/3/2026 6:00:25 PM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (64, 'AL/2026-27/029', 'Baba Interior Studio', 'Baba Interior Studio', '7970081371', '7970081371@dealer.com', '71F454E1', 'Authorized', '22ABDFB9195K1Z5', 'ABDFB9195K', NULL, 'New Timber Market Raipur', NULL, '492001', 'Chhattisgarh', 'Raipur', 'India', 'New Timber Market Raipur', NULL, '492001', 'Chhattisgarh', 'Raipur', 'India', 'Dealer', NULL, 1, 0, '7/3/2026 6:00:25 PM', '1', '7/3/2026 6:00:25 PM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (84, 'AL/2026-27/030', 'B.M. Distributors', 'B.M. Distributors', '0000000000', 'b.m.distributors@dealer.com', '25AF3FC6', 'Authorized', NULL, NULL, NULL, 'Pune', NULL, '411042', 'Maharashtra', 'Pune', 'India', 'Pune', NULL, '411042', 'Maharashtra', 'Pune', 'India', 'Dealer', NULL, 1, 0, '7/3/2026 6:02:29 PM', '1', '7/3/2026 6:02:29 PM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (85, 'AL/2026-27/031', 'Bajaj Enterprises', 'Bajaj Enterprises', '9414006628', '9414006628@dealer.com', '2FCE430E', 'Authorized', '08AVKPB9851H1ZA', 'AVKPB9851H', NULL, 'Near Kothari Hospital Bikaner', NULL, '334001', 'Rajasthan', 'Bikaner', 'India', 'Near Kothari Hospital Bikaner', NULL, '334001', 'Rajasthan', 'Bikaner', 'India', 'Dealer', NULL, 1, 0, '7/3/2026 6:02:29 PM', '1', '7/3/2026 6:02:29 PM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (86, 'AL/2026-27/032', 'Balaji Ply Sales Private Limited', 'Balaji Ply Sales Private Limited', '9831656652', '9831656652@dealer.com', 'F4768CBB', 'Authorized', '19AADCB4071A1Z4', 'AADCB4071A', '', 'Chittaranjan Avenue Kolkata', 'WEST BENGAL', '700012', 'West Bengal', 'Kolkata', 'India', 'FAST N SAFE RAIL CARGO
', 'BHIWANDI', '421302', 'Maharashtra', 'Thane', 'India', 'Dealer', NULL, 1, 0, '7/3/2026 6:02:29 PM', '1', '7/7/2026 12:30:23 PM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (87, 'AL/2026-27/033', 'Balaji Plywood & Doors', 'Balaji Plywood & Doors', '8712748729', '8712748729@dealer.com', 'EA8A093E', 'Authorized', '37ABGFB3597G1Z6', 'ABGFB3597G', NULL, 'Visakhapatnam', NULL, '530016', 'Andhra Pradesh', 'Visakhapatnam', 'India', 'Visakhapatnam', NULL, '530016', 'Andhra Pradesh', 'Visakhapatnam', 'India', 'Dealer', NULL, 1, 0, '7/3/2026 6:02:29 PM', '1', '7/3/2026 6:02:29 PM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (88, 'AL/2026-27/034', 'Banashankari Glass & Plywoods', 'Banashankari Glass & Plywoods', '9353227845', '9353227845@dealer.com', '3B53EE28', 'Authorized', '29AAHFB1033H1ZR', 'AAHFB1033H', NULL, 'Bengaluru', NULL, '560079', 'Karnataka', 'Bengaluru', 'India', 'Bengaluru', NULL, '560079', 'Karnataka', 'Bengaluru', 'India', 'Dealer', NULL, 1, 0, '7/3/2026 6:02:29 PM', '1', '7/3/2026 6:02:29 PM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (89, 'AL/2026-27/035', 'Barkhedawala Plywood & Hardware', 'Barkhedawala Plywood & Hardware', '9926666656', '9926666656@dealer.com', '407464E8', 'Authorized', '23AHOPP6827D2Z6', 'AHOPP6827D', NULL, 'Mandsaur', NULL, '458883', 'Madhya Pradesh', 'Mandsaur', 'India', 'Mandsaur', NULL, '458883', 'Madhya Pradesh', 'Mandsaur', 'India', 'Dealer', NULL, 1, 0, '7/3/2026 6:02:29 PM', '1', '7/3/2026 6:02:29 PM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (90, 'AL/2026-27/036', 'Beech Impex Pvt Ltd', 'Beech Impex Pvt Ltd', '7676982400', '7676982400@dealer.com', '2BFB7516', 'Authorized', '29AABCB5923B1Z0', NULL, NULL, 'Bengaluru', NULL, '560076', 'Karnataka', 'Bengaluru', 'India', 'Bengaluru', NULL, '560076', 'Karnataka', 'Bengaluru', 'India', 'Dealer', NULL, 1, 0, '7/3/2026 6:02:29 PM', '1', '7/3/2026 6:02:29 PM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (91, 'AL/2026-27/037', 'Bhagwati Laminates', 'Bhagwati Laminates', '0000000000', 'bhagwatilaminates@dealer.com', '4FACC5E7', 'Authorized', '27ABHPJ6476B1ZN', 'ABHPJ6476B', NULL, 'Pune', NULL, '411042', 'Maharashtra', 'Pune', 'India', 'Pune', NULL, '411042', 'Maharashtra', 'Pune', 'India', 'Dealer', NULL, 1, 0, '7/3/2026 6:02:29 PM', '1', '7/3/2026 6:02:29 PM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (92, 'AL/2026-27/038', 'Bhavya Interior Gallery', 'Bhavya Interior Gallery', '9829021690', '9829021690@dealer.com', 'BCE2F38B', 'Authorized', '08AAGHN3082B1ZF', 'AAGHN3082B', NULL, 'Jodhpur', NULL, '342001', 'Rajasthan', 'Jodhpur', 'India', 'Jodhpur', NULL, '342001', 'Rajasthan', 'Jodhpur', 'India', 'Dealer', NULL, 1, 0, '7/3/2026 6:02:29 PM', '1', '7/3/2026 6:02:29 PM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (93, 'AL/2026-27/039', 'Bohnucci Design Studio', 'Bohnucci Design Studio', '9988048787', '9988048787@dealer.com', '2C1A9B4D', 'Authorized', '29ANRPM0753G2ZM', 'ANRPM0753G', NULL, 'Bengaluru', NULL, '560049', 'Karnataka', 'Bengaluru', 'India', 'Bengaluru', NULL, '560049', 'Karnataka', 'Bengaluru', 'India', 'Dealer', NULL, 1, 0, '7/3/2026 6:02:29 PM', '1', '7/3/2026 6:02:29 PM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (94, 'AL/2026-27/040', 'B Square Home Decor', 'B Square Home Decor', '9922922616', 'bsquarehomedecor1@dealer.com', 'C8113BB9', 'Authorized', '27ABEFB0299H1ZE', 'ABEFB0299H', NULL, 'Yavatmal', NULL, '445001', 'Maharashtra', 'Yavatmal', 'India', 'Yavatmal', NULL, '445001', 'Maharashtra', 'Yavatmal', 'India', 'Dealer', NULL, 1, 0, '7/3/2026 6:04:09 PM', '1', '7/3/2026 6:04:09 PM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (95, 'AL/2026-27/041', 'B. Timber Industries', 'B. Timber Industries', '9829053066', 'b.timberindustries2@dealer.com', 'B6A06AAA', 'Authorized', '08ADHPK9889M1ZG', 'ADHPK9889M', NULL, 'Kota', NULL, '324007', 'Rajasthan', 'Kota', 'India', 'Kota', NULL, '324007', 'Rajasthan', 'Kota', 'India', 'Dealer', NULL, 1, 0, '7/3/2026 6:04:09 PM', '1', '7/3/2026 6:04:09 PM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (96, 'AL/2026-27/042', 'Bombay Hardware Stores', 'Bombay Hardware Stores', '9979999971', 'bombayhardwarestores3@dealer.com', '84359947', 'Authorized', '27AAMPB1125F1Z8', 'AAMPB1125F', NULL, 'Jalgaon', NULL, '425001', 'Maharashtra', 'Jalgaon', 'India', 'Jalgaon', NULL, '425001', 'Maharashtra', 'Jalgaon', 'India', 'Dealer', NULL, 1, 0, '7/3/2026 6:04:09 PM', '1', '7/3/2026 6:04:09 PM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (97, 'AL/2026-27/043', 'Casa Lusso', 'Casa Lusso', '8886660875', 'casalusso4@dealer.com', 'AA5F1863', 'Authorized', NULL, NULL, NULL, 'Hyderabad', NULL, '500084', 'Telangana', 'Hyderabad', 'India', 'Hyderabad', NULL, '500084', 'Telangana', 'Hyderabad', 'India', 'Dealer', NULL, 1, 0, '7/3/2026 6:04:09 PM', '1', '7/3/2026 6:04:09 PM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (98, 'AL/2026-27/044', 'CELESTIA', 'CELESTIA', '9979999971', 'celestia5@dealer.com', '56F716EB', 'Authorized', NULL, NULL, NULL, 'Rajkot', NULL, '360004', 'Gujarat', 'Rajkot', 'India', 'Rajkot', NULL, '360004', 'Gujarat', 'Rajkot', 'India', 'Dealer', NULL, 1, 0, '7/3/2026 6:04:09 PM', '1', '7/3/2026 6:04:09 PM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (99, 'AL/2026-27/045', 'Chandrawanshi', 'Chandrawanshi', '9890178108', 'chandrawanshi6@dealer.com', '6DC8086D', 'Authorized', NULL, NULL, NULL, NULL, NULL, '431007', 'Maharashtra', NULL, 'India', NULL, NULL, '431007', 'Maharashtra', NULL, 'India', 'Dealer', NULL, 1, 0, '7/3/2026 6:04:09 PM', '1', '7/3/2026 6:04:09 PM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (100, 'AL/2026-27/046', 'Changs Hotel', 'Changs Hotel', '0000000000', 'changshotel7@dealer.com', '5F67A851', 'Authorized', NULL, NULL, NULL, 'Camp Pune', NULL, '411001', 'Maharashtra', 'Pune', 'India', 'Camp Pune', NULL, '411001', 'Maharashtra', 'Pune', 'India', 'Dealer', NULL, 1, 0, '7/3/2026 6:04:09 PM', '1', '7/3/2026 6:04:09 PM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (101, 'AL/2026-27/047', 'Chetan Dabhade', 'Chetan Dabhade', '0000000000', 'chetandabhade8@dealer.com', '7DBF138C', 'Authorized', NULL, NULL, NULL, NULL, NULL, NULL, 'Maharashtra', NULL, 'India', NULL, NULL, NULL, 'Maharashtra', NULL, 'India', 'Dealer', NULL, 1, 0, '7/3/2026 6:04:09 PM', '1', '7/3/2026 6:04:09 PM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (102, 'AL/2026-27/048', 'Chintamani Distributors', 'Chintamani Distributors', '9890178108', 'chintamanidistributors9@dealer.com', 'B3713C4C', 'Authorized', '27FOQPK4463A1ZS', 'FOQPK4463A', NULL, 'Aurangabad', NULL, '431007', 'Maharashtra', 'Aurangabad', 'India', 'Aurangabad', NULL, '431007', 'Maharashtra', 'Aurangabad', 'India', 'Dealer', NULL, 1, 0, '7/3/2026 6:04:09 PM', '1', '7/3/2026 6:04:09 PM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (103, 'AL/2026-27/049', 'Core', 'Core', '9725021351', 'core10@dealer.com', '0D47FBDF', 'Authorized', '24AAPFM8965P1Z6', 'AAPFM8965P', NULL, 'Surat', NULL, '395023', 'Gujarat', 'Surat', 'India', 'Surat', NULL, '395023', 'Gujarat', 'Surat', 'India', 'Dealer', NULL, 1, 0, '7/3/2026 6:04:09 PM', '1', '7/3/2026 6:04:09 PM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (104, 'AL/2026-27/050', 'Creative Surfaces', 'Creative Surfaces', '9980092047', 'creativesurfaces11@dealer.com', '3E7F2404', 'Authorized', '29AANFC2589D1Z5', 'AANFC2589D', NULL, 'Bengaluru', NULL, '560062', 'Karnataka', 'Bengaluru', 'India', 'Bengaluru', NULL, '560062', 'Karnataka', 'Bengaluru', 'India', 'Dealer', NULL, 1, 0, '7/3/2026 6:04:09 PM', '1', '7/3/2026 6:04:09 PM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (105, 'AL/2026-27/051', 'Decor Design', 'Decor Design', '7620827182', 'decordesign12@dealer.com', '547DB816', 'Authorized', NULL, NULL, NULL, 'Talegaon Dabhade', NULL, '410506', 'Maharashtra', 'Pune', 'India', 'Talegaon Dabhade', NULL, '410506', 'Maharashtra', 'Pune', 'India', 'Dealer', NULL, 1, 0, '7/3/2026 6:04:09 PM', '1', '7/3/2026 6:04:09 PM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (106, 'AL/2026-27/052', 'DECORMORE', 'DECORMORE', '7737927761', 'decormore13@dealer.com', '0B48435B', 'Authorized', NULL, NULL, NULL, 'Bhilwara', NULL, '311001', 'Rajasthan', 'Bhilwara', 'India', 'Bhilwara', NULL, '311001', 'Rajasthan', 'Bhilwara', 'India', 'Dealer', NULL, 1, 0, '7/3/2026 6:04:09 PM', '1', '7/3/2026 6:04:09 PM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (107, 'AL/2026-27/053', 'DEEP TRADING CO.', 'DEEP TRADING CO.', '8980500896', 'deeptradingco.14@dealer.com', 'EB9F4F06', 'Authorized', NULL, NULL, NULL, 'Ahmedabad', NULL, '380007', 'Gujarat', 'Ahmedabad', 'India', 'Ahmedabad', NULL, '380007', 'Gujarat', 'Ahmedabad', 'India', 'Dealer', NULL, 1, 0, '7/3/2026 6:04:09 PM', '1', '7/3/2026 6:04:09 PM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (108, 'AL/2026-27/054', 'deepak thavrani', 'deepak thavrani', '9766353599', 'deepakthavrani15@dealer.com', '37152BAD', 'Authorized', NULL, NULL, NULL, 'Pimple Saudagar', NULL, '411027', 'Maharashtra', 'Pune', 'India', 'Pimple Saudagar', NULL, '411027', 'Maharashtra', 'Pune', 'India', 'Dealer', NULL, 1, 0, '7/3/2026 6:04:09 PM', '1', '7/3/2026 6:04:09 PM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (109, 'AL/2026-27/055', 'Devanshi Decor', 'Devanshi Decor', '9920029618', 'devanshidecor16@dealer.com', '31BDBDEF', 'Authorized', '27AATFD8926F1ZX', 'AATFD8926F', NULL, 'Navi Mumbai', NULL, '400710', 'Maharashtra', 'Thane', 'India', 'Navi Mumbai', NULL, '400710', 'Maharashtra', 'Thane', 'India', 'Dealer', NULL, 1, 0, '7/3/2026 6:04:09 PM', '1', '7/3/2026 6:04:09 PM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (110, 'AL/2026-27/056', 'Devanshi Inteerior Hubs', 'Devanshi Inteerior Hubs', '9702455511', 'devanshiinteeriorhubs17@dealer.com', '16002D50', 'Authorized', '27AAYFD4472D1Z3', 'AAYFD4472D', NULL, 'Pune', NULL, '411060', 'Maharashtra', 'Pune', 'India', 'Pune', NULL, '411060', 'Maharashtra', 'Pune', 'India', 'Dealer', NULL, 1, 0, '7/3/2026 6:04:09 PM', '1', '7/3/2026 6:04:09 PM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (111, 'AL/2026-27/057', 'Devanshi Laminates Pvt Ltd', 'Devanshi Laminates Pvt Ltd', '9819522442', 'devanshilaminatespvtltd18@dealer.com', '0062A287', 'Authorized', '27AAHCD6087G1ZD', 'AAHCD6087G', NULL, 'Navi Mumbai', NULL, '400710', 'Maharashtra', 'Thane', 'India', 'Navi Mumbai', NULL, '400710', 'Maharashtra', 'Thane', 'India', 'Dealer', NULL, 1, 0, '7/3/2026 6:04:09 PM', '1', '7/3/2026 6:04:09 PM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (112, 'AL/2026-27/058', 'dhananjay chandratre', 'dhananjay chandratre', '9922503240', 'dhananjaychandratre19@dealer.com', 'F28F0AA9', 'Authorized', NULL, NULL, NULL, 'Dapodi Pune', NULL, '411012', 'Maharashtra', 'Pune', 'India', 'Dapodi Pune', NULL, '411012', 'Maharashtra', 'Pune', 'India', 'Dealer', NULL, 1, 0, '7/3/2026 6:04:09 PM', '1', '7/3/2026 6:04:09 PM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (113, 'AL/2026-27/059', 'DHARMENDRA DHOLU', 'DHARMENDRA DHOLU', '9595852249', 'dharmendradholu20@dealer.com', '27FB9D0E', 'Authorized', NULL, NULL, NULL, 'Moshi Pune', NULL, '412105', 'Maharashtra', 'Pune', 'India', 'Moshi Pune', NULL, '412105', 'Maharashtra', 'Pune', 'India', 'Dealer', NULL, 1, 0, '7/3/2026 6:04:09 PM', '1', '7/3/2026 6:04:09 PM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (114, 'AL/2026-27/060', 'Dheeraj Ply & Veneer', 'Dheeraj Ply & Veneer', '9630064954', 'dheerajply&veneer21@dealer.com', 'D2A24893', 'Authorized', '23AYGPS8904D1ZF', 'AYGPS8904D', NULL, 'Indore', NULL, '452020', 'Madhya Pradesh', 'Indore', 'India', 'Indore', NULL, '452020', 'Madhya Pradesh', 'Indore', 'India', 'Dealer', NULL, 1, 0, '7/3/2026 6:04:09 PM', '1', '7/3/2026 6:04:09 PM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (115, 'AL/2026-27/061', 'Dhi Concepts', 'Dhi Concepts', '9881801980', 'dhiconcepts22@dealer.com', '2D743D26', 'Authorized', NULL, NULL, NULL, 'Charholi Pune', NULL, '4121005', 'Maharashtra', 'Pune', 'India', 'Charholi Pune', NULL, '4121005', 'Maharashtra', 'Pune', 'India', 'Dealer', NULL, 1, 0, '7/3/2026 6:04:09 PM', '1', '7/3/2026 6:04:09 PM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (116, 'AL/2026-27/062', 'Dhiresh Decor', 'Dhiresh Decor', '8074957741', 'dhireshdecor23@dealer.com', '2DE1A2D5', 'Authorized', '36AEXPR1316R1ZK', 'AEXPR1316R', NULL, 'Hyderabad', NULL, '500001', 'Telangana', 'Hyderabad', 'India', 'Hyderabad', NULL, '500001', 'Telangana', 'Hyderabad', 'India', 'Dealer', NULL, 1, 0, '7/3/2026 6:04:09 PM', '1', '7/3/2026 6:04:09 PM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (117, 'AL/2026-27/063', 'Diamond Hardware and Interiors', 'Diamond Hardware and Interiors', '9010321116', 'diamondhardwareandinteriors24@dealer.com', 'E23CB3F4', 'Authorized', '37AAYFD8795R1ZR', 'AAYFD8795R', NULL, 'Rajahmundry', NULL, '533101', 'Andhra Pradesh', 'Rajahmundry', 'India', 'Rajahmundry', NULL, '533101', 'Andhra Pradesh', 'Rajahmundry', 'India', 'Dealer', NULL, 1, 0, '7/3/2026 6:04:09 PM', '1', '7/3/2026 6:04:09 PM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (118, 'AL/2026-27/064', 'Dnyaneshwar', 'Dnyaneshwar', '9921704704', 'dnyaneshwar25@dealer.com', 'B8F6274B', 'Authorized', NULL, NULL, NULL, 'Baner Pune', NULL, '411045', 'Maharashtra', 'Pune', 'India', 'Baner Pune', NULL, '411045', 'Maharashtra', 'Pune', 'India', 'Dealer', NULL, 1, 0, '7/3/2026 6:04:09 PM', '1', '7/3/2026 6:04:09 PM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (119, 'AL/2026-27/065', 'Doors - N - Windows', 'Doors - N - Windows', '8873858989', 'doors-n-windows26@dealer.com', '9A609E6B', 'Authorized', '10CAGPM8069K1ZG', 'CAGPM8069K', NULL, 'Darbhanga', NULL, '846001', 'Bihar', 'Darbhanga', 'India', 'Darbhanga', NULL, '846001', 'Bihar', 'Darbhanga', 'India', 'Dealer', NULL, 1, 0, '7/3/2026 6:04:09 PM', '1', '7/3/2026 6:04:09 PM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (120, 'AL/2026-27/066', 'Dream Decor', 'Dream Decor', '9893000292', 'dreamdecor27@dealer.com', '259DEDA4', 'Authorized', '23AAVFD2708F1ZJ', 'AAVFD2708F', NULL, 'Indore', NULL, '452010', 'Madhya Pradesh', 'Indore', 'India', 'Indore', NULL, '452010', 'Madhya Pradesh', 'Indore', 'India', 'Dealer', NULL, 1, 0, '7/3/2026 6:04:09 PM', '1', '7/3/2026 6:04:09 PM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (121, 'AL/2026-27/067', 'Dream Design Decor', 'Dream Design Decor', '9929133344', 'dreamdesigndecor28@dealer.com', '7859E81F', 'Authorized', '08AAJFD8603M1Z2', 'AAJFD8603M', NULL, 'Jaipur', NULL, '302018', 'Rajasthan', 'Jaipur', 'India', 'Jaipur', NULL, '302018', 'Rajasthan', 'Jaipur', 'India', 'Dealer', NULL, 1, 0, '7/3/2026 6:04:09 PM', '1', '7/3/2026 6:04:09 PM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (122, 'AL/2026-27/068', 'Eikai Surfaces LLP', 'Eikai Surfaces LLP', '7567740497', 'eikaisurfacesllp29@dealer.com', 'FE684C36', 'Authorized', '24AAKFE2495F1ZF', 'AAKFE2495F', NULL, 'Surat', NULL, '395017', 'Gujarat', 'Surat', 'India', 'Surat', NULL, '395017', 'Gujarat', 'Surat', 'India', 'Dealer', NULL, 1, 0, '7/3/2026 6:04:09 PM', '1', '7/3/2026 6:04:09 PM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (123, 'AL/2026-27/069', 'Eleganz Studio', 'Eleganz Studio', '9427217266', 'eleganzstudio30@dealer.com', '4DEC2D1A', 'Authorized', '24AAKFE9057D1ZF', 'AAKFE9057D', NULL, 'Jamnagar', NULL, '361002', 'Gujarat', 'Jamnagar', 'India', 'Jamnagar', NULL, '361002', 'Gujarat', 'Jamnagar', 'India', 'Dealer', NULL, 1, 0, '7/3/2026 6:04:09 PM', '1', '7/3/2026 6:04:09 PM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (124, 'AL/2026-27/070', 'Eurotrend Furnitures Pvt Ltd', 'Eurotrend Furnitures Pvt Ltd', '8808801014', 'eurotrendfurniturespvtltd31@dealer.com', 'CA4EBFAF', 'Authorized', '27AAACE3609C2Z4', 'AAACE3609C', NULL, 'Navi Mumbai', NULL, '400705', 'Maharashtra', 'Thane', 'India', 'Navi Mumbai', NULL, '400705', 'Maharashtra', 'Thane', 'India', 'Dealer', NULL, 1, 0, '7/3/2026 6:04:09 PM', '1', '7/3/2026 6:04:09 PM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (125, 'AL/2026-27/071', 'First Feel Ventures LLP', 'First Feel Ventures LLP', '8080925217', 'firstfeelventuresllp32@dealer.com', 'FE6830B1', 'Authorized', '30AAJFF2269F1ZQ', 'AAJFF2269F', NULL, 'Goa', NULL, '403722', 'Goa', 'South Goa', 'India', 'Goa', NULL, '403722', 'Goa', 'South Goa', 'India', 'Dealer', NULL, 1, 0, '7/3/2026 6:04:09 PM', '1', '7/3/2026 6:04:09 PM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (126, 'AL/2026-27/072', 'Gajanan Enterprises', 'Gajanan Enterprises', '8882114444', 'gajananenterprises33@dealer.com', '9EB3F2DA', 'Authorized', '24AAUFG8175A1Z8', NULL, NULL, 'Anand', NULL, '388120', 'Gujarat', 'Anand', 'India', 'Anand', NULL, '388120', 'Gujarat', 'Anand', 'India', 'Dealer', NULL, 1, 0, '7/3/2026 6:04:09 PM', '1', '7/3/2026 6:04:09 PM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (127, 'AL/2026-27/073', 'Galaxy Decor', 'Galaxy Decor', '9993607715', 'galaxydecor34@dealer.com', 'CF68FD45', 'Authorized', '23AQTPC8405E1Z0', 'AQTPC8405E', NULL, 'Indore', NULL, '452001', 'Madhya Pradesh', 'Indore', 'India', 'Indore', NULL, '452001', 'Madhya Pradesh', 'Indore', 'India', 'Dealer', NULL, 1, 0, '7/3/2026 6:04:09 PM', '1', '7/3/2026 6:04:09 PM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (128, 'AL/2026-27/074', 'Ganpati Lam & Ply Pvt Ltd', 'Ganpati Lam & Ply Pvt Ltd', '9439702221', 'ganpatilam&plypvtltd35@dealer.com', '1117573C', 'Authorized', '21AACCG7626H1ZU', 'AACCG7626H', NULL, 'Bhubaneswar', NULL, '751001', 'Odisha', 'Khordha', 'India', 'Bhubaneswar', NULL, '751001', 'Odisha', 'Khordha', 'India', 'Dealer', NULL, 1, 0, '7/3/2026 6:04:09 PM', '1', '7/3/2026 6:04:09 PM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (129, 'AL/2026-27/075', 'Gautam Plywood & Timber', 'Gautam Plywood & Timber', '9371580007', 'gautamplywood&timber36@dealer.com', 'E9DB43C4', 'Authorized', '27ACLPP9717G1Z3', 'ACLPP9717G', NULL, 'Nashik', NULL, '422005', 'Maharashtra', 'Nashik', 'India', 'Nashik', NULL, '422005', 'Maharashtra', 'Nashik', 'India', 'Dealer', NULL, 1, 0, '7/3/2026 6:04:09 PM', '1', '7/3/2026 6:04:09 PM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (130, 'AL/2026-27/076', 'Gayatri Decors', 'Gayatri Decors', '9866986633', 'gayatridecors37@dealer.com', '2F5BDA37', 'Authorized', '36AAZFG4576A1Z1', 'AAZFG4576A', NULL, 'Hyderabad', NULL, '500001', 'Telangana', 'Hyderabad', 'India', 'Hyderabad', NULL, '500001', 'Telangana', 'Hyderabad', 'India', 'Dealer', NULL, 1, 0, '7/3/2026 6:04:09 PM', '1', '7/3/2026 6:04:09 PM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (131, 'AL/2026-27/077', 'Gayatri Traders', 'Gayatri Traders', '9823125158', 'gayatritraders38@dealer.com', '9FCB01AB', 'Authorized', '30AEOPP9565P1ZK', 'AEOPP9565P', NULL, 'South Goa', NULL, '403601', 'Goa', 'Margao', 'India', 'South Goa', NULL, '403601', 'Goa', 'Margao', 'India', 'Dealer', NULL, 1, 0, '7/3/2026 6:04:09 PM', '1', '7/3/2026 6:04:09 PM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (132, 'AL/2026-27/078', 'Gmc Marketing', 'Gmc Marketing', '9145333175', 'gmcmarketing39@dealer.com', 'E3DAB36A', 'Authorized', '27AAGFG9247F1Z7', 'AAGFG9247F', NULL, 'Pune', NULL, '411011', 'Maharashtra', 'Pune', 'India', 'Pune', NULL, '411011', 'Maharashtra', 'Pune', 'India', 'Dealer', NULL, 1, 0, '7/3/2026 6:04:09 PM', '1', '7/3/2026 6:04:09 PM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (133, 'AL/2026-27/079', 'Gruhakala Design Studio', 'Gruhakala Design Studio', '9900088667', 'gruhakaladesignstudio40@dealer.com', '2FECFC01', 'Authorized', '29AMHPN7140B1Z5', 'AMHPN7140B', NULL, 'Bengaluru', NULL, '560064', 'Karnataka', 'Bengaluru', 'India', 'Bengaluru', NULL, '560064', 'Karnataka', 'Bengaluru', 'India', 'Dealer', NULL, 1, 0, '7/3/2026 6:04:09 PM', '1', '7/3/2026 6:04:09 PM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (151, 'AL/2026-27/097', 'Devanshi Laminates Private Limited', 'Devanshi Laminates Private Limited', '9819522442', 'devanshilaminatesprivatelimited981952244218@demo.com', '123', 'Authorized', '27AAHCD6087G1ZD', 'AAHCD6087G', '', 'TTC Industrial Area, Khairane, Navi Mumbai', NULL, '400710', 'Maharashtra', 'Thane', 'India', 'TTC Industrial Area, Khairane, Navi Mumbai', NULL, '400710', 'Maharashtra', 'Thane', 'India', 'Dealer', '', 1, 0, '7/3/2026 6:05:16 PM', '1', '7/3/2026 6:05:16 PM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (180, 'AL/2026-27/108', 'Eurotrend Furnitures Private Limited', 'Eurotrend Furnitures Private Limited', '8808801014', 'eurotrend8808801014@demo.com', '123', 'Authorized', '27AAACE3609C2Z4', 'AAACE3609C', NULL, 'Plot No A-127, TTC Industrial Area, Navi Mumbai', NULL, '400705', 'Maharashtra', 'Thane', 'India', 'Plot No A-127, TTC Industrial Area, Navi Mumbai', NULL, '400705', 'Maharashtra', 'Thane', 'India', 'Dealer', NULL, 1, 0, '7/4/2026 10:33:51 AM', '1', '7/4/2026 10:33:51 AM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (184, 'AL/2026-27/112', 'Ganpati Lam & Ply Pvt. Ltd.', 'Ganpati Lam & Ply Pvt. Ltd.', '9439702221', 'ganpatilam9439702221@demo.com', '123', 'Authorized', '21AACCG7626H1ZU', 'AACCG7626H', NULL, 'Plot No. SCR-70, Unit-3, Kharvel Nagar, Bhubaneswar', NULL, '751001', 'Odisha', 'Bhubaneswar', 'India', 'Plot No. SCR-70, Unit-3, Kharvel Nagar, Bhubaneswar', NULL, '751001', 'Odisha', 'Bhubaneswar', 'India', 'Dealer', NULL, 1, 0, '7/4/2026 10:42:41 AM', '1', '7/4/2026 10:42:41 AM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (185, 'AL/2026-27/113', 'Gautam Plywood and Timber', 'Gautam Plywood and Timber', '9371580007', 'gautamplywood9371580007@demo.com', '123', 'Authorized', '27ACLPP9717G1Z3', 'ACLPP9717G', NULL, 'Shop No. 11/12, Yeolekar Complex, Nashik', NULL, '422005', 'Maharashtra', 'Nashik', 'India', 'Shop No. 11/12, Yeolekar Complex, Nashik', NULL, '422005', 'Maharashtra', 'Nashik', 'India', 'Dealer', NULL, 1, 0, '7/4/2026 10:42:41 AM', '1', '7/4/2026 10:42:41 AM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (190, 'AL/2026-27/118', 'Gshantii Furniture Industries Llp', 'Gshantii Furniture Industries Llp', '9669516666', 'gshantii9669516666@demo.com', '123', 'Authorized', '23AASFG1902D1ZT', 'AASFG1902D', NULL, 'Kameshwar Agro Krishi Audhyogik Nagar, Burhanpur', NULL, '450331', 'Madhya Pradesh', 'Burhanpur', 'India', 'Kameshwar Agro Krishi Audhyogik Nagar, Burhanpur', NULL, '450331', 'Madhya Pradesh', 'Burhanpur', 'India', 'Dealer', NULL, 1, 0, '7/4/2026 10:42:41 AM', '1', '7/4/2026 10:42:41 AM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (191, 'AL/2026-27/119', 'Hanuman steel traders', 'Hanuman steel traders', '9421036714', 'hanumansteel9421036714@demo.com', '123', 'Authorized', '27APVPC3240C1Z5', 'APVPC3240C', NULL, 'Bhosari Road, Pimpri Chinchwad', NULL, '411026', 'Maharashtra', 'Pune', 'India', 'Bhosari Road, Pimpri Chinchwad', NULL, '411026', 'Maharashtra', 'Pune', 'India', 'Dealer', NULL, 1, 0, '7/4/2026 10:42:41 AM', '1', '7/4/2026 10:42:41 AM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (192, 'AL/2026-27/120', 'Harshal pandit', 'Harshal pandit', '9673728192', 'harshal9673728192@demo.com', '123', 'Authorized', NULL, NULL, NULL, 'Bhumkar Nagar, Wakad, Pune', NULL, '411033', 'Maharashtra', 'Pune', 'India', 'Bhumkar Nagar, Wakad, Pune', NULL, '411033', 'Maharashtra', 'Pune', 'India', 'Dealer', NULL, 1, 0, '7/4/2026 10:42:41 AM', '1', '7/4/2026 10:42:41 AM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (193, 'AL/2026-27/121', 'HARSH TIMBERMART', 'HARSH TIMBERMART', '9673728192', 'harshwood9673728192@demo.com', '123', 'Authorized', NULL, NULL, NULL, 'Dombivli East', NULL, '421201', 'Maharashtra', 'Thane', 'India', 'Dombivli East', NULL, '421201', 'Maharashtra', 'Thane', 'India', 'Dealer', NULL, 1, 0, '7/4/2026 10:42:41 AM', '1', '7/4/2026 10:42:41 AM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (194, 'AL/2026-27/122', 'Heda Plywoods', 'Heda Plywoods', '9916668511', 'hedaplywood9916668511@demo.com', '123', 'Authorized', '29AAAFH8780L1ZR', 'AAAFH8780L', NULL, 'Tilakwadi, Belagavi', NULL, '590006', 'Karnataka', 'Belagavi', 'India', 'Tilakwadi, Belagavi', NULL, '590006', 'Karnataka', 'Belagavi', 'India', 'Dealer', NULL, 1, 0, '7/4/2026 10:42:41 AM', '1', '7/4/2026 10:42:41 AM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (195, 'AL/2026-27/123', 'HINCH', 'HINCH', '9742221600', 'hinch9742221600@demo.com', '123', 'Authorized', NULL, NULL, NULL, 'Shilpa Avenue Colony, Hyderabad', NULL, '500085', 'Telangana', 'Hyderabad', 'India', 'Shilpa Avenue Colony, Hyderabad', NULL, '500085', 'Telangana', 'Hyderabad', 'India', 'Dealer', NULL, 1, 0, '7/4/2026 10:42:41 AM', '1', '7/4/2026 10:42:41 AM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (196, 'AL/2026-27/124', 'Hindva Hardware and Ply Wood', 'Hindva Hardware and Ply Wood', '9601762832', 'hindvahardware9601762832@demo.com', '123', 'Authorized', '24BIVPD6991H1ZP', 'BIVPD6991H', NULL, 'Surat Zoo Sarthana Jakatnaka', NULL, '395006', 'Gujarat', 'Surat', 'India', 'Surat Zoo Sarthana Jakatnaka', NULL, '395006', 'Gujarat', 'Surat', 'India', 'Dealer', NULL, 1, 0, '7/4/2026 10:42:41 AM', '1', '7/4/2026 10:42:41 AM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (197, 'AL/2026-27/125', 'I-Creation', 'I-Creation', '9337892046', 'icreation9337892046@demo.com', '123', 'Authorized', '21DDGPP4057Q1Z3', 'DDGPP4057Q', NULL, 'Udit Nagar, Rourkela', NULL, '769012', 'Odisha', 'Rourkela', 'India', 'Udit Nagar, Rourkela', NULL, '769012', 'Odisha', 'Rourkela', 'India', 'Dealer', NULL, 1, 0, '7/4/2026 10:42:41 AM', '1', '7/4/2026 10:42:41 AM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (198, 'AL/2026-27/126', 'Imagine Interio (Kolkata)', 'Imagine Interio (Kolkata)', '9836119963', 'imagine9836119963@demo.com', '123', 'Authorized', '19AALFI2069L1ZU', 'AALFI2069L', NULL, 'Topsia Road, Kolkata', NULL, '700046', 'West Bengal', 'Kolkata', 'India', 'Topsia Road, Kolkata', NULL, '700046', 'West Bengal', 'Kolkata', 'India', 'Dealer', NULL, 1, 0, '7/4/2026 10:42:41 AM', '1', '7/4/2026 10:42:41 AM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (199, 'AL/2026-27/127', 'Imagine Interio (Odisha)', 'Imagine Interio (Odisha)', '7008547408', 'imagineodisha7008547408@demo.com', '123', 'Authorized', '21ADCPJ2935Q1ZH', 'ADCPJ2935Q', NULL, 'Shop No.1B, Ground Floor, Sahej Success, Rourkela', NULL, '769012', 'Odisha', 'Rourkela', 'India', 'Shop No.1B, Ground Floor, Sahej Success, Rourkela', NULL, '769012', 'Odisha', 'Rourkela', 'India', 'Dealer', NULL, 1, 0, '7/4/2026 10:44:04 AM', '1', '7/4/2026 10:44:04 AM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (200, 'AL/2026-27/128', 'Imagine Interio (W B)', 'Imagine Interio (W B)', '9732723424', 'imaginewb9732723424@demo.com', '123', 'Authorized', '19ANKPJ4301L1ZV', 'ANKPJ4301L', NULL, 'Sevoke Road, Siliguri', NULL, '734005', 'West Bengal', 'Siliguri', 'India', 'Sevoke Road, Siliguri', NULL, '734005', 'West Bengal', 'Siliguri', 'India', 'Dealer', NULL, 1, 0, '7/4/2026 10:44:04 AM', '1', '7/4/2026 10:44:04 AM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (201, 'AL/2026-27/129', 'Infinity', 'Infinity', '7410075272', 'infinity7410075272@demo.com', '123', 'Authorized', NULL, NULL, NULL, 'Gagan UNO, Dhole Patil Road, Pune', NULL, '411001', 'Maharashtra', 'Pune', 'India', 'Gagan UNO, Dhole Patil Road, Pune', NULL, '411001', 'Maharashtra', 'Pune', 'India', 'Dealer', NULL, 1, 0, '7/4/2026 10:44:04 AM', '1', '7/4/2026 10:44:04 AM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (202, 'AL/2026-27/130', 'Innovative Dezine', 'Innovative Dezine', '8127777771', 'innovative8127777771@demo.com', '123', 'Authorized', '09AAIFI1857M1ZU', 'AAIFI1857M', NULL, 'Arya Nagar, Kanpur', NULL, '208002', 'Uttar Pradesh', 'Kanpur', 'India', 'Arya Nagar, Kanpur', NULL, '208002', 'Uttar Pradesh', 'Kanpur', 'India', 'Dealer', NULL, 1, 0, '7/4/2026 10:44:04 AM', '1', '7/4/2026 10:44:04 AM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (203, 'AL/2026-27/131', 'Ishita Hemani', 'Ishita Hemani', '8554996742', 'ishita8554996742@demo.com', '123', 'Authorized', NULL, NULL, NULL, 'Sai Pearl, Pimple Saudagar, Pune', NULL, '411027', 'Maharashtra', 'Pune', 'India', 'Sai Pearl, Pimple Saudagar, Pune', NULL, '411027', 'Maharashtra', 'Pune', 'India', 'Dealer', NULL, 1, 0, '7/4/2026 10:44:04 AM', '1', '7/4/2026 10:44:04 AM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (204, 'AL/2026-27/132', 'Ishwar Hardware & Laminates', 'Ishwar Hardware & Laminates', '8999877488', 'ishwar8999877488@demo.com', '123', 'Authorized', NULL, NULL, NULL, 'Alankar Market, Akola', NULL, '444001', 'Maharashtra', 'Akola', 'India', 'Alankar Market, Akola', NULL, '444001', 'Maharashtra', 'Akola', 'India', 'Dealer', NULL, 1, 0, '7/4/2026 10:44:04 AM', '1', '7/4/2026 10:44:04 AM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (205, 'AL/2026-27/133', 'Jaylaxmi Traders', 'Jaylaxmi Traders', 'NULL', 'jaylaxmi@example.com', '123', 'Authorized', '27BEGPC2618H1ZS', 'BEGPC2618H', NULL, 'Talwade Road, Pune', NULL, '411062', 'Maharashtra', 'Pune', 'India', 'Talwade Road, Pune', NULL, '411062', 'Maharashtra', 'Pune', 'India', 'Dealer', NULL, 1, 0, '7/4/2026 10:44:04 AM', '1', '7/4/2026 10:44:04 AM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (206, 'AL/2026-27/134', 'Kailash Enterprises', 'Kailash Enterprises', '8956581333', 'kailash8956581333@demo.com', '123', 'Authorized', '27AANPP0574B1ZQ', 'AANPP0574B', NULL, 'Lakadganj, Nagpur', NULL, '440008', 'Maharashtra', 'Nagpur', 'India', 'Lakadganj, Nagpur', NULL, '440008', 'Maharashtra', 'Nagpur', 'India', 'Dealer', NULL, 1, 0, '7/4/2026 10:44:04 AM', '1', '7/4/2026 10:44:04 AM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (207, 'AL/2026-27/135', 'Kalamaya Architech', 'Kalamaya Architech', '7768922727', 'kalamaya7768922727@demo.com', '123', 'Authorized', NULL, NULL, NULL, 'Akurdi, Pune', NULL, '411035', 'Maharashtra', 'Pune', 'India', 'Akurdi, Pune', NULL, '411035', 'Maharashtra', 'Pune', 'India', 'Dealer', NULL, 1, 0, '7/4/2026 10:44:04 AM', '1', '7/4/2026 10:44:04 AM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (208, 'AL/2026-27/136', 'Kanhaiya Sales', 'Kanhaiya Sales', '9977106000', 'kanhaiya9977106000@demo.com', '123', 'Authorized', '22BAPPA6441P1ZH', 'BAPPA6441P', NULL, 'Raipur', NULL, '492009', 'Chhattisgarh', 'Raipur', 'India', 'Raipur', NULL, '492009', 'Chhattisgarh', 'Raipur', 'India', 'Dealer', NULL, 1, 0, '7/4/2026 10:44:04 AM', '1', '7/4/2026 10:44:04 AM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (209, 'AL/2026-27/137', 'Kartik Interiors', 'Kartik Interiors', '7019956987', 'kartik7019956987@demo.com', '123', 'Authorized', NULL, NULL, NULL, 'Raichur', NULL, '584101', 'Karnataka', 'Raichur', 'India', 'Raichur', NULL, '584101', 'Karnataka', 'Raichur', 'India', 'Dealer', NULL, 1, 0, '7/4/2026 10:44:04 AM', '1', '7/4/2026 10:44:04 AM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (210, 'AL/2026-27/138', 'Kashi Prayag Constructions', 'Kashi Prayag Constructions', '7676976786', 'kashi7676976786@demo.com', '123', 'Authorized', '29AAUFK5563C1ZW', 'AAUFK5563C', NULL, 'Baba Nagar, Bangalore', NULL, '560064', 'Karnataka', 'Bangalore', 'India', 'Baba Nagar, Bangalore', NULL, '560064', 'Karnataka', 'Bangalore', 'India', 'Dealer', NULL, 1, 0, '7/4/2026 10:44:04 AM', '1', '7/4/2026 10:44:04 AM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (211, 'AL/2026-27/139', 'Keshav Plywoods', 'Keshav Plywoods', '9945695399', 'keshav9945695399@demo.com', '123', 'Authorized', '29AAXFK5600M1ZM', 'AAXFK5600M', NULL, 'Mysore Road, Bangalore', NULL, '560026', 'Karnataka', 'Bangalore', 'India', 'Mysore Road, Bangalore', NULL, '560026', 'Karnataka', 'Bangalore', 'India', 'Dealer', NULL, 1, 0, '7/4/2026 10:44:04 AM', '1', '7/4/2026 10:44:04 AM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (212, 'AL/2026-27/140', 'Lakecity Interiors', 'Lakecity Interiors', '9950768168', 'lakecity9950768168@demo.com', '123', 'Authorized', '08ASLPK4406F1ZT', 'ASLPK4406F', NULL, 'Udaipur', NULL, '313001', 'Rajasthan', 'Udaipur', 'India', 'Udaipur', NULL, '313001', 'Rajasthan', 'Udaipur', 'India', 'Dealer', NULL, 1, 0, '7/4/2026 10:44:04 AM', '1', '7/4/2026 10:44:04 AM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (213, 'AL/2026-27/141', 'Lakshminarayan Ply and Doors', 'Lakshminarayan Ply and Doors', '9740426179', 'lakshmi9740426179@demo.com', '123', 'Authorized', '29AABFL6358H1Z1', 'AABFL6358H', NULL, 'Nayandahalli, Bangalore', NULL, '560039', 'Karnataka', 'Bangalore', 'India', 'Nayandahalli, Bangalore', NULL, '560039', 'Karnataka', 'Bangalore', 'India', 'Dealer', NULL, 1, 0, '7/4/2026 10:44:04 AM', '1', '7/4/2026 10:44:04 AM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (214, 'AL/2026-27/142', 'Laxmi Timber', 'Laxmi Timber', '9079643604', 'laxmi9079643604@demo.com', '123', 'Authorized', '08BLMPS1040L1ZS', 'BLMPS1040L', NULL, 'Kankroli', NULL, '313324', 'Rajasthan', 'Rajsamand', 'India', 'Kankroli', NULL, '313324', 'Rajasthan', 'Rajsamand', 'India', 'Dealer', NULL, 1, 0, '7/4/2026 10:44:04 AM', '1', '7/4/2026 10:44:04 AM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (215, 'AL/2026-27/143', 'Lazoo India Private Limited', 'Lazoo India Private Limited', NULL, 'lazoo@example.com', '123', 'Authorized', '27AADCL7008D1ZS', 'AADCL7008D', NULL, 'Phursungi, Pune', NULL, '412307', 'Maharashtra', 'Pune', 'India', 'Phursungi, Pune', NULL, '412307', 'Maharashtra', 'Pune', 'India', 'Dealer', NULL, 1, 0, '7/4/2026 10:44:04 AM', '1', '7/4/2026 10:44:04 AM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (216, 'AL/2026-27/144', 'Legends County Landmark Private Limited', 'Legends County Landmark Private Limited', NULL, 'legends@example.com', '123', 'Authorized', '27AAHCG1862A1ZX', 'AAHCG1862A', NULL, 'Bund Garden Road, Pune', NULL, '411001', 'Maharashtra', 'Pune', 'India', 'Bund Garden Road, Pune', NULL, '411001', 'Maharashtra', 'Pune', 'India', 'Dealer', NULL, 1, 0, '7/4/2026 10:44:04 AM', '1', '7/4/2026 10:44:04 AM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (217, 'AL/2026-27/145', 'Lumber Bee Studio Private Limited', 'Lumber Bee Studio Private Limited', '9538918149', 'lumberbee9538918149@demo.com', '123', 'Authorized', '29AAFCL2820F1ZO', 'AAFCL2820F', NULL, 'Bengaluru', NULL, '560082', 'Karnataka', 'Bengaluru', 'India', 'Bengaluru', NULL, '560082', 'Karnataka', 'Bengaluru', 'India', 'Dealer', NULL, 1, 0, '7/4/2026 10:44:04 AM', '1', '7/4/2026 10:44:04 AM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (218, 'AL/2026-27/146', 'Maa Laxmi Gallery', 'Maa Laxmi Gallery', '7350676865', 'maalaxmi7350676865@demo.com', '123', 'Authorized', '30EMSPK9463F1ZO', 'EMSPK9463F', NULL, 'Mapusa, Goa', NULL, '403507', 'Goa', 'North Goa', 'India', 'Mapusa, Goa', NULL, '403507', 'Goa', 'North Goa', 'India', 'Dealer', NULL, 1, 0, '7/4/2026 10:44:04 AM', '1', '7/4/2026 10:44:04 AM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (219, 'AL/2026-27/147', 'Mahavir Square', 'Mahavir Square', '4224369008', 'mahavir4224369008@demo.com', '123', 'Authorized', '33FRVPM6064B1ZJ', 'FRVPM6064B', NULL, 'New No 51 and 53, Old No 33 and 33A, Ponnurangam Road East, RS Puram, Coimbatore', NULL, '641002', 'Tamil Nadu', 'Coimbatore', 'India', 'New No 51 and 53, Old No 33 and 33A, Ponnurangam Road East, RS Puram, Coimbatore', NULL, '641002', 'Tamil Nadu', 'Coimbatore', 'India', 'Dealer', NULL, 1, 0, '7/4/2026 10:45:07 AM', '1', '7/4/2026 10:45:07 AM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (220, 'AL/2026-27/148', 'Manish Plywood', 'Manish Plywood', '9885544140', 'manish9885544140@demo.com', '123', 'Authorized', '36ABNPJ8761D1ZE', 'ABNPJ8761D', NULL, 'Aghapura, Goshamahal, Hyderabad', NULL, '500001', 'Telangana', 'Hyderabad', 'India', 'Aghapura, Goshamahal, Hyderabad', NULL, '500001', 'Telangana', 'Hyderabad', 'India', 'Dealer', NULL, 1, 0, '7/4/2026 10:45:07 AM', '1', '7/4/2026 10:45:07 AM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (221, 'AL/2026-27/149', 'MANMUK INTERIOR & EXTERIOR Solution', 'MANMUK INTERIOR & EXTERIOR Solution', '9879241083', 'manmuk9879241083@demo.com', '123', 'Authorized', NULL, NULL, NULL, 'Udhana Magdalla Road, Surat', NULL, '395007', 'Gujarat', 'Surat', 'India', 'Udhana Magdalla Road, Surat', NULL, '395007', 'Gujarat', 'Surat', 'India', 'Dealer', NULL, 1, 0, '7/4/2026 10:45:07 AM', '1', '7/4/2026 10:45:07 AM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (222, 'AL/2026-27/150', 'Maruti Ply and Glass', 'Maruti Ply and Glass', '9122462222', 'marutiply9122462222@demo.com', '123', 'Authorized', '10ABBFM3906B1Z5', 'ABBFM3906B', '', 'Raj Market, Akharaghat Road, Muzaffarpur', 'BIHAR', '842001', 'Bihar', 'Muzaffarpur', 'India', 'FAST N SAFE RAIL CARGO
', 'BHIWANDI ', '421302', 'Maharashtra', 'Thane', 'India', 'Dealer', NULL, 1, 0, '7/4/2026 10:45:07 AM', '1', '7/7/2026 2:38:33 PM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (223, 'AL/2026-27/151', 'Mbh Creative Studio Llp', 'Mbh Creative Studio Llp', '9110664493', 'mbh9110664493@demo.com', '123', 'Authorized', '29ABBFM7384B1Z6', 'ABBFM7384B', NULL, 'Koramangala, Bengaluru', NULL, '560095', 'Karnataka', 'Bengaluru', 'India', 'Koramangala, Bengaluru', NULL, '560095', 'Karnataka', 'Bengaluru', 'India', 'Dealer', NULL, 1, 0, '7/4/2026 10:45:07 AM', '1', '7/4/2026 10:45:07 AM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (224, 'AL/2026-27/152', 'Milind Wani', 'Milind Wani', '8408005500', 'milind8408005500@demo.com', '123', 'Authorized', NULL, NULL, NULL, 'Shaniwar Peth, Pune', NULL, '411030', 'Maharashtra', 'Pune', 'India', 'Shaniwar Peth, Pune', NULL, '411030', 'Maharashtra', 'Pune', 'India', 'Dealer', NULL, 1, 0, '7/4/2026 10:45:07 AM', '1', '7/4/2026 10:45:07 AM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (225, 'AL/2026-27/153', 'Minal Sawant', 'Minal Sawant', '8805532663', 'minal8805532663@demo.com', '123', 'Authorized', NULL, NULL, NULL, 'Chinchwad, Pune', NULL, '411033', 'Maharashtra', 'Pune', 'India', 'Chinchwad, Pune', NULL, '411033', 'Maharashtra', 'Pune', 'India', 'Dealer', NULL, 1, 0, '7/4/2026 10:45:07 AM', '1', '7/4/2026 10:45:07 AM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (226, 'AL/2026-27/154', 'misriya decor', 'misriya decor', '9008693288', 'misriya9008693288@demo.com', '123', 'Authorized', NULL, NULL, NULL, 'Devanur Extension, Mysore', NULL, '570019', 'Karnataka', 'Mysore', 'India', 'Devanur Extension, Mysore', NULL, '570019', 'Karnataka', 'Mysore', 'India', 'Dealer', NULL, 1, 0, '7/4/2026 10:45:07 AM', '1', '7/4/2026 10:45:07 AM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (227, 'AL/2026-27/155', 'M K Hardware & Plywood', 'M K Hardware & Plywood', '9623062461', 'mkhardware9623062461@demo.com', '123', 'Authorized', NULL, NULL, NULL, 'Nanded', NULL, '431605', 'Maharashtra', 'Nanded', 'India', 'Nanded', NULL, '431605', 'Maharashtra', 'Nanded', 'India', 'Dealer', NULL, 1, 0, '7/4/2026 10:45:07 AM', '1', '7/4/2026 10:45:07 AM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (228, 'AL/2026-27/156', 'Modanis Interior Studio', 'Modanis Interior Studio', '9822615151', 'modanis9822615151@demo.com', '123', 'Authorized', '27AJDPM6726B1ZE', 'AJDPM6726B', NULL, 'Chhatrapati Sambhaji Nagar', NULL, '431001', 'Maharashtra', 'Chhatrapati Sambhaji Nagar', 'India', 'Chhatrapati Sambhaji Nagar', NULL, '431001', 'Maharashtra', 'Chhatrapati Sambhaji Nagar', 'India', 'Dealer', NULL, 1, 0, '7/4/2026 10:45:07 AM', '1', '7/4/2026 10:45:07 AM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (229, 'AL/2026-27/157', 'Modi Interior World', 'Modi Interior World', '9512655558', 'modi9512655558@demo.com', '123', 'Authorized', '24CJIPM8903K1ZV', 'CJIPM8903K', NULL, 'Rajkot', NULL, '360005', 'Gujarat', 'Rajkot', 'India', 'Rajkot', NULL, '360005', 'Gujarat', 'Rajkot', 'India', 'Dealer', NULL, 1, 0, '7/4/2026 10:45:07 AM', '1', '7/4/2026 10:45:07 AM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (230, 'AL/2026-27/158', 'Modi Plywood', 'Modi Plywood', '9827007769', 'modiplywood9827007769@demo.com', '123', 'Authorized', '23ABLFM1781A1ZL', 'ABLFM1781A', NULL, 'M.P. Nagar, Bhopal', NULL, '462011', 'Madhya Pradesh', 'Bhopal', 'India', 'M.P. Nagar, Bhopal', NULL, '462011', 'Madhya Pradesh', 'Bhopal', 'India', 'Dealer', NULL, 1, 0, '7/4/2026 10:45:07 AM', '1', '7/4/2026 10:45:07 AM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (231, 'AL/2026-27/159', 'Mrugesh Laser Engravers', 'Mrugesh Laser Engravers', NULL, 'mrugesh@example.com', '123', 'Authorized', NULL, NULL, NULL, 'PCNTDA Bhosari, Pune', NULL, '411026', 'Maharashtra', 'Pune', 'India', 'PCNTDA Bhosari, Pune', NULL, '411026', 'Maharashtra', 'Pune', 'India', 'Dealer', NULL, 1, 0, '7/4/2026 10:45:07 AM', '1', '7/4/2026 10:45:07 AM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (232, 'AL/2026-27/160', 'Agam Enterprises', 'Agam Enterprises', '8932959595', 'agam8932959595@demo.com', '123', 'Authorized', '09ABMFA0276F1ZG', 'BIBPS0334M', NULL, 'Vinayakpur, Kanpur', NULL, '208003', 'Uttar Pradesh', 'Kanpur', 'India', 'Vinayakpur, Kanpur', NULL, '208003', 'Uttar Pradesh', 'Kanpur', 'India', 'Dealer', NULL, 1, 0, '7/4/2026 10:45:07 AM', '1', '7/4/2026 10:45:07 AM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (233, 'AL/2026-27/161', 'Asian Plywoods', 'Asian Plywoods', '9448190081', 'asian9448190081@demo.com', '123', 'Authorized', '29AAYFA7376H1ZL', 'AAYFA7376H', NULL, 'Kalaburagi', NULL, '585102', 'Karnataka', 'Kalaburagi', 'India', 'Kalaburagi', NULL, '585102', 'Karnataka', 'Kalaburagi', 'India', 'Dealer', NULL, 1, 0, '7/4/2026 10:45:07 AM', '1', '7/4/2026 10:45:07 AM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (234, 'AL/2026-27/162', 'Om Plywoods', 'Om Plywoods', '8801858522', 'omplywood8801858522@demo.com', '123', 'Authorized', '37CSKPD0515K1ZT', 'CSKPD0515K', NULL, 'Poolavani Gunta, Tirupati', NULL, '517501', 'Andhra Pradesh', 'Tirupati', 'India', 'Poolavani Gunta, Tirupati', NULL, '517501', 'Andhra Pradesh', 'Tirupati', 'India', 'Dealer', NULL, 1, 0, '7/4/2026 10:46:15 AM', '1', '7/4/2026 10:46:15 AM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (235, 'AL/2026-27/163', 'Ornaterra Interiors Llp', 'Ornaterra Interiors Llp', '9217363401', 'ornaterra9217363401@demo.com', '123', 'Authorized', '07AAJFO6284D1Z3', 'AAJFO6284D', NULL, 'Mangolpuri Industrial Area, New Delhi', NULL, '110083', 'Delhi', 'New Delhi', 'India', 'Mangolpuri Industrial Area, New Delhi', NULL, '110083', 'Delhi', 'New Delhi', 'India', 'Dealer', NULL, 1, 0, '7/4/2026 10:46:15 AM', '1', '7/4/2026 10:46:15 AM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (236, 'AL/2026-27/164', 'Paints Plus', 'Paints Plus', '9705122072', 'paints9705122072@demo.com', '123', 'Authorized', '37ABIPV3579N1ZM', 'ABIPV3579N', NULL, 'Tikkle Road, Vijayawada', NULL, '520010', 'Andhra Pradesh', 'Vijayawada', 'India', 'Tikkle Road, Vijayawada', NULL, '520010', 'Andhra Pradesh', 'Vijayawada', 'India', 'Dealer', NULL, 1, 0, '7/4/2026 10:46:15 AM', '1', '7/4/2026 10:46:15 AM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (237, 'AL/2026-27/165', 'Palette Interior Studio', 'Palette Interior Studio', '7777016114', 'palette7777016114@demo.com', '123', 'Authorized', '27AARHP3463P1Z8', 'AARHP3463P', NULL, 'Malad West, Mumbai', NULL, '400064', 'Maharashtra', 'Mumbai', 'India', 'Malad West, Mumbai', NULL, '400064', 'Maharashtra', 'Mumbai', 'India', 'Dealer', NULL, 1, 0, '7/4/2026 10:46:15 AM', '1', '7/4/2026 10:46:15 AM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (238, 'AL/2026-27/166', 'PANCHSHEEL ENGINEERS', 'PANCHSHEEL ENGINEERS', '9766104590', 'panchsheel9766104590@demo.com', '123', 'Authorized', NULL, NULL, NULL, 'Talawade, Pune', NULL, '411062', 'Maharashtra', 'Pune', 'India', 'Talawade, Pune', NULL, '411062', 'Maharashtra', 'Pune', 'India', 'Dealer', NULL, 1, 0, '7/4/2026 10:46:15 AM', '1', '7/4/2026 10:46:15 AM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (239, 'AL/2026-27/167', 'parimala Narayankeri', 'parimala Narayankeri', '9850502380', 'parimala9850502380@demo.com', '123', 'Authorized', NULL, NULL, NULL, 'Pimple Saudagar, Pune', NULL, '411017', 'Maharashtra', 'Pune', 'India', 'Pimple Saudagar, Pune', NULL, '411017', 'Maharashtra', 'Pune', 'India', 'Dealer', NULL, 1, 0, '7/4/2026 10:46:15 AM', '1', '7/4/2026 10:46:15 AM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (240, 'AL/2026-27/168', 'PATADIA DECOR', 'PATADIA DECOR', '9879831311', 'patadia9879831311@demo.com', '123', 'Authorized', '24BMGPP0510B1ZT', 'BMGPP0510B', NULL, 'Rajkot', NULL, '360001', 'Gujarat', 'Rajkot', 'India', 'Rajkot', NULL, '360001', 'Gujarat', 'Rajkot', 'India', 'Dealer', NULL, 1, 0, '7/4/2026 10:46:15 AM', '1', '7/4/2026 10:46:15 AM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (241, 'AL/2026-27/169', 'Phoenix Decor', 'Phoenix Decor', '9923205205', 'phoenix9923205205@demo.com', '123', 'Authorized', '27BBKPK2434A1Z2', 'BBKPK2434A', NULL, 'Narayan Peth, Pune', NULL, '411030', 'Maharashtra', 'Pune', 'India', 'Narayan Peth, Pune', NULL, '411030', 'Maharashtra', 'Pune', 'India', 'Dealer', NULL, 1, 0, '7/4/2026 10:46:15 AM', '1', '7/4/2026 10:46:15 AM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (242, 'AL/2026-27/170', 'P K Holding', 'P K Holding', '7736210236', 'pkholding7736210236@demo.com', '123', 'Authorized', '32ABCFP1832C1ZW', 'ABCFP1832C', NULL, 'Nadapuram, Kerala', NULL, '673504', 'Kerala', 'Kozhikode', 'India', 'Nadapuram, Kerala', NULL, '673504', 'Kerala', 'Kozhikode', 'India', 'Dealer', NULL, 1, 0, '7/4/2026 10:46:15 AM', '1', '7/4/2026 10:46:15 AM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (243, 'AL/2026-27/171', 'Ploceus Studio Llp', 'Ploceus Studio Llp', '7774052415', 'ploceus7774052415@demo.com', '123', 'Authorized', '27AAZFP8728R1ZQ', 'AAZFP8728R', NULL, 'Wagholi, Pune', NULL, '412207', 'Maharashtra', 'Pune', 'India', 'Wagholi, Pune', NULL, '412207', 'Maharashtra', 'Pune', 'India', 'Dealer', NULL, 1, 0, '7/4/2026 10:46:15 AM', '1', '7/4/2026 10:46:15 AM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (244, 'AL/2026-27/172', 'Ply & Hardware Planet', 'Ply & Hardware Planet', '9826060032', 'plyplanet9826060032@demo.com', '123', 'Authorized', '23ALVPH2317P1ZP', 'ALVPH2317P', NULL, 'Indore', NULL, '452001', 'Madhya Pradesh', 'Indore', 'India', 'Indore', NULL, '452001', 'Madhya Pradesh', 'Indore', 'India', 'Dealer', NULL, 1, 0, '7/4/2026 10:46:15 AM', '1', '7/4/2026 10:46:15 AM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (245, 'AL/2026-27/173', 'Ply Planet', 'Ply Planet', '7828903834', 'plyplanet7828903834@demo.com', '123', 'Authorized', '23AJHPB6420D1ZY', 'AJHPB6420D', NULL, 'Indore', NULL, '453771', 'Madhya Pradesh', 'Indore', 'India', 'Indore', NULL, '453771', 'Madhya Pradesh', 'Indore', 'India', 'Dealer', NULL, 1, 0, '7/4/2026 10:46:15 AM', '1', '7/4/2026 10:46:15 AM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (246, 'AL/2026-27/174', 'Plywood Centre', 'Plywood Centre', '9642429881', 'plywood9642429881@demo.com', '123', 'Authorized', '37ACSPP8797P1ZY', 'ACSPP8797P', NULL, 'Nellore', NULL, '425001', 'Andhra Pradesh', 'Nellore', 'India', 'Nellore', NULL, '425001', 'Andhra Pradesh', 'Nellore', 'India', 'Dealer', NULL, 1, 0, '7/4/2026 10:46:15 AM', '1', '7/4/2026 10:46:15 AM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (247, 'AL/2026-27/175', 'Ply World', 'Ply World', '7000968996', 'plyworld7000968996@demo.com', '123', 'Authorized', '23EWMPP9043Q1ZL', 'EWMPP9043Q', NULL, 'Seoni', NULL, '480661', 'Madhya Pradesh', 'Seoni', 'India', 'Seoni', NULL, '480661', 'Madhya Pradesh', 'Seoni', 'India', 'Dealer', NULL, 1, 0, '7/4/2026 10:46:15 AM', '1', '7/4/2026 10:46:15 AM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (248, 'AL/2026-27/176', 'Pooja Plywoods', 'Pooja Plywoods', NULL, 'pooja@example.com', '123', 'Authorized', '29AHIPJ6777G1ZS', 'AHIPJ6777G', NULL, 'Gokul Road, Hubballi', NULL, '580030', 'Karnataka', 'Hubballi', 'India', 'Gokul Road, Hubballi', NULL, '580030', 'Karnataka', 'Hubballi', 'India', 'Dealer', NULL, 1, 0, '7/4/2026 10:46:15 AM', '1', '7/4/2026 10:46:15 AM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (249, 'AL/2026-27/177', 'Raj Biradar', 'Raj Biradar', NULL, 'rajbiradar@demo.com', '123', 'Authorized', NULL, NULL, NULL, 'Pimpri Chinchwad', NULL, NULL, 'Maharashtra', 'Pimpri Chinchwad', 'India', 'Pimpri Chinchwad', NULL, NULL, 'Maharashtra', 'Pimpri Chinchwad', 'India', 'Dealer', NULL, 1, 0, '7/4/2026 10:46:58 AM', '1', '7/4/2026 10:46:58 AM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (250, 'AL/2026-27/178', 'RAJ JADHAV', 'RAJ JADHAV', '8805732410', 'rajjadav8805732410@demo.com', '123', 'Authorized', NULL, NULL, NULL, 'Phulewadi, Kolhapur', NULL, '416010', 'Maharashtra', 'Kolhapur', 'India', 'Phulewadi, Kolhapur', NULL, '416010', 'Maharashtra', 'Kolhapur', 'India', 'Dealer', NULL, 1, 0, '7/4/2026 10:46:58 AM', '1', '7/4/2026 10:46:58 AM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (251, 'AL/2026-27/179', 'Ram Plywood', 'Ram Plywood', '9762275112', 'ramplywood9762275112@demo.com', '123', 'Authorized', '27BDSPR7227N1ZJ', 'BDSPR7227N', NULL, 'Waluj, Chhatrapati Sambhaji Nagar', NULL, '431136', 'Maharashtra', 'Chhatrapati Sambhaji Nagar', 'India', 'Waluj, Chhatrapati Sambhaji Nagar', NULL, '431136', 'Maharashtra', 'Chhatrapati Sambhaji Nagar', 'India', 'Dealer', NULL, 1, 0, '7/4/2026 10:46:58 AM', '1', '7/4/2026 10:46:58 AM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (252, 'AL/2026-27/180', 'Raymond Gomes', 'Raymond Gomes', '8390615111', 'raymond8390615111@demo.com', '123', 'Authorized', NULL, NULL, NULL, 'VTP Aethereus, Mahalunge', NULL, '411045', 'Maharashtra', 'Pune', 'India', 'VTP Aethereus, Mahalunge', NULL, '411045', 'Maharashtra', 'Pune', 'India', 'Dealer', NULL, 1, 0, '7/4/2026 10:46:58 AM', '1', '7/4/2026 10:46:58 AM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (253, 'AL/2026-27/181', 'REGAL ENTERPRISE', 'REGAL ENTERPRISE', '9689191234', 'regal9689191234@demo.com', '123', 'Authorized', NULL, NULL, NULL, 'Baramati, Pune', NULL, '413102', 'Maharashtra', 'Pune', 'India', 'Baramati, Pune', NULL, '413102', 'Maharashtra', 'Pune', 'India', 'Dealer', NULL, 1, 0, '7/4/2026 10:46:58 AM', '1', '7/4/2026 10:46:58 AM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (254, 'AL/2026-27/182', 'Rekha Mishra', 'Rekha Mishra', '7666035165', 'rekha7666035165@demo.com', '123', 'Authorized', NULL, NULL, NULL, 'Pimple Saudagar, Pune', NULL, '411033', 'Maharashtra', 'Pune', 'India', 'Pimple Saudagar, Pune', NULL, '411033', 'Maharashtra', 'Pune', 'India', 'Dealer', NULL, 1, 0, '7/4/2026 10:46:58 AM', '1', '7/4/2026 10:46:58 AM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (255, 'AL/2026-27/183', 'Reliance Plywood Corporation', 'Reliance Plywood Corporation', '7022614066', 'reliance7022614066@demo.com', '123', 'Authorized', '29AGGPG6870L1ZU', 'AGGPG6870L', NULL, 'Mysore Road, Bengaluru', NULL, '560026', 'Karnataka', 'Bengaluru', 'India', 'Mysore Road, Bengaluru', NULL, '560026', 'Karnataka', 'Bengaluru', 'India', 'Dealer', NULL, 1, 0, '7/4/2026 10:46:58 AM', '1', '7/4/2026 10:46:58 AM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (256, 'AL/2026-27/184', 'Rishabh Decor', 'Rishabh Decor', '8220345472', 'rishabh8220345472@demo.com', '123', 'Authorized', '33ANQPM1955M1ZG', 'ANQPM1955M', NULL, 'Mettupalayam Road, Coimbatore', NULL, '641002', 'Tamil Nadu', 'Coimbatore', 'India', 'Mettupalayam Road, Coimbatore', NULL, '641002', 'Tamil Nadu', 'Coimbatore', 'India', 'Dealer', NULL, 1, 0, '7/4/2026 10:46:58 AM', '1', '7/4/2026 10:46:58 AM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (257, 'AL/2026-27/185', 'Rista Interior Hub', 'Rista Interior Hub', '7425811769', 'rista7425811769@demo.com', '123', 'Authorized', '24PFWPS2028E1ZW', 'PFWPS2028E', NULL, 'Bhatar, Surat', NULL, '395007', 'Gujarat', 'Surat', 'India', 'Bhatar, Surat', NULL, '395007', 'Gujarat', 'Surat', 'India', 'Dealer', NULL, 1, 0, '7/4/2026 10:46:58 AM', '1', '7/4/2026 10:46:58 AM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (258, 'AL/2026-27/186', 'Ritesh Rastogi', 'Ritesh Rastogi', '9517102326', 'ritesh9517102326@demo.com', '123', 'Authorized', NULL, NULL, NULL, 'Lucknow', NULL, '226003', 'Uttar Pradesh', 'Lucknow', 'India', 'Lucknow', NULL, '226003', 'Uttar Pradesh', 'Lucknow', 'India', 'Dealer', NULL, 1, 0, '7/4/2026 10:46:58 AM', '1', '7/4/2026 10:46:58 AM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (259, 'AL/2026-27/187', 'RMG Design', 'RMG Design', NULL, 'rmgdesign@demo.com', '123', 'Authorized', NULL, NULL, NULL, 'Pimple Saudagar, Pune', NULL, '411027', 'Maharashtra', 'Pune', 'India', 'Pimple Saudagar, Pune', NULL, '411027', 'Maharashtra', 'Pune', 'India', 'Dealer', NULL, 1, 0, '7/4/2026 10:46:58 AM', '1', '7/4/2026 10:46:58 AM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (260, 'AL/2026-27/188', 'Royal Rexine', 'Royal Rexine', '8308015252', 'royal8308015252@demo.com', '123', 'Authorized', '27AHAPR8530M1ZW', 'AHAPR8530M', NULL, 'Ahmednagar', NULL, '414001', 'Maharashtra', 'Ahmednagar', 'India', 'Ahmednagar', NULL, '414001', 'Maharashtra', 'Ahmednagar', 'India', 'Dealer', NULL, 1, 0, '7/4/2026 10:46:58 AM', '1', '7/4/2026 10:46:58 AM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (261, 'AL/2026-27/189', 'Royal Touch', 'Royal Touch', '9898656908', 'royaltouch9898656908@demo.com', '123', 'Authorized', '24AZYPS4281N1ZA', 'AZYPS4281N', NULL, 'Surat', NULL, '395007', 'Gujarat', 'Surat', 'India', 'Surat', NULL, '395007', 'Gujarat', 'Surat', 'India', 'Dealer', NULL, 1, 0, '7/4/2026 10:46:58 AM', '1', '7/4/2026 10:46:58 AM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (262, 'AL/2026-27/190', 'R Seven Studio', 'R Seven Studio', '8123415918', 'rseven8123415918@demo.com', '123', 'Authorized', '27FOWPS3345H1Z5', 'FOWPS3345H', NULL, 'Pune', NULL, '411037', 'Maharashtra', 'Pune', 'India', 'Pune', NULL, '411037', 'Maharashtra', 'Pune', 'India', 'Dealer', NULL, 1, 0, '7/4/2026 10:46:58 AM', '1', '7/4/2026 10:46:58 AM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (263, 'AL/2026-27/191', 'Rushikesh Kapare', 'Rushikesh Kapare', NULL, 'rushikesh@demo.com', '123', 'Authorized', NULL, NULL, NULL, 'Maharashtra', NULL, NULL, 'Maharashtra', 'Pune', 'India', 'Maharashtra', NULL, NULL, 'Maharashtra', 'Pune', 'India', 'Dealer', NULL, 1, 0, '7/4/2026 10:46:58 AM', '1', '7/4/2026 10:46:58 AM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (264, 'AL/2026-27/192', 'Shades', 'Shades', '9930366616', 'shades9930366616@demo.com', '123', 'Authorized', '27ADBPC3088N3ZB', NULL, NULL, 'Ghatkopar West, Mumbai', NULL, '400086', 'Maharashtra', 'Mumbai', 'India', 'Ghatkopar West, Mumbai', NULL, '400086', 'Maharashtra', 'Mumbai', 'India', 'Dealer', NULL, 1, 0, '7/4/2026 10:48:03 AM', '1', '7/4/2026 10:48:03 AM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (265, 'AL/2026-27/193', 'Shah Milapchand and Sons', 'Shah Milapchand and Sons', '9665949334', 'shahmilap9665949334@demo.com', '123', 'Authorized', '27AEGPS3044G1ZH', 'AEGPS3044G', NULL, 'New Timber Market, Pune', NULL, '411002', 'Maharashtra', 'Pune', 'India', 'New Timber Market, Pune', NULL, '411002', 'Maharashtra', 'Pune', 'India', 'Dealer', NULL, 1, 0, '7/4/2026 10:48:03 AM', '1', '7/4/2026 10:48:03 AM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (266, 'AL/2026-27/194', 'Shanti Plywood and Laminates', 'Shanti Plywood and Laminates', '8838700651', 'shanti8838700651@demo.com', '123', 'Authorized', '33BDOPA7953C1ZP', 'BDOPA7953C', NULL, 'Mettupalayam Road, Coimbatore', NULL, '641002', 'Tamil Nadu', 'Coimbatore', 'India', 'Mettupalayam Road, Coimbatore', NULL, '641002', 'Tamil Nadu', 'Coimbatore', 'India', 'Dealer', NULL, 1, 0, '7/4/2026 10:48:03 AM', '1', '7/4/2026 10:48:03 AM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (267, 'AL/2026-27/195', 'Shanti Plywood Co.', 'Shanti Plywood Co.', NULL, 'shantiplywood@demo.com', '123', 'Authorized', '07AACFS6187Q1ZD', 'AACFS6187Q', NULL, 'Kirti Nagar, Delhi', NULL, '110015', 'Delhi', 'Delhi', 'India', 'Kirti Nagar, Delhi', NULL, '110015', 'Delhi', 'Delhi', 'India', 'Dealer', NULL, 1, 0, '7/4/2026 10:48:03 AM', '1', '7/4/2026 10:48:03 AM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (268, 'AL/2026-27/196', 'Shilpa Lande', 'Shilpa Lande', '7447306253', 'shilpa7447306253@demo.com', '123', 'Authorized', NULL, NULL, NULL, 'Dighi, Pune', NULL, '411015', 'Maharashtra', 'Pune', 'India', 'Dighi, Pune', NULL, '411015', 'Maharashtra', 'Pune', 'India', 'Dealer', NULL, 1, 0, '7/4/2026 10:48:03 AM', '1', '7/4/2026 10:48:03 AM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (269, 'AL/2026-27/197', 'Shirdi Plywood Agency', 'Shirdi Plywood Agency', '9332223777', 'shirdi9332223777@demo.com', '123', 'Authorized', '19AHMPJ5513A1ZL', 'AHMPJ5513A', NULL, 'Asansol', NULL, '713301', 'West Bengal', 'Asansol', 'India', 'Asansol', NULL, '713301', 'West Bengal', 'Asansol', 'India', 'Dealer', NULL, 1, 0, '7/4/2026 10:48:03 AM', '1', '7/4/2026 10:48:03 AM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (270, 'AL/2026-27/198', 'Shiv Lam', 'Shiv Lam', '9819282272', 'shivlam9819282272@demo.com', '123', 'Authorized', '27ADLPT3742L1ZX', 'ADLPT3742L', NULL, 'Malad West, Mumbai', NULL, '400064', 'Maharashtra', 'Mumbai', 'India', 'Malad West, Mumbai', NULL, '400064', 'Maharashtra', 'Mumbai', 'India', 'Dealer', NULL, 1, 0, '7/4/2026 10:48:03 AM', '1', '7/4/2026 10:48:03 AM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (271, 'AL/2026-27/199', 'Shree Bhikshu Interior Hub', 'Shree Bhikshu Interior Hub', '8866871849', 'shree8866871849@demo.com', '123', 'Authorized', '24AWIPB4986E1ZK', 'AWIPB4986E', NULL, 'Magdalla Road, Surat', NULL, '395017', 'Gujarat', 'Surat', 'India', 'Magdalla Road, Surat', NULL, '395017', 'Gujarat', 'Surat', 'India', 'Dealer', NULL, 1, 0, '7/4/2026 10:48:03 AM', '1', '7/4/2026 10:48:03 AM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (272, 'AL/2026-27/200', 'Shree Interior Studio', 'Shree Interior Studio', '9949600500', 'shreeinterior9949600500@demo.com', '123', 'Authorized', '36AEBFS0795K1ZN', 'AEBFS0795K', NULL, 'Jubilee Hills, Hyderabad', NULL, '500045', 'Telangana', 'Hyderabad', 'India', 'Jubilee Hills, Hyderabad', NULL, '500045', 'Telangana', 'Hyderabad', 'India', 'Dealer', NULL, 1, 0, '7/4/2026 10:48:03 AM', '1', '7/4/2026 10:48:03 AM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (273, 'AL/2026-27/201', 'Shree Renuka Ply & Hardware', 'Shree Renuka Ply & Hardware', '8975552533', 'shree8975552533@demo.com', '123', 'Authorized', NULL, NULL, NULL, 'Kolhapur', NULL, '416002', 'Maharashtra', 'Kolhapur', 'India', 'Kolhapur', NULL, '416002', 'Maharashtra', 'Kolhapur', 'India', 'Dealer', NULL, 1, 0, '7/4/2026 10:48:03 AM', '1', '7/4/2026 10:48:03 AM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (274, 'AL/2026-27/202', 'Shree Shakti Plywood', 'Shree Shakti Plywood', '9099549259', 'shakti9099549259@demo.com', '123', 'Authorized', '24BXBPT7556B1ZG', 'BXBPT7556B', NULL, 'Bhuj, Kachchh', NULL, '370001', 'Gujarat', 'Bhuj', 'India', 'Bhuj, Kachchh', NULL, '370001', 'Gujarat', 'Bhuj', 'India', 'Dealer', NULL, 1, 0, '7/4/2026 10:48:03 AM', '1', '7/4/2026 10:48:03 AM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (275, 'AL/2026-27/203', 'Shree Vardayini Plywood and Hardware', 'Shree Vardayini Plywood and Hardware', '8866892186', 'vardayini8866892186@demo.com', '123', 'Authorized', '24ALWPS7934E1ZH', 'ALWPS7934E', NULL, 'Gandhinagar', NULL, '382028', 'Gujarat', 'Gandhinagar', 'India', 'Gandhinagar', NULL, '382028', 'Gujarat', 'Gandhinagar', 'India', 'Dealer', NULL, 1, 0, '7/4/2026 10:48:03 AM', '1', '7/4/2026 10:48:03 AM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (276, 'AL/2026-27/204', 'Shri Narmada Timber Mart', 'Shri Narmada Timber Mart', '9826245994', 'narmada9826245994@demo.com', '123', 'Authorized', '23AAPFS8588N1Z3', 'AAPFS8588N', NULL, 'Govindpura, Bhopal', NULL, '462011', 'Madhya Pradesh', 'Bhopal', 'India', 'Govindpura, Bhopal', NULL, '462011', 'Madhya Pradesh', 'Bhopal', 'India', 'Dealer', NULL, 1, 0, '7/4/2026 10:48:03 AM', '1', '7/4/2026 10:48:03 AM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (277, 'AL/2026-27/205', 'Shriram Kale', 'Shriram Kale', '9403023921', 'shriram9403023921@demo.com', '123', 'Authorized', NULL, NULL, NULL, 'Dange Chowk, Pune', NULL, '411033', 'Maharashtra', 'Pune', 'India', 'Dange Chowk, Pune', NULL, '411033', 'Maharashtra', 'Pune', 'India', 'Dealer', NULL, 1, 0, '7/4/2026 10:48:03 AM', '1', '7/4/2026 10:48:03 AM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (278, 'AL/2026-27/206', 'Shriram Kale', 'Shri Sadguru Ply & Timber', '9998867334', 'sadguru9998867334@demo.com', '123', 'Authorized', '24AESFS8532D1ZR', 'AESFS8532D', NULL, 'Vadodara', NULL, '390022', 'Gujarat', 'Vadodara', 'India', 'Vadodara', NULL, '390022', 'Gujarat', 'Vadodara', 'India', 'Dealer', NULL, 1, 0, '7/4/2026 10:48:03 AM', '1', '7/4/2026 10:48:03 AM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (279, 'AL/2026-27/207', 'SURAJ NANEKAR', 'SURAJ NANEKAR', '9822933232', 'suraj9822933232@demo.com', '123', 'Authorized', NULL, NULL, NULL, 'Kharabwadi, Pune', NULL, '411050', 'Maharashtra', 'Pune', 'India', 'Kharabwadi, Pune', NULL, '411050', 'Maharashtra', 'Pune', 'India', 'Dealer', NULL, 1, 0, '7/4/2026 10:49:28 AM', '1', '7/4/2026 10:49:28 AM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (280, 'AL/2026-27/208', 'Surface Studio', 'Surface Studio', '8460386242', 'surfacestudio8460386242@demo.com', '123', 'Authorized', '24AAOFP9355R1Z6', 'AAOFP9355R', NULL, 'Gota, Ahmedabad', NULL, '382481', 'Gujarat', 'Ahmedabad', 'India', 'Gota, Ahmedabad', NULL, '382481', 'Gujarat', 'Ahmedabad', 'India', 'Dealer', NULL, 1, 0, '7/4/2026 10:49:28 AM', '1', '7/4/2026 10:49:28 AM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (281, 'AL/2026-27/209', 'Swapnil Raut', 'Swapnil Raut', '9022656216', 'swapnil9022656216@demo.com', '123', 'Authorized', NULL, NULL, NULL, 'Chikhali, Pune', NULL, NULL, 'Maharashtra', 'Pune', 'India', 'Chikhali, Pune', NULL, NULL, 'Maharashtra', 'Pune', 'India', 'Dealer', NULL, 1, 0, '7/4/2026 10:49:28 AM', '1', '7/4/2026 10:49:28 AM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (282, 'AL/2026-27/210', 'Swastik Plywoods', 'Swastik Plywoods', '9448064400', 'swastik9448064400@demo.com', '123', 'Authorized', '29ABPFS7293B1ZM', 'ABPFS7293B', NULL, 'Belagavi', NULL, '590001', 'Karnataka', 'Belagavi', 'India', 'Belagavi', NULL, '590001', 'Karnataka', 'Belagavi', 'India', 'Dealer', NULL, 1, 0, '7/4/2026 10:49:28 AM', '1', '7/4/2026 10:49:28 AM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (283, 'AL/2026-27/211', 'Taksh', 'Taksh', '8638979847', 'taksh8638979847@demo.com', '123', 'Authorized', '18AXPPB8542G1Z8', 'AXPPB8542G', '', 'Tinsukia', 'Tinsukia ', '786125', 'Assam', 'Tinsukia', 'India', 'MOONLINE EXPRESS CARGO PVT LTD', 'BHIWANDI ', '421302', 'Maharashtra', 'Thane', 'India', 'Dealer', NULL, 1, 0, '7/4/2026 10:49:28 AM', '1', '7/7/2026 2:43:38 PM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (284, 'AL/2026-27/212', 'Thaat Baat', 'Thaat Baat', '7023123545', 'thaat7023123545@demo.com', '123', 'Authorized', '08AOVPJ7183C2ZH', 'AOVPJ7183C', NULL, 'Kankroli, Rajsamand', NULL, '313224', 'Rajasthan', 'Rajsamand', 'India', 'Kankroli, Rajsamand', NULL, '313224', 'Rajasthan', 'Rajsamand', 'India', 'Dealer', NULL, 1, 0, '7/4/2026 10:49:28 AM', '1', '7/4/2026 10:49:28 AM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (285, 'AL/2026-27/213', 'The Array Design Studio', 'The Array Design Studio', '7666989891', 'array7666989891@demo.com', '123', 'Authorized', '27AWCPG1991Q1ZZ', 'AWCPG1991Q', NULL, 'Hinjewadi, Pune', NULL, '411057', 'Maharashtra', 'Pune', 'India', 'Hinjewadi, Pune', NULL, '411057', 'Maharashtra', 'Pune', 'India', 'Dealer', NULL, 1, 0, '7/4/2026 10:49:28 AM', '1', '7/4/2026 10:49:28 AM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (286, 'AL/2026-27/214', 'The House of Woods', 'The House of Woods', '9680702220', 'housewood9680702220@demo.com', '123', 'Authorized', '08BPSPJ9471G1Z7', 'BPSPJ9471G', NULL, 'Kota', NULL, '324007', 'Rajasthan', 'Kota', 'India', 'Kota', NULL, '324007', 'Rajasthan', 'Kota', 'India', 'Dealer', NULL, 1, 0, '7/4/2026 10:49:28 AM', '1', '7/4/2026 10:49:28 AM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (287, 'AL/2026-27/215', 'The Select', 'The Select', '9978744084', 'theselect9978744084@demo.com', '123', 'Authorized', '24AAUFT7795D1ZH', 'AAUFT7795D', NULL, 'Vadodara', NULL, '391410', 'Gujarat', 'Vadodara', 'India', 'Vadodara', NULL, '391410', 'Gujarat', 'Vadodara', 'India', 'Dealer', NULL, 1, 0, '7/4/2026 10:49:28 AM', '1', '7/4/2026 10:49:28 AM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (288, 'AL/2026-27/216', 'The Woods', 'The Woods', '9414101896', 'thewoods9414101896@demo.com', '123', 'Authorized', '08AAMHR2758G2ZP', 'AAMHR2758G', NULL, 'Banswara', NULL, '327001', 'Rajasthan', 'Banswara', 'India', 'Banswara', NULL, '327001', 'Rajasthan', 'Banswara', 'India', 'Dealer', NULL, 1, 0, '7/4/2026 10:49:28 AM', '1', '7/4/2026 10:49:28 AM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (289, 'AL/2026-27/217', 'Truflo by Hindware', 'Truflo by Hindware', '9880089798', 'truflo9880089798@demo.com', '123', 'Authorized', NULL, NULL, NULL, 'Belagavi', NULL, '590009', 'Maharashtra', 'Belagavi', 'India', 'Belagavi', NULL, '590009', 'Maharashtra', 'Belagavi', 'India', 'Dealer', NULL, 1, 0, '7/4/2026 10:49:28 AM', '1', '7/4/2026 10:49:28 AM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (290, 'AL/2026-27/218', 'Tushar Chikhale', 'Tushar Chikhale', '9618409977', 'tushar9618409977@demo.com', '123', 'Authorized', NULL, NULL, NULL, 'Chikhali, Pune', NULL, NULL, 'Maharashtra', 'Pune', 'India', 'Chikhali, Pune', NULL, NULL, 'Maharashtra', 'Pune', 'India', 'Dealer', NULL, 1, 0, '7/4/2026 10:49:28 AM', '1', '7/4/2026 10:49:28 AM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (291, 'AL/2026-27/219', 'Unique Interior', 'Unique Interior', '9811626211', 'unique9811626211@demo.com', '123', 'Authorized', '07DEOPS7343M2ZK', 'DEOPS7343M', NULL, 'New Delhi', NULL, '110051', 'Delhi', 'Delhi', 'India', 'New Delhi', NULL, '110051', 'Delhi', 'Delhi', 'India', 'Dealer', NULL, 1, 0, '7/4/2026 10:49:28 AM', '1', '7/4/2026 10:49:28 AM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (292, 'AL/2026-27/220', 'Vardhaman Dekors', 'Vardhaman Dekors', NULL, 'vardhaman@demo.com', '123', 'Authorized', '27BSXPD7318E1ZG', 'BSXPD7318E', NULL, 'Bhavani Peth, Pune', NULL, '411042', 'Maharashtra', 'Pune', 'India', 'Bhavani Peth, Pune', NULL, '411042', 'Maharashtra', 'Pune', 'India', 'Dealer', NULL, 1, 0, '7/4/2026 10:49:28 AM', '1', '7/4/2026 10:49:28 AM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (293, 'AL/2026-27/221', 'Varsha', 'Varsha', NULL, 'varsha@demo.com', '123', 'Authorized', NULL, NULL, NULL, 'Kothrud, Pune', NULL, NULL, 'Maharashtra', 'Pune', 'India', 'Kothrud, Pune', NULL, NULL, 'Maharashtra', 'Pune', 'India', 'Dealer', NULL, 1, 0, '7/4/2026 10:49:28 AM', '1', '7/4/2026 10:49:28 AM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (294, 'AL/2026-27/222', 'VASTU INTERIOR AND CONTRACTORS', 'VASTU INTERIOR AND CONTRACTORS', '7483368833', 'vastu7483368833@demo.com', '123', 'Authorized', NULL, NULL, NULL, 'Purna Nagar, Chikhali', '', NULL, 'Maharashtra', 'Pune', 'India', 'Purna Nagar, Chikhali', '', NULL, 'Maharashtra', 'Pune', 'India', 'Dealer', NULL, 1, 0, '7/4/2026 10:50:49 AM', '1', '7/4/2026 10:50:49 AM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (295, 'AL/2026-27/223', 'Vayu Decors Llp', 'Vayu Decors Llp', '6305942678', 'vayu6305942678@demo.com', '123', 'Authorized', '36AAWFV9739M1ZT', 'AAWFV9739M', NULL, 'Srinagar Colony Road, Hyderabad', '', NULL, 'Telangana', 'Hyderabad', 'India', 'Srinagar Colony Road, Hyderabad', '', NULL, 'Telangana', 'Hyderabad', 'India', 'Dealer', NULL, 1, 0, '7/4/2026 10:50:49 AM', '1', '7/4/2026 10:50:49 AM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (296, 'AL/2026-27/224', 'Veneer Point', 'Veneer Point', '9825321515', 'veneer9825321515@demo.com', '123', 'Authorized', '24AANFV1963C1Z6', 'AANFV1963C', NULL, 'Althan Bhatar Road, Surat', '', NULL, 'Gujarat', 'Surat', 'India', 'Althan Bhatar Road, Surat', '', NULL, 'Gujarat', 'Surat', 'India', 'Dealer', NULL, 1, 0, '7/4/2026 10:50:49 AM', '1', '7/4/2026 10:50:49 AM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (297, 'AL/2026-27/225', 'Vijay Ply & Lam', 'Vijay Ply & Lam', '9422775738', 'vijay9422775738@demo.com', '123', 'Authorized', '27BMYPS9914G1Z2', 'BMYPS9914G', NULL, 'Jalgaon', '', NULL, 'Maharashtra', 'Jalgaon', 'India', 'Jalgaon', '', NULL, 'Maharashtra', 'Jalgaon', 'India', 'Dealer', NULL, 1, 0, '7/4/2026 10:50:49 AM', '1', '7/4/2026 10:50:49 AM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (298, 'AL/2026-27/226', 'Vinayak Marketing Company', 'Vinayak Marketing Company', '7330303096', 'vinayak7330303096@demo.com', '123', 'Authorized', '27AHMPK2008F1ZL', 'AHMPK2008F', NULL, 'Ichalkaranji', '', NULL, 'Maharashtra', 'Kolhapur', 'India', 'Ichalkaranji', '', NULL, 'Maharashtra', 'Kolhapur', 'India', 'Dealer', NULL, 1, 0, '7/4/2026 10:50:49 AM', '1', '7/4/2026 10:50:49 AM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (299, 'AL/2026-27/227', 'vineeta agrawal', 'vineeta agrawal', '9823088151', 'vineeta9823088151@demo.com', '123', 'Authorized', NULL, NULL, NULL, '', NULL, NULL, 'Maharashtra', '', 'India', '', NULL, NULL, 'Maharashtra', '', 'India', 'Dealer', NULL, 1, 0, '7/4/2026 10:50:49 AM', '1', '7/4/2026 10:50:49 AM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (300, 'AL/2026-27/228', 'Vinod Plywood', 'Vinod Plywood', '7507037481', 'vinod7507037481@demo.com', '123', 'Authorized', '27ABEPA5585F1ZR', 'ABEPA5585F', NULL, 'Jalna Road, Chhatrapati Sambhaji Nagar', '', NULL, 'Maharashtra', 'Chhatrapati Sambhaji Nagar', 'India', 'Jalna Road, Chhatrapati Sambhaji Nagar', '', NULL, 'Maharashtra', 'Chhatrapati Sambhaji Nagar', 'India', 'Dealer', NULL, 1, 0, '7/4/2026 10:50:49 AM', '1', '7/4/2026 10:50:49 AM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (301, 'AL/2026-27/229', 'Viraj Vasantrao Kachare', 'Viraj Vasantrao Kachare', '8888888342', 'viraj8888888342@demo.com', '123', 'Authorized', NULL, NULL, NULL, 'Mundhwa, Pune', '', NULL, 'Maharashtra', 'Pune', 'India', 'Mundhwa, Pune', '', NULL, 'Maharashtra', 'Pune', 'India', 'Dealer', NULL, 1, 0, '7/4/2026 10:50:49 AM', '1', '7/4/2026 10:50:49 AM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (302, 'AL/2026-27/230', 'Viswa Interiors Pvt Ltd', 'Viswa Interiors Pvt Ltd', '9246244818', 'viswa9246244818@demo.com', '123', 'Authorized', '36AADCV9136G1Z4', 'AADCV9136G', NULL, 'Jeedimetla, Hyderabad', '', NULL, 'Telangana', 'Hyderabad', 'India', 'Jeedimetla, Hyderabad', '', NULL, 'Telangana', 'Hyderabad', 'India', 'Dealer', NULL, 1, 0, '7/4/2026 10:50:49 AM', '1', '7/4/2026 10:50:49 AM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (303, 'AL/2026-27/231', 'V Near', 'V Near', '9404000008', 'vnear9404000008@demo.com', '123', 'Authorized', '27AANFV9751G1ZI', 'AANFV9751G', NULL, 'Chikhalthana, Chhatrapati Sambhaji Nagar', '', NULL, 'Maharashtra', 'Chhatrapati Sambhaji Nagar', 'India', 'Chikhalthana, Chhatrapati Sambhaji Nagar', '', NULL, 'Maharashtra', 'Chhatrapati Sambhaji Nagar', 'India', 'Dealer', NULL, 1, 0, '7/4/2026 10:50:49 AM', '1', '7/4/2026 10:50:49 AM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (304, 'AL/2026-27/232', 'Wood Storie', 'Wood Storie', '9884214448', 'wood9884214448@demo.com', '123', 'Authorized', '33AASHA9905Q1ZK', 'AASHA9905Q', '', 'Choolai, Chennai', 'Choolai', '600112', 'Tamil Nadu', 'Choolai', 'India', 'Juneja Sunmica & Plywood', ' Ambala City, Subzi  Mandi', '134003', 'Haryana', 'Ambala', 'India', 'Dealer', NULL, 1, 0, '7/4/2026 10:50:49 AM', '1', '7/7/2026 2:36:03 PM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (305, 'AL/2026-27/233', 'Yukti Enterprises', 'Yukti Enterprises', '9818666035', 'yukti9818666035@demo.com', '123', 'Authorized', '07AKDPG6421G1ZI', 'AKDPG6421G', NULL, 'Kirti Nagar, New Delhi', '', NULL, 'Delhi', 'New Delhi', 'India', 'Kirti Nagar, New Delhi', '', NULL, 'Delhi', 'New Delhi', 'India', 'Dealer', NULL, 1, 0, '7/4/2026 10:50:49 AM', '1', '7/4/2026 10:50:49 AM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (306, 'AL/2026-27/234', 'M/S ONKAR NATH SUNIL KUMAR', 'M/S ONKAR NATH SUNIL KUMAR', '9918646776', 'onkarnath9918646776@demo.com', '3732', 'Authorized', '09AABFO0977B1ZF', 'AABFO0977B', '', ' NE Rly Plot NO.61  Jhakerkatti, Cooperganj ', 'KANPUR ', '208022', 'Uttar Pradesh', 'KANPUR ', 'India', ' NE Rly Plot NO.61  Jhakerkatti, Cooperganj ', 'KANPUR ', '208022', 'Uttar Pradesh', 'KANPUR ', 'India', 'Dealer', NULL, 1, 0, '7/7/2026 11:55:30 AM', '1', NULL, NULL);
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (307, 'AL/2026-27/235', 'SINGHAL DECOR LLP', 'SINGHAL DECOR LLP', '9979791000', 'singhal9979791000@demo.com', '2437', 'Authorized', '24AFWFS1701B1Z8', 'AFWFS1701B', '', ' Showroom 109-110 Anam-2 Vejalpur Nr. Axiom, Opp. Shivalik Satyamev', 'Ahmedabad Ambli', '380058', 'Gujarat', 'Ahmedabad Ambli', 'India', ' Showroom 109-110 Anam-2 Vejalpur Nr. Axiom, Opp. Shivalik Satyamev', 'Ahmedabad Ambli', '380058', 'Gujarat', 'Ahmedabad Ambli', 'India', 'Dealer', NULL, 1, 0, '7/7/2026 11:57:00 AM', '1', NULL, NULL);
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (308, 'AL/2026-27/236', 'FAST RAIL CARGO PRIVATE LIMITED', 'FAST RAIL CARGO PRIVATE LIMITED', '8169455658', 'fastnsafe8169455658@demo.com', '9896', 'Authorized', '27AACCF3841M1ZF', 'AACCF3841M', '', 'GROUND FLOOR GROUND FLOOR SHIV AASHISH INDL ESTATE ANDHERI KURLA ROAD ', 'ANDHERI EAST SAKINAKA ', '400072', 'Maharashtra', 'ANDHERI EAST SAKINAKA ', 'India', 'GROUND FLOOR GROUND FLOOR SHIV AASHISH INDL ESTATE ANDHERI KURLA ROAD ', 'ANDHERI EAST SAKINAKA ', '400072', 'Maharashtra', 'ANDHERI EAST SAKINAKA ', 'India', 'Dealer', NULL, 1, 0, '7/7/2026 12:07:14 PM', '1', NULL, NULL);
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (309, 'AL/2026-27/237', 'Operator1', NULL, '9876543210', 'Operator1@gmail.com', '123', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Operator', NULL, 1, 0, '7/7/2026 2:15:58 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (310, 'AL/2026-27/238', 'Operator2', NULL, '9876543210', 'Operator2@gmail.com', '123', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Operator', NULL, 1, 0, '7/7/2026 2:18:12 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (311, 'AL/2026-27/239', 'Operators3', NULL, '9876543210', 'Operators3@gmail.com', '123', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Operator', NULL, 1, 0, '7/7/2026 2:19:25 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (312, 'AL/2026-27/240', 'MOONLINE EXPRESS CARGO PRIVATE LIMITED', 'MOONLINE EXPRESS CARGO PRIVATE LIMITED', '9321723820', 'moonline9321723820@demo.com', '8874', 'Authorized', '27AAMCM7385D1Z2', 'AAMCM7385D', '', '1st Floor Unit No. 129 Sahar Cargo Estate J B Nagar ', 'Mumbai ', '400099', 'Maharashtra', 'Mumbai ', 'India', '1st Floor Unit No. 129 Sahar Cargo Estate J B Nagar ', 'Mumbai ', '400099', 'Maharashtra', 'Mumbai ', 'India', 'Dealer', NULL, 1, 0, '7/7/2026 2:42:38 PM', '1', NULL, NULL);
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (313, 'AL/2026-27/241', 'NAVKAR DECOR', 'NAVKAR DECOR', '9199293626', 'navkardecor@919929362655demo.com', '7977', 'Authorized', '08ABBFR2430F1ZK ', 'ABBFR2430F', '', ' PLOT NO 145, GALI NO 6,  MILKMAN COLNY CITY CIRCLE ', 'JODHPUR ', '342001', 'Rajasthan', 'JODHPUR ', 'India', ' PLOT NO 145, GALI NO 6,  MILKMAN COLNY CITY CIRCLE ', 'JODHPUR ', '342001', 'Rajasthan', 'JODHPUR ', 'India', 'Dealer', NULL, 1, 0, '7/8/2026 11:20:27 AM', '1', NULL, NULL);

SET IDENTITY_INSERT dbo.tbl_UserMaster OFF;


-- Structure for table [DB_AcryshadeLaminatesTestAWS].[dbo].[tbl_UserRoleAuthorization]
SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
CREATE TABLE [dbo].[tbl_UserRoleAuthorization](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[UserID] [int] NULL,
	[UserName] [nvarchar](200) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[MenuId] [int] NULL,
	[MenuName] [nvarchar](200) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[PageName] [nvarchar](200) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[PageAccess] [bit] NULL,
	[PagesButtonAccess] [bit] NULL,
	[CreatedBy] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[CreatedOn] [datetime] NULL,
	[UpdatedBy] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[UpdatedOn] [datetime] NULL,
	[IsDeleted] [bit] NULL,
PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]


-- Data for table [DB_AcryshadeLaminatesTestAWS].[dbo].[tbl_UserRoleAuthorization]
SET IDENTITY_INSERT dbo.tbl_UserRoleAuthorization ON;

INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (1, 1, 'Admin', 1, 'Dashboard', 'Dashboard.aspx', 1, 1, '1', '7/23/2026 4:11:12 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (2, 1, 'Admin', 2, 'Roles', 'RoleMaster.aspx', 1, 1, '1', '7/23/2026 4:11:12 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (3, 1, 'Admin', 3, 'Users', 'UserList.aspx', 1, 1, '1', '7/23/2026 4:11:12 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (4, 1, 'Admin', 4, 'Dealers', 'DealerList.aspx', 1, 1, '1', '7/23/2026 4:11:12 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (5, 1, 'Admin', 5, 'Sub Dealers', 'CompanyList.aspx', 1, 1, '1', '7/23/2026 4:11:12 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (6, 1, 'Admin', 6, 'Stages', 'StageList.aspx', 1, 1, '1', '7/23/2026 4:11:12 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (7, 1, 'Admin', 7, 'Machine', 'MachineList.aspx', 1, 1, '1', '7/23/2026 4:11:12 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (8, 1, 'Admin', 8, 'Raw Material', 'RawMaterialList.aspx', 1, 1, '1', '7/23/2026 4:11:12 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (9, 1, 'Admin', 9, 'Products', 'ProductList.aspx', 1, 1, '1', '7/23/2026 4:11:12 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (10, 1, 'Admin', 10, 'Transporter', 'TransporterList.aspx', 1, 1, '1', '7/23/2026 4:11:12 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (11, 1, 'Admin', 11, 'Work Order', 'WorkOrderList.aspx', 1, 1, '1', '7/23/2026 4:11:12 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (12, 1, 'Admin', 12, 'Place Order', 'PlaceOrder.aspx', 1, 1, '1', '7/23/2026 4:11:12 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (13, 1, 'Admin', 13, 'Assign Machine', 'AssignMachine.aspx', 1, 1, '1', '7/23/2026 4:11:12 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (14, 1, 'Admin', 14, 'Approve Designs', 'WorkOrdrForDesign.aspx', 1, 1, '1', '7/23/2026 4:11:12 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (15, 1, 'Admin', 15, 'Start Production', 'AssignWorkOrder.aspx', 1, 1, '1', '7/23/2026 4:11:12 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (16, 1, 'Admin', 16, 'Production Stage 1', 'WoProductionS1.aspx', 1, 1, '1', '7/23/2026 4:11:12 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (17, 1, 'Admin', 17, 'Production Stage 2', 'WoProductionS2.aspx', 1, 1, '1', '7/23/2026 4:11:12 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (18, 1, 'Admin', 18, 'Packaging', 'Packaging.aspx', 1, 1, '1', '7/23/2026 4:11:12 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (19, 1, 'Admin', 19, 'User Authorization', 'UserAuthorization.aspx', 1, 1, '1', '7/23/2026 4:11:12 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (20, 1, 'Admin', 21, 'Delivery Page', 'Delivery.aspx', 1, 1, '1', '7/23/2026 4:11:12 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (21, 1, 'Admin', 22, 'Production Reports', 'ProductionReport.aspx', 1, 1, '1', '7/23/2026 4:11:12 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (22, 1, 'Admin', 23, 'Machine Break Down', 'MachineBreakdown.aspx', 1, 1, '1', '7/23/2026 4:11:12 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (23, 1, 'Admin', 24, 'Trending Product Reports', 'TrendingReports.aspx', 1, 1, '1', '7/23/2026 4:11:12 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (24, 309, 'Operator1', 1, 'Dashboard', 'Dashboard.aspx', 0, 0, '1', '7/23/2026 4:11:58 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (25, 309, 'Operator1', 2, 'Roles', 'RoleMaster.aspx', 0, 0, '1', '7/23/2026 4:11:58 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (26, 309, 'Operator1', 3, 'Users', 'UserList.aspx', 0, 0, '1', '7/23/2026 4:11:58 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (27, 309, 'Operator1', 4, 'Dealers', 'DealerList.aspx', 0, 0, '1', '7/23/2026 4:11:58 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (28, 309, 'Operator1', 5, 'Sub Dealers', 'CompanyList.aspx', 0, 0, '1', '7/23/2026 4:11:58 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (29, 309, 'Operator1', 6, 'Stages', 'StageList.aspx', 0, 0, '1', '7/23/2026 4:11:58 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (30, 309, 'Operator1', 7, 'Machine', 'MachineList.aspx', 0, 0, '1', '7/23/2026 4:11:58 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (31, 309, 'Operator1', 8, 'Raw Material', 'RawMaterialList.aspx', 0, 0, '1', '7/23/2026 4:11:58 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (32, 309, 'Operator1', 9, 'Products', 'ProductList.aspx', 0, 0, '1', '7/23/2026 4:11:58 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (33, 309, 'Operator1', 10, 'Transporter', 'TransporterList.aspx', 0, 0, '1', '7/23/2026 4:11:58 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (34, 309, 'Operator1', 11, 'Work Order', 'WorkOrderList.aspx', 0, 0, '1', '7/23/2026 4:11:58 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (35, 309, 'Operator1', 12, 'Place Order', 'PlaceOrder.aspx', 0, 0, '1', '7/23/2026 4:11:58 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (36, 309, 'Operator1', 13, 'Assign Machine', 'AssignMachine.aspx', 0, 0, '1', '7/23/2026 4:11:58 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (37, 309, 'Operator1', 14, 'Approve Designs', 'WorkOrdrForDesign.aspx', 0, 0, '1', '7/23/2026 4:11:58 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (38, 309, 'Operator1', 15, 'Start Production', 'AssignWorkOrder.aspx', 0, 0, '1', '7/23/2026 4:11:58 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (39, 309, 'Operator1', 16, 'Production Stage 1', 'WoProductionS1.aspx', 1, 1, '1', '7/23/2026 4:11:58 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (40, 309, 'Operator1', 17, 'Production Stage 2', 'WoProductionS2.aspx', 1, 1, '1', '7/23/2026 4:11:58 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (41, 309, 'Operator1', 18, 'Packaging', 'Packaging.aspx', 0, 0, '1', '7/23/2026 4:11:58 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (42, 309, 'Operator1', 19, 'User Authorization', 'UserAuthorization.aspx', 0, 0, '1', '7/23/2026 4:11:58 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (43, 309, 'Operator1', 21, 'Delivery Page', 'Delivery.aspx', 0, 0, '1', '7/23/2026 4:11:58 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (44, 309, 'Operator1', 22, 'Production Reports', 'ProductionReport.aspx', 0, 0, '1', '7/23/2026 4:11:58 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (45, 309, 'Operator1', 23, 'Machine Break Down', 'MachineBreakdown.aspx', 0, 0, '1', '7/23/2026 4:11:58 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (46, 309, 'Operator1', 24, 'Trending Product Reports', 'TrendingReports.aspx', 0, 0, '1', '7/23/2026 4:11:58 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (47, 310, 'Operator2', 1, 'Dashboard', 'Dashboard.aspx', 0, 0, '1', '7/23/2026 4:12:13 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (48, 310, 'Operator2', 2, 'Roles', 'RoleMaster.aspx', 0, 0, '1', '7/23/2026 4:12:13 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (49, 310, 'Operator2', 3, 'Users', 'UserList.aspx', 0, 0, '1', '7/23/2026 4:12:13 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (50, 310, 'Operator2', 4, 'Dealers', 'DealerList.aspx', 0, 0, '1', '7/23/2026 4:12:13 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (51, 310, 'Operator2', 5, 'Sub Dealers', 'CompanyList.aspx', 0, 0, '1', '7/23/2026 4:12:13 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (52, 310, 'Operator2', 6, 'Stages', 'StageList.aspx', 0, 0, '1', '7/23/2026 4:12:13 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (53, 310, 'Operator2', 7, 'Machine', 'MachineList.aspx', 0, 0, '1', '7/23/2026 4:12:13 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (54, 310, 'Operator2', 8, 'Raw Material', 'RawMaterialList.aspx', 0, 0, '1', '7/23/2026 4:12:13 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (55, 310, 'Operator2', 9, 'Products', 'ProductList.aspx', 0, 0, '1', '7/23/2026 4:12:13 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (56, 310, 'Operator2', 10, 'Transporter', 'TransporterList.aspx', 0, 0, '1', '7/23/2026 4:12:13 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (57, 310, 'Operator2', 11, 'Work Order', 'WorkOrderList.aspx', 0, 0, '1', '7/23/2026 4:12:13 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (58, 310, 'Operator2', 12, 'Place Order', 'PlaceOrder.aspx', 0, 0, '1', '7/23/2026 4:12:13 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (59, 310, 'Operator2', 13, 'Assign Machine', 'AssignMachine.aspx', 0, 0, '1', '7/23/2026 4:12:13 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (60, 310, 'Operator2', 14, 'Approve Designs', 'WorkOrdrForDesign.aspx', 0, 0, '1', '7/23/2026 4:12:13 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (61, 310, 'Operator2', 15, 'Start Production', 'AssignWorkOrder.aspx', 0, 0, '1', '7/23/2026 4:12:13 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (62, 310, 'Operator2', 16, 'Production Stage 1', 'WoProductionS1.aspx', 1, 1, '1', '7/23/2026 4:12:13 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (63, 310, 'Operator2', 17, 'Production Stage 2', 'WoProductionS2.aspx', 1, 1, '1', '7/23/2026 4:12:13 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (64, 310, 'Operator2', 18, 'Packaging', 'Packaging.aspx', 0, 0, '1', '7/23/2026 4:12:13 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (65, 310, 'Operator2', 19, 'User Authorization', 'UserAuthorization.aspx', 0, 0, '1', '7/23/2026 4:12:13 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (66, 310, 'Operator2', 21, 'Delivery Page', 'Delivery.aspx', 0, 0, '1', '7/23/2026 4:12:13 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (67, 310, 'Operator2', 22, 'Production Reports', 'ProductionReport.aspx', 0, 0, '1', '7/23/2026 4:12:13 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (68, 310, 'Operator2', 23, 'Machine Break Down', 'MachineBreakdown.aspx', 0, 0, '1', '7/23/2026 4:12:13 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (69, 310, 'Operator2', 24, 'Trending Product Reports', 'TrendingReports.aspx', 0, 0, '1', '7/23/2026 4:12:13 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (70, 311, 'Operators3', 1, 'Dashboard', 'Dashboard.aspx', 0, 0, '1', '7/23/2026 4:13:04 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (71, 311, 'Operators3', 2, 'Roles', 'RoleMaster.aspx', 0, 0, '1', '7/23/2026 4:13:04 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (72, 311, 'Operators3', 3, 'Users', 'UserList.aspx', 0, 0, '1', '7/23/2026 4:13:04 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (73, 311, 'Operators3', 4, 'Dealers', 'DealerList.aspx', 0, 0, '1', '7/23/2026 4:13:04 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (74, 311, 'Operators3', 5, 'Sub Dealers', 'CompanyList.aspx', 0, 0, '1', '7/23/2026 4:13:04 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (75, 311, 'Operators3', 6, 'Stages', 'StageList.aspx', 0, 0, '1', '7/23/2026 4:13:04 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (76, 311, 'Operators3', 7, 'Machine', 'MachineList.aspx', 0, 0, '1', '7/23/2026 4:13:04 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (77, 311, 'Operators3', 8, 'Raw Material', 'RawMaterialList.aspx', 0, 0, '1', '7/23/2026 4:13:04 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (78, 311, 'Operators3', 9, 'Products', 'ProductList.aspx', 0, 0, '1', '7/23/2026 4:13:04 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (79, 311, 'Operators3', 10, 'Transporter', 'TransporterList.aspx', 0, 0, '1', '7/23/2026 4:13:04 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (80, 311, 'Operators3', 11, 'Work Order', 'WorkOrderList.aspx', 0, 0, '1', '7/23/2026 4:13:04 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (81, 311, 'Operators3', 12, 'Place Order', 'PlaceOrder.aspx', 0, 0, '1', '7/23/2026 4:13:04 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (82, 311, 'Operators3', 13, 'Assign Machine', 'AssignMachine.aspx', 0, 0, '1', '7/23/2026 4:13:04 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (83, 311, 'Operators3', 14, 'Approve Designs', 'WorkOrdrForDesign.aspx', 0, 0, '1', '7/23/2026 4:13:04 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (84, 311, 'Operators3', 15, 'Start Production', 'AssignWorkOrder.aspx', 0, 0, '1', '7/23/2026 4:13:04 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (85, 311, 'Operators3', 16, 'Production Stage 1', 'WoProductionS1.aspx', 1, 1, '1', '7/23/2026 4:13:04 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (86, 311, 'Operators3', 17, 'Production Stage 2', 'WoProductionS2.aspx', 1, 1, '1', '7/23/2026 4:13:04 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (87, 311, 'Operators3', 18, 'Packaging', 'Packaging.aspx', 0, 0, '1', '7/23/2026 4:13:04 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (88, 311, 'Operators3', 19, 'User Authorization', 'UserAuthorization.aspx', 0, 0, '1', '7/23/2026 4:13:04 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (89, 311, 'Operators3', 21, 'Delivery Page', 'Delivery.aspx', 0, 0, '1', '7/23/2026 4:13:04 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (90, 311, 'Operators3', 22, 'Production Reports', 'ProductionReport.aspx', 0, 0, '1', '7/23/2026 4:13:04 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (91, 311, 'Operators3', 23, 'Machine Break Down', 'MachineBreakdown.aspx', 0, 0, '1', '7/23/2026 4:13:04 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (92, 311, 'Operators3', 24, 'Trending Product Reports', 'TrendingReports.aspx', 0, 0, '1', '7/23/2026 4:13:04 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (93, 3, 'WEB LINK SERVICES PRIVATE LIMITED', 1, 'Dashboard', 'Dashboard.aspx', 0, 0, '1', '7/23/2026 4:14:21 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (94, 3, 'WEB LINK SERVICES PRIVATE LIMITED', 2, 'Roles', 'RoleMaster.aspx', 0, 0, '1', '7/23/2026 4:14:21 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (95, 3, 'WEB LINK SERVICES PRIVATE LIMITED', 3, 'Users', 'UserList.aspx', 0, 0, '1', '7/23/2026 4:14:21 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (96, 3, 'WEB LINK SERVICES PRIVATE LIMITED', 4, 'Dealers', 'DealerList.aspx', 0, 0, '1', '7/23/2026 4:14:21 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (97, 3, 'WEB LINK SERVICES PRIVATE LIMITED', 5, 'Sub Dealers', 'CompanyList.aspx', 0, 0, '1', '7/23/2026 4:14:21 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (98, 3, 'WEB LINK SERVICES PRIVATE LIMITED', 6, 'Stages', 'StageList.aspx', 0, 0, '1', '7/23/2026 4:14:21 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (99, 3, 'WEB LINK SERVICES PRIVATE LIMITED', 7, 'Machine', 'MachineList.aspx', 0, 0, '1', '7/23/2026 4:14:21 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (100, 3, 'WEB LINK SERVICES PRIVATE LIMITED', 8, 'Raw Material', 'RawMaterialList.aspx', 0, 0, '1', '7/23/2026 4:14:21 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (101, 3, 'WEB LINK SERVICES PRIVATE LIMITED', 9, 'Products', 'ProductList.aspx', 0, 0, '1', '7/23/2026 4:14:21 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (102, 3, 'WEB LINK SERVICES PRIVATE LIMITED', 10, 'Transporter', 'TransporterList.aspx', 0, 0, '1', '7/23/2026 4:14:21 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (103, 3, 'WEB LINK SERVICES PRIVATE LIMITED', 11, 'Work Order', 'WorkOrderList.aspx', 0, 0, '1', '7/23/2026 4:14:21 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (104, 3, 'WEB LINK SERVICES PRIVATE LIMITED', 12, 'Place Order', 'PlaceOrder.aspx', 1, 1, '1', '7/23/2026 4:14:21 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (105, 3, 'WEB LINK SERVICES PRIVATE LIMITED', 13, 'Assign Machine', 'AssignMachine.aspx', 0, 0, '1', '7/23/2026 4:14:21 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (106, 3, 'WEB LINK SERVICES PRIVATE LIMITED', 14, 'Approve Designs', 'WorkOrdrForDesign.aspx', 0, 0, '1', '7/23/2026 4:14:21 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (107, 3, 'WEB LINK SERVICES PRIVATE LIMITED', 15, 'Start Production', 'AssignWorkOrder.aspx', 0, 0, '1', '7/23/2026 4:14:21 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (108, 3, 'WEB LINK SERVICES PRIVATE LIMITED', 16, 'Production Stage 1', 'WoProductionS1.aspx', 0, 0, '1', '7/23/2026 4:14:21 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (109, 3, 'WEB LINK SERVICES PRIVATE LIMITED', 17, 'Production Stage 2', 'WoProductionS2.aspx', 0, 0, '1', '7/23/2026 4:14:21 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (110, 3, 'WEB LINK SERVICES PRIVATE LIMITED', 18, 'Packaging', 'Packaging.aspx', 0, 0, '1', '7/23/2026 4:14:21 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (111, 3, 'WEB LINK SERVICES PRIVATE LIMITED', 19, 'User Authorization', 'UserAuthorization.aspx', 0, 0, '1', '7/23/2026 4:14:21 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (112, 3, 'WEB LINK SERVICES PRIVATE LIMITED', 21, 'Delivery Page', 'Delivery.aspx', 0, 0, '1', '7/23/2026 4:14:21 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (113, 3, 'WEB LINK SERVICES PRIVATE LIMITED', 22, 'Production Reports', 'ProductionReport.aspx', 0, 0, '1', '7/23/2026 4:14:21 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (114, 3, 'WEB LINK SERVICES PRIVATE LIMITED', 23, 'Machine Break Down', 'MachineBreakdown.aspx', 0, 0, '1', '7/23/2026 4:14:21 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (115, 3, 'WEB LINK SERVICES PRIVATE LIMITED', 24, 'Trending Product Reports', 'TrendingReports.aspx', 0, 0, '1', '7/23/2026 4:14:21 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (116, 313, 'NAVKAR DECOR', 1, 'Dashboard', 'Dashboard.aspx', 0, 0, '1', '7/23/2026 4:14:40 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (117, 313, 'NAVKAR DECOR', 2, 'Roles', 'RoleMaster.aspx', 0, 0, '1', '7/23/2026 4:14:40 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (118, 313, 'NAVKAR DECOR', 3, 'Users', 'UserList.aspx', 0, 0, '1', '7/23/2026 4:14:40 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (119, 313, 'NAVKAR DECOR', 4, 'Dealers', 'DealerList.aspx', 0, 0, '1', '7/23/2026 4:14:40 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (120, 313, 'NAVKAR DECOR', 5, 'Sub Dealers', 'CompanyList.aspx', 0, 0, '1', '7/23/2026 4:14:40 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (121, 313, 'NAVKAR DECOR', 6, 'Stages', 'StageList.aspx', 0, 0, '1', '7/23/2026 4:14:40 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (122, 313, 'NAVKAR DECOR', 7, 'Machine', 'MachineList.aspx', 0, 0, '1', '7/23/2026 4:14:40 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (123, 313, 'NAVKAR DECOR', 8, 'Raw Material', 'RawMaterialList.aspx', 0, 0, '1', '7/23/2026 4:14:40 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (124, 313, 'NAVKAR DECOR', 9, 'Products', 'ProductList.aspx', 0, 0, '1', '7/23/2026 4:14:40 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (125, 313, 'NAVKAR DECOR', 10, 'Transporter', 'TransporterList.aspx', 0, 0, '1', '7/23/2026 4:14:40 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (126, 313, 'NAVKAR DECOR', 11, 'Work Order', 'WorkOrderList.aspx', 0, 0, '1', '7/23/2026 4:14:40 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (127, 313, 'NAVKAR DECOR', 12, 'Place Order', 'PlaceOrder.aspx', 1, 0, '1', '7/23/2026 4:14:40 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (128, 313, 'NAVKAR DECOR', 13, 'Assign Machine', 'AssignMachine.aspx', 0, 0, '1', '7/23/2026 4:14:40 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (129, 313, 'NAVKAR DECOR', 14, 'Approve Designs', 'WorkOrdrForDesign.aspx', 0, 0, '1', '7/23/2026 4:14:40 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (130, 313, 'NAVKAR DECOR', 15, 'Start Production', 'AssignWorkOrder.aspx', 0, 0, '1', '7/23/2026 4:14:40 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (131, 313, 'NAVKAR DECOR', 16, 'Production Stage 1', 'WoProductionS1.aspx', 0, 0, '1', '7/23/2026 4:14:40 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (132, 313, 'NAVKAR DECOR', 17, 'Production Stage 2', 'WoProductionS2.aspx', 0, 0, '1', '7/23/2026 4:14:40 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (133, 313, 'NAVKAR DECOR', 18, 'Packaging', 'Packaging.aspx', 0, 0, '1', '7/23/2026 4:14:40 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (134, 313, 'NAVKAR DECOR', 19, 'User Authorization', 'UserAuthorization.aspx', 0, 0, '1', '7/23/2026 4:14:40 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (135, 313, 'NAVKAR DECOR', 21, 'Delivery Page', 'Delivery.aspx', 0, 0, '1', '7/23/2026 4:14:40 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (136, 313, 'NAVKAR DECOR', 22, 'Production Reports', 'ProductionReport.aspx', 0, 0, '1', '7/23/2026 4:14:40 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (137, 313, 'NAVKAR DECOR', 23, 'Machine Break Down', 'MachineBreakdown.aspx', 0, 0, '1', '7/23/2026 4:14:40 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (138, 313, 'NAVKAR DECOR', 24, 'Trending Product Reports', 'TrendingReports.aspx', 0, 0, '1', '7/23/2026 4:14:40 PM', NULL, NULL, NULL);

SET IDENTITY_INSERT dbo.tbl_UserRoleAuthorization OFF;


-- Structure for table [DB_AcryshadeLaminatesTestAWS].[dbo].[tbl_WorkOrderDetails]
SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
CREATE TABLE [dbo].[tbl_WorkOrderDetails](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[HeaderID] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[ProductId] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[ProductName] [nvarchar](500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[PartNo] [nvarchar](300) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Description] [nvarchar](max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Size] [nvarchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Unit] [nvarchar](20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Qty] [nvarchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[SqFeet] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[UploadedImage] [nvarchar](200) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Type] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
 CONSTRAINT [PK__tbl_Work__3214EC07377E67F7] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

ALTER TABLE [dbo].[tbl_WorkOrderDetails] ADD  CONSTRAINT [DF__tbl_WorkOrd__Qty__3864608B]  DEFAULT ((0)) FOR [Qty]

-- Data for table [DB_AcryshadeLaminatesTestAWS].[dbo].[tbl_WorkOrderDetails]
SET IDENTITY_INSERT dbo.tbl_WorkOrderDetails ON;

INSERT INTO dbo.tbl_WorkOrderDetails (Id, HeaderID, ProductId, ProductName, PartNo, Description, Size, Unit, Qty, SqFeet, UploadedImage, Type) VALUES (1, '1', '81', 'AS HD 044(A) Textura Sheet', '0', 'Regular-N/A', '8x4', 'NOS', '10', '320', '~/MyProducts/f8cf0809-c424-4a6c-85b1-b59da9261ff8_AS HD 044A.jpg', 'Regular');
INSERT INTO dbo.tbl_WorkOrderDetails (Id, HeaderID, ProductId, ProductName, PartNo, Description, Size, Unit, Qty, SqFeet, UploadedImage, Type) VALUES (2, '2', '24', 'AS HD 012(B) Textura Sheet', '0', 'Regular-N/A', '8x2', 'NOS', '20', '320', '~/MyProducts/7ff1382c-ea61-47b8-bfb0-342d7fed7e10_AS HD 012B.jpg', 'Regular');
INSERT INTO dbo.tbl_WorkOrderDetails (Id, HeaderID, ProductId, ProductName, PartNo, Description, Size, Unit, Qty, SqFeet, UploadedImage, Type) VALUES (3, '2', '77', 'AS HD 042(A) Textura Sheet', '0', 'Size change', '8x2', 'NOS', '30', '480', '~/MyProducts/3dc5fcd9-bc3d-4829-ac03-b97687ec8b8d_AS HD 042A.jpg', 'Custom');
INSERT INTO dbo.tbl_WorkOrderDetails (Id, HeaderID, ProductId, ProductName, PartNo, Description, Size, Unit, Qty, SqFeet, UploadedImage, Type) VALUES (4, '3', '96', 'AS HD 058(A) Textura Sheet', '0', 'Regular-N/A', '8x4', 'NOS', '20', '640', '~/MyProducts/b0eaaa68-e165-42bd-8b1b-a92e4ac9840b_AS HD 058A.jpg', 'Regular');

SET IDENTITY_INSERT dbo.tbl_WorkOrderDetails OFF;


-- Structure for table [DB_AcryshadeLaminatesTestAWS].[dbo].[tbl_WorkOrderHdr]
SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
CREATE TABLE [dbo].[tbl_WorkOrderHdr](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[SeriesNo] [nvarchar](200) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[TallyRefNo] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[WorkOrderDate] [date] NULL,
	[Dealer] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[CustomerName] [nvarchar](500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[CustomerRefNo] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[BillingGstNo] [nvarchar](200) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[BillingAddress] [nvarchar](max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[BillingPincode] [nvarchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[ShippingGstNo] [nvarchar](200) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[ShippingAddress] [nvarchar](max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[ShippingPincode] [nvarchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[DeliveryDate] [date] NULL,
	[CreatedOn] [datetime] NULL,
	[CreatedBy] [nvarchar](200) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[UpdatedOn] [datetime] NULL,
	[UpdatedBy] [nvarchar](200) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[IsDeleted] [bit] NULL,
	[IsDispatched] [bit] NULL,
	[isproductioncompleted] [bit] NULL,
	[isdesignapproved] [bit] NULL,
	[AttachmentPath] [nvarchar](max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[RankNo] [int] NULL,
	[ScheduledDate] [datetime] NULL,
	[PlaceOrderID] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[AttachmentLR] [nvarchar](max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[IsLRAttached] [bit] NULL,
	[DeliveryRemark] [nvarchar](max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[IsAllCompleted] [bit] NULL,
	[LRUplodedBy] [nvarchar](200) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[LRUplodedDate] [datetime] NULL,
	[HoldStatus] [bit] NULL,
	[HoldDate] [datetime] NULL,
	[CancelStatus] [bit] NULL,
	[Canceldate] [datetime] NULL,
	[InvoiceAttached] [nvarchar](500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[DispatchedDate] [datetime] NULL,
	[DeliveredDate] [datetime] NULL,
	[SendForDesign] [bit] NULL,
 CONSTRAINT [PK__tbl_Work__3214EC27519A97A5] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

ALTER TABLE [dbo].[tbl_WorkOrderHdr] ADD  CONSTRAINT [DF__tbl_WorkO__IsDel__2DE6D218]  DEFAULT ((1)) FOR [IsDeleted]

-- Data for table [DB_AcryshadeLaminatesTestAWS].[dbo].[tbl_WorkOrderHdr]
SET IDENTITY_INSERT dbo.tbl_WorkOrderHdr ON;

INSERT INTO dbo.tbl_WorkOrderHdr (ID, SeriesNo, TallyRefNo, WorkOrderDate, Dealer, CustomerName, CustomerRefNo, BillingGstNo, BillingAddress, BillingPincode, ShippingGstNo, ShippingAddress, ShippingPincode, DeliveryDate, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy, IsDeleted, IsDispatched, isproductioncompleted, isdesignapproved, AttachmentPath, RankNo, ScheduledDate, PlaceOrderID, AttachmentLR, IsLRAttached, DeliveryRemark, IsAllCompleted, LRUplodedBy, LRUplodedDate, HoldStatus, HoldDate, CancelStatus, Canceldate, InvoiceAttached, DispatchedDate, DeliveredDate, SendForDesign) VALUES (1, 'WO/2026-27/001', 'WO/2026-27/001', '7/24/2026 12:00:00 AM', 'WEB LINK SERVICES PRIVATE LIMITED', 'WEB LINK SERVICES PRIVATE LIMITED', 'ORD000011', '27AABCW8929J2ZP', '4 FLAT NO A-506 Aksha Vrundavan CHIKHALI MOSHI ROAD OPP INDIAL OIL PETROL PUMP', '411062', '27AABCW8929J2ZP', '4 FLAT NO A-506 Aksha Vrundavan CHIKHALI MOSHI ROAD OPP INDIAL OIL PETROL PUMP', '411062', '7/29/2026 12:00:00 AM', '7/18/2026 10:10:24 AM', '1', NULL, NULL, 0, 0, 0, 1, NULL, NULL, '7/25/2026 12:00:00 AM', '1', NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, 0, NULL, NULL, NULL, NULL, 1);
INSERT INTO dbo.tbl_WorkOrderHdr (ID, SeriesNo, TallyRefNo, WorkOrderDate, Dealer, CustomerName, CustomerRefNo, BillingGstNo, BillingAddress, BillingPincode, ShippingGstNo, ShippingAddress, ShippingPincode, DeliveryDate, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy, IsDeleted, IsDispatched, isproductioncompleted, isdesignapproved, AttachmentPath, RankNo, ScheduledDate, PlaceOrderID, AttachmentLR, IsLRAttached, DeliveryRemark, IsAllCompleted, LRUplodedBy, LRUplodedDate, HoldStatus, HoldDate, CancelStatus, Canceldate, InvoiceAttached, DispatchedDate, DeliveredDate, SendForDesign) VALUES (2, 'WO/2026-27/002', 'WO/2026-27/002', '7/25/2026 12:00:00 AM', 'NAVKAR DECOR', 'NAVKAR DECOR', 'ORD000012', '08ABBFR2430F1ZK', 'PLOT NO 145, GALI NO 6,  MILKMAN COLNY CITY CIRCLE', '342001', '08ABBFR2430F1ZK', 'PLOT NO 145, GALI NO 6,  MILKMAN COLNY CITY CIRCLE', '342001', '7/29/2026 12:00:00 AM', '7/25/2026 9:59:26 AM', '1', NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2', NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, 0, NULL, NULL, NULL, NULL, 1);
INSERT INTO dbo.tbl_WorkOrderHdr (ID, SeriesNo, TallyRefNo, WorkOrderDate, Dealer, CustomerName, CustomerRefNo, BillingGstNo, BillingAddress, BillingPincode, ShippingGstNo, ShippingAddress, ShippingPincode, DeliveryDate, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy, IsDeleted, IsDispatched, isproductioncompleted, isdesignapproved, AttachmentPath, RankNo, ScheduledDate, PlaceOrderID, AttachmentLR, IsLRAttached, DeliveryRemark, IsAllCompleted, LRUplodedBy, LRUplodedDate, HoldStatus, HoldDate, CancelStatus, Canceldate, InvoiceAttached, DispatchedDate, DeliveredDate, SendForDesign) VALUES (3, 'WO/2026-27/003', 'WO/2026-27/003', '7/25/2026 12:00:00 AM', 'Abhishek Plywood & Hardware', 'Abhishek Plywood & Hardware', 'ORD000013', '27AIJPL4561C1ZC', '1477 Abhishek Plywood & Hardware, Near Sona Sadi Center, Gandhi Chowk, Kopargaon', '423601', '27AIJPL4561C1ZC', '1477 Abhishek Plywood & Hardware, Near Sona Sadi Center, Gandhi Chowk, Kopargaon', '423601', '7/30/2026 12:00:00 AM', '7/25/2026 10:00:02 AM', '1', NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '3', NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, 0, NULL, NULL, NULL, NULL, 1);

SET IDENTITY_INSERT dbo.tbl_WorkOrderHdr OFF;


-- VIEWS

-- STORED PROCEDURES
-- Script for SP_ProductsMaster
GO
CREATE PROCEDURE [dbo].[SP_ProductsMaster]
    @ShowRecords INT = 0,
    @ID INT = 0,
    @PartName NVARCHAR(200) = NULL,
    @Productcode NVARCHAR(100) = NULL,
    @Thickness NVARCHAR(100) = NULL,
    @ProductCategory NVARCHAR(200) = NULL,
    @PartNo NVARCHAR(100) = NULL,
    @Size NVARCHAR(MAX) = NULL,
    @ImagenamePath NVARCHAR(500) = Null,
    @IsActive BIT =  Null,
    @ActionBy NVARCHAR(100) = NULL,
    @SP_Action NVARCHAR(100) = NULL,
    @Productname  NVARCHAR(100) = NULL
AS
BEGIN
    IF @SP_Action = 'ProductList'
    BEGIN
        WITH ProductMaster AS
        (
            SELECT
                ID,
                Productcode,
                ProductCategory,
                Productname,
                PartName,
                Thickness,
                PartNo,
                Size,
                ImagenamePath,
                IsActive,
                FavoriteProduct
            FROM tbl_ProdcutMaster
            WHERE IsDeleted = 0
            AND (
                    Productname LIKE CASE
                                    WHEN ISNULL(@Productname,'') <> ''
                                    THEN '%' + @Productname + '%'
                                    ELSE '%'
                                  END
                )
        ),
        NUMBERED AS
        (
            SELECT *,
                   ROW_NUMBER() OVER(ORDER BY ID DESC) RN
            FROM ProductMaster
        )
        SELECT *
        FROM NUMBERED
        WHERE @ShowRecords = 0
           OR RN <= @ShowRecords
        ORDER BY ID DESC;
    END

    IF @SP_Action = 'ProductListById'
    BEGIN
        SELECT *
        FROM tbl_ProdcutMaster
        WHERE ID = @ID;
    END

    IF @SP_Action = 'InsertProduct'
    BEGIN
        INSERT INTO tbl_ProdcutMaster
        (
             Productcode,
             ProductCategory,
             Productname,
             PartName,
             Thickness,
             PartNo,
             Size,
             ImagenamePath,
             IsActive,
            IsDeleted,
            CreatedBy,
            CreatedOn
        )
        VALUES
        (
             @Productcode,
             @ProductCategory,
             @Productname,
             @PartName,
             @Thickness,
             @PartNo,
             @Size,
             @ImagenamePath,
              1,
              0,
              @ActionBy,
             GETDATE()
        );
    END

    IF @SP_Action = 'Deleteproduct'
     BEGIN
       Update tbl_ProdcutMaster set isdeleted = 1 where  ID = @ID
     END
     
    IF @SP_Action = 'UpdateProduct'
     BEGIN
        UPDATE tbl_ProdcutMaster
            SET
                Productname = @Productname,
                ProductCategory = @ProductCategory,
                PartName    = @PartName,
                Thickness   = @Thickness,
                PartNo      = @PartNo,
                Size        = @Size,
                ImagenamePath = @ImagenamePath,
                UpdatedBy   = @ActionBy,
                UpdatedOn   = GETDATE()
         WHERE ID = @ID;
      END

END

-- Script for SP_Productioncapacity
GO
CREATE PROCEDURE [dbo].[SP_Productioncapacity]
    @ShowRecords INT = 0,
    @Id int =0,
    @WorkOrderNo NVARCHAR(200) = NULL,
    @SP_Action NVARCHAR(100) = NULL

AS
BEGIN
    DECLARE @MachineId INT;

    IF @SP_Action = 'DailyTotalcapacity'
    BEGIN
   SELECT
    AllocatedStage,
    SUM(
        TRY_CAST(MachinePerHRQty AS FLOAT) *
        TRY_CAST(MachineRunningHR AS FLOAT)
    ) AS StageDailyCapacity
FROM [DB_AcryshadeLaminatesTest].[dbo].[tbl_MachineMaster]
WHERE IsActive = 1
AND IsDeleted = 0
GROUP BY AllocatedStage;
    END

    IF @SP_Action ='machinecount'
    BEGIN
      SELECT 
    AllocatedStage,
    COUNT(ID) AS MachineCount
FROM [DB_AcryshadeLaminatesTest].[dbo].[tbl_MachineMaster]
WHERE IsActive = 1
  AND IsDeleted = 0
GROUP BY AllocatedStage
ORDER BY AllocatedStage;
    END

    IF @SP_Action='GetCapacity'
    BEGIN
      SELECT
    M.AllocatedStage,
    M.MachineName,

    (TRY_CAST(M.MachinePerHRQty AS FLOAT) *
     TRY_CAST(M.MachineRunningHR AS FLOAT)) AS MachineCapacity,

    ISNULL(SUM(TRY_CAST(PM.PlannedQty AS FLOAT)),0) AS MachineLoad,

    (
        (TRY_CAST(M.MachinePerHRQty AS FLOAT) *
         TRY_CAST(M.MachineRunningHR AS FLOAT))
        - ISNULL(SUM(TRY_CAST(PM.PlannedQty AS FLOAT)),0)
    ) AS MachineAvailable,

    -- ✔ LOAD %
    CASE 
        WHEN (TRY_CAST(M.MachinePerHRQty AS FLOAT) *
              TRY_CAST(M.MachineRunningHR AS FLOAT)) = 0
        THEN 0

        ELSE 
            ROUND(
                (ISNULL(SUM(TRY_CAST(PM.PlannedQty AS FLOAT)),0) * 100.0)
                /
                (TRY_CAST(M.MachinePerHRQty AS FLOAT) *
                 TRY_CAST(M.MachineRunningHR AS FLOAT))
            ,2)
    END AS LoadPercentage

FROM tbl_MachineMaster M
LEFT JOIN tbl_ProductionMachineLoading PM
    ON M.ID = PM.MachineId
    AND PM.Status = 'In-Process'

WHERE M.IsDeleted = 0
and M.IsActive=1
GROUP BY
    M.AllocatedStage,
    M.MachineName,
    M.MachinePerHRQty,
    M.MachineRunningHR;
    END
    
  --  IF @SP_Action = 'GetReceivedWO'
  --   BEGIN
  --      WITH WorkOrders
		--	AS (
		--	    SELECT * FROM tbl_ProductionInatial
  --              WHERE (
		--				WorkOrderNo LIKE CASE 
		--					WHEN @WorkOrderNo != ''
		--						THEN @WorkOrderNo
		--					ELSE '%%'
		--					END
		--	          )
		--	   ),NUMBERED
		--AS (
		--	SELECT *
		--		,ROW_NUMBER() OVER (
		--			ORDER BY Id DESC
		--			) AS RN
		--	FROM WorkOrders
		--	)
		--SELECT *
		--FROM NUMBERED
		--WHERE @ShowRecords = 0
		--	OR RN <= @ShowRecords
		--ORDER BY ID DESC
  --   END
    -----updated----------
    --IF @SP_Action = 'StartProduction'
    -- BEGIN
    --     SELECT TOP 1
    --            @MachineId = M.ID
    --        FROM tbl_MachineMaster M
    --        LEFT JOIN tbl_ProductionMachineLoading PM
    --            ON M.ID = PM.MachineId
    --            AND PM.Status = 'In-Process'
    --        WHERE M.IsDeleted = 0
    --            AND M.IsActive = 1
    --            AND M.AllocatedStage = 'Stage 1'
    --        GROUP BY
    --            M.ID,
    --            M.MachinePerHRQty,
    --            M.MachineRunningHR
    --        HAVING
    --        (
    --            (TRY_CAST(M.MachinePerHRQty AS FLOAT) *
    --             TRY_CAST(M.MachineRunningHR AS FLOAT))
    --            -
    --            ISNULL(SUM(TRY_CAST(PM.PlannedQty AS FLOAT)),0)
    --        ) >=
    --        (
    --            SELECT TotalQty
    --            FROM tbl_ProductionInatial
    --            WHERE ID = @Id
    --        )
    --        ORDER BY
    --        (
    --            (TRY_CAST(M.MachinePerHRQty AS FLOAT) *
    --             TRY_CAST(M.MachineRunningHR AS FLOAT))
    --            -
    --            ISNULL(SUM(TRY_CAST(PM.PlannedQty AS FLOAT)),0)
    --        ) DESC;


    --  	INSERT INTO tbl_ProductionMachineLoading
    --    (
    --        ProductionPlanId,
    --        WorkOrderId,
    --        MachineId,
    --        AllocatedStage,
    --        ScheduleDate,
    --        PlannedQty,
    --        ProducedQty,
    --        Status
    --    )
    --    SELECT
    --        PI.ID,
    --        PI.WorkOrderId,
    --        @MachineId,
    --        'Stage 1',
    --        GETDATE(),
    --        PI.TotalQty,
    --        0,
    --        'In-Process'
    --    FROM tbl_ProductionInatial PI
    --    WHERE PI.ID = @Id;
    -- END



--    IF @SP_Action = 'StartProduction'
--BEGIN

--    DECLARE @RemainingQty FLOAT;
--    DECLARE @MachineIdLocal INT;
--    DECLARE @AvailableQty FLOAT;
--    DECLARE @AllocateQty FLOAT;
--    DECLARE @WorkOrderId INT;

--    SELECT
--        @RemainingQty = TotalQty,
--        @WorkOrderId = WorkOrderId
--    FROM tbl_ProductionInatial
--    WHERE ID = @Id;

--    DECLARE MachineCursor CURSOR FOR

--    SELECT
--        M.ID,

--        (
--            (TRY_CAST(M.MachinePerHRQty AS FLOAT)
--            * TRY_CAST(M.MachineRunningHR AS FLOAT))

--            - ISNULL(
--                SUM(
--                    TRY_CAST(PM.PlannedQty AS FLOAT)
--                ),0
--            )
--        ) AS AvailableQty

--    FROM tbl_MachineMaster M

--    LEFT JOIN tbl_ProductionMachineLoading PM
--        ON M.ID = PM.MachineId
--        AND PM.Status = 'In-Process'

--    WHERE M.IsDeleted = 0
--      AND M.IsActive = 1
--      AND M.AllocatedStage = 'Stage 1'

--    GROUP BY
--        M.ID,
--        M.MachinePerHRQty,
--        M.MachineRunningHR

--    HAVING
--        (
--            (TRY_CAST(M.MachinePerHRQty AS FLOAT)
--            * TRY_CAST(M.MachineRunningHR AS FLOAT))

--            - ISNULL(
--                SUM(
--                    TRY_CAST(PM.PlannedQty AS FLOAT)
--                ),0
--            )
--        ) > 0

--    ORDER BY AvailableQty DESC;

--    OPEN MachineCursor;

--    FETCH NEXT FROM MachineCursor
--    INTO @MachineIdLocal, @AvailableQty;

--    WHILE @@FETCH_STATUS = 0
--          AND @RemainingQty > 0
--    BEGIN

--        SET @AllocateQty =
--        CASE
--            WHEN @RemainingQty >= @AvailableQty
--                THEN @AvailableQty
--            ELSE @RemainingQty
--        END;

--        INSERT INTO tbl_ProductionMachineLoading
--        (
--            ProductionPlanId,
--            WorkOrderId,
--            MachineId,
--            AllocatedStage,
--            ScheduleDate,
--            PlannedQty,
--            ProducedQty,
--            Status
--        )
--        VALUES
--        (
--            @Id,
--            @WorkOrderId,
--            @MachineIdLocal,
--            'Stage 1',
--            GETDATE(),
--            @AllocateQty,
--            0,
--            'In-Process'
--        );

--        SET @RemainingQty =
--            @RemainingQty - @AllocateQty;

--        FETCH NEXT FROM MachineCursor
--        INTO @MachineIdLocal, @AvailableQty;
--    END

--    CLOSE MachineCursor;
--    DEALLOCATE MachineCursor;

--    IF @RemainingQty > 0
--    BEGIN
--        RAISERROR(
--            'Insufficient machine capacity. Remaining Qty not allocated.',
--            16,
--            1
--        );
--    END

--END


      ------updated-----------
     IF @SP_Action = 'StartProduction'
BEGIN

    DECLARE @RemainingQty FLOAT;
    DECLARE @MachineIdLocal INT;
    DECLARE @AvailableQty FLOAT;
    DECLARE @AllocateQty FLOAT;
    DECLARE @WorkOrderId INT;

    SELECT
        @RemainingQty = TotalQty,
        @WorkOrderId = WorkOrderId
    FROM tbl_ProductionInatial
    WHERE ID = @Id;


    DECLARE MachineCursor CURSOR FOR

    SELECT
        M.ID,

        (
            (TRY_CAST(M.MachinePerHRQty AS FLOAT) *
             TRY_CAST(M.MachineRunningHR AS FLOAT))
            -
            ISNULL(SUM(TRY_CAST(PM.PlannedQty AS FLOAT)), 0)
        ) AS AvailableQty

    FROM tbl_MachineMaster M

    LEFT JOIN tbl_ProductionMachineLoading PM
        ON M.ID = PM.MachineId
        AND PM.Status = 'In-Process'

    WHERE M.IsDeleted = 0
      AND M.IsActive = 1
      AND M.AllocatedStage = 'Stage 1'

    GROUP BY
        M.ID,
        M.MachinePerHRQty,
        M.MachineRunningHR

    HAVING
        (
            (TRY_CAST(M.MachinePerHRQty AS FLOAT) *
             TRY_CAST(M.MachineRunningHR AS FLOAT))
            -
            ISNULL(SUM(TRY_CAST(PM.PlannedQty AS FLOAT)), 0)
        ) > 0


    ORDER BY
        -- ⭐ KEY FIX: prioritize machines already used first
        CASE
            WHEN ISNULL(SUM(TRY_CAST(PM.PlannedQty AS FLOAT)), 0) > 0
            THEN 0 ELSE 1
        END,
        M.ID;   -- maintain stable sequence


    OPEN MachineCursor;

    FETCH NEXT FROM MachineCursor
    INTO @MachineIdLocal, @AvailableQty;

    WHILE @@FETCH_STATUS = 0
          AND @RemainingQty > 0
    BEGIN

        SET @AllocateQty =
        CASE
            WHEN @RemainingQty >= @AvailableQty
                THEN @AvailableQty
            ELSE @RemainingQty
        END;

        INSERT INTO tbl_ProductionMachineLoading
        (
            ProductionPlanId,
            WorkOrderId,
            MachineId,
            AllocatedStage,
            ScheduleDate,
            PlannedQty,
            ProducedQty,
            Status
        )
        VALUES
        (
            @Id,
            @WorkOrderId,
            @MachineIdLocal,
            'Stage 1',
            GETDATE(),
            @AllocateQty,
            0,
            'In-Process'
        );

        SET @RemainingQty = @RemainingQty - @AllocateQty;

        FETCH NEXT FROM MachineCursor
        INTO @MachineIdLocal, @AvailableQty;

    END

    CLOSE MachineCursor;
    DEALLOCATE MachineCursor;


    IF @RemainingQty > 0
    BEGIN
        RAISERROR(
            'Insufficient machine capacity. Remaining Qty not allocated.',
            16,
            1
        );
    END

END


--IF @SP_Action = 'StartProduction'
--BEGIN

--    DECLARE @RemainingQty FLOAT;
--    DECLARE @MachineIdLocal INT;
--    DECLARE @AvailableQty FLOAT;
--    DECLARE @AllocateQty FLOAT;
--    DECLARE @WorkOrderId INT;

--    ---------------------------------------------------
--    -- STEP 1: GET SAFE REMAINING QTY (NO NEGATIVE)
--    ---------------------------------------------------
--    SELECT
--        @WorkOrderId = WorkOrderId,
--        @RemainingQty =
--            CASE 
--                WHEN TotalQty - ISNULL((
--                    SELECT SUM(PlannedQty)
--                    FROM tbl_ProductionMachineLoading
--                    WHERE ProductionPlanId = @Id
--                      AND AllocatedStage = 'Stage 1'
--                ), 0) < 0 
--                THEN 0
--                ELSE TotalQty - ISNULL((
--                    SELECT SUM(PlannedQty)
--                    FROM tbl_ProductionMachineLoading
--                    WHERE ProductionPlanId = @Id
--                      AND AllocatedStage = 'Stage 1'
--                ), 0)
--            END
--    FROM tbl_ProductionInatial
--    WHERE ID = @Id;

--    ---------------------------------------------------
--    -- STOP IF NOTHING LEFT
--    ---------------------------------------------------
--    IF @RemainingQty <= 0
--        RETURN;

--    ---------------------------------------------------
--    -- STEP 2: MACHINE CURSOR (CORRECT CAPACITY CALC)
--    ---------------------------------------------------
--    DECLARE MachineCursor CURSOR FOR

--    SELECT
--        M.ID,

--        (
--            (TRY_CAST(M.MachinePerHRQty AS FLOAT) *
--             TRY_CAST(M.MachineRunningHR AS FLOAT))
--            -
--            ISNULL(
--                SUM(
--                    CASE
--                        WHEN PM.ProductionPlanId = @Id
--                         AND PM.AllocatedStage = 'Stage 1'
--                        THEN PM.PlannedQty
--                        ELSE 0
--                    END
--                ), 0
--            )
--        ) AS AvailableQty

--    FROM tbl_MachineMaster M

--    LEFT JOIN tbl_ProductionMachineLoading PM
--        ON M.ID = PM.MachineId

--    WHERE M.IsDeleted = 0
--      AND M.IsActive = 1
--      AND M.AllocatedStage = 'Stage 1'

--    GROUP BY
--        M.ID,
--        M.MachinePerHRQty,
--        M.MachineRunningHR

--    HAVING
--        (
--            (TRY_CAST(M.MachinePerHRQty AS FLOAT) *
--             TRY_CAST(M.MachineRunningHR AS FLOAT))
--            -
--            ISNULL(
--                SUM(
--                    CASE
--                        WHEN PM.ProductionPlanId = @Id
--                         AND PM.AllocatedStage = 'Stage 1'
--                        THEN PM.PlannedQty
--                        ELSE 0
--                    END
--                ), 0
--            )
--        ) > 0

--    ORDER BY M.ID;

--    OPEN MachineCursor;

--    FETCH NEXT FROM MachineCursor
--    INTO @MachineIdLocal, @AvailableQty;

--    ---------------------------------------------------
--    -- STEP 3: ALLOCATION LOOP (NO OVERBOOKING)
--    ---------------------------------------------------
--    WHILE @@FETCH_STATUS = 0
--          AND @RemainingQty > 0
--    BEGIN

--        ---------------------------------------------------
--        -- STEP 3.1: REAL TIME CAPACITY CHECK
--        ---------------------------------------------------
--        DECLARE @MachineCapacity FLOAT;
--        DECLARE @UsedQty FLOAT;
--        DECLARE @FreeQty FLOAT;

--        SELECT
--            @MachineCapacity =
--                TRY_CAST(MachinePerHRQty AS FLOAT) *
--                TRY_CAST(MachineRunningHR AS FLOAT)
--        FROM tbl_MachineMaster
--        WHERE ID = @MachineIdLocal;

--        SELECT
--            @UsedQty = ISNULL(SUM(PlannedQty), 0)
--        FROM tbl_ProductionMachineLoading
--        WHERE MachineId = @MachineIdLocal
--          AND ProductionPlanId = @Id
--          AND AllocatedStage = 'Stage 1';

--        SET @FreeQty = @MachineCapacity - @UsedQty;

--        ---------------------------------------------------
--        -- SKIP IF NO CAPACITY
--        ---------------------------------------------------
--        IF @FreeQty <= 0
--        BEGIN
--            FETCH NEXT FROM MachineCursor
--            INTO @MachineIdLocal, @AvailableQty;

--            CONTINUE;
--        END

--        ---------------------------------------------------
--        -- STEP 3.2: SAFE ALLOCATION
--        ---------------------------------------------------
--        SET @AllocateQty =
--            CASE
--                WHEN @RemainingQty >= @FreeQty
--                    THEN @FreeQty
--                ELSE @RemainingQty
--            END;

--        ---------------------------------------------------
--        -- STEP 4: INSERT ONLY SAFE VALUE
--        ---------------------------------------------------
--        INSERT INTO tbl_ProductionMachineLoading
--        (
--            ProductionPlanId,
--            WorkOrderId,
--            MachineId,
--            AllocatedStage,
--            ScheduleDate,
--            PlannedQty,
--            ProducedQty,
--            Status
--        )
--        VALUES
--        (
--            @Id,
--            @WorkOrderId,
--            @MachineIdLocal,
--            'Stage 1',
--            GETDATE(),
--            @AllocateQty,
--            0,
--            'In-Process'
--        );

--        ---------------------------------------------------
--        -- STEP 5: UPDATE REMAINING
--        ---------------------------------------------------
--        SET @RemainingQty = @RemainingQty - @AllocateQty;

--        ---------------------------------------------------
--        -- NEXT MACHINE
--        ---------------------------------------------------
--        FETCH NEXT FROM MachineCursor
--        INTO @MachineIdLocal, @AvailableQty;

--    END

--    CLOSE MachineCursor;
--    DEALLOCATE MachineCursor;

--    ---------------------------------------------------
--    -- FINAL OUTPUT (NO NEGATIVE POSSIBLE)
--    ---------------------------------------------------
--    SELECT
--        @Id AS ProductionPlanId,
--        @RemainingQty AS PendingQty,
--        'SAFE PRODUCTION COMPLETED (NO OVERBOOKING)' AS Message;

--END


     IF @SP_Action = 'GetReceivedWO'
     Begin
--     WITH WorkOrders AS
--(
--    SELECT *
--    FROM tbl_ProductionInatial
--    WHERE WorkOrderNo LIKE
--    CASE
--        WHEN ISNULL(@WorkOrderNo,'') <> ''
--            THEN @WorkOrderNo
--        ELSE '%'
--    END
--),
--NUMBERED AS
--(
--    SELECT *,
--           ROW_NUMBER() OVER(ORDER BY ID DESC) AS RN
--    FROM WorkOrders
--),
--Loading AS
--(
--    SELECT
--        ProductionPlanId,
--        SUM(PlannedQty) AS ScheduledQty
--    FROM tbl_ProductionMachineLoading
--    GROUP BY ProductionPlanId
--)

--SELECT
--    N.*,
--    ISNULL(L.ScheduledQty,0) AS ScheduledQty,
--    N.TotalQty - ISNULL(L.ScheduledQty,0) AS PendingQty
--FROM NUMBERED N
--LEFT JOIN Loading L
--    ON L.ProductionPlanId = N.ID
--WHERE @ShowRecords = 0
--   OR N.RN <= @ShowRecords
--ORDER BY N.ID DESC;



--WITH WorkOrders AS
--(
--    SELECT *
--    FROM tbl_ProductionInatial
--    WHERE WorkOrderNo LIKE
--        CASE
--            WHEN ISNULL(@WorkOrderNo,'') <> ''
--                THEN @WorkOrderNo
--            ELSE '%'
--        END
--),

--NUMBERED AS
--(
--    SELECT *,
--           ROW_NUMBER() OVER(ORDER BY ID DESC) AS RN
--    FROM WorkOrders
--),

---- ✅ TOTAL per WorkOrder (FIX)
--Loading AS
--(
--    SELECT
--        ProductionPlanId,
--        SUM(PlannedQty) AS ScheduledQty,
--        MIN(ScheduleDate) AS FirstScheduleDate,
--        MAX(ScheduleDate) AS LastScheduleDate
--    FROM tbl_ProductionMachineLoading
--    GROUP BY ProductionPlanId
--)

--SELECT
--    N.ID,
--    N.WorkOrderNo,
--    N.Size,
--    CAST(CAST(N.TotalQty AS FLOAT) AS INT) AS TotalQty,
--CAST(CAST(ISNULL(L.ScheduledQty,0) AS FLOAT) AS INT) AS ScheduledQty,
--CAST(
--    CAST(N.TotalQty AS FLOAT)
--    - CAST(ISNULL(L.ScheduledQty,0) AS FLOAT)
--AS INT) AS PendingQty,
--   CONVERT(VARCHAR(19), L.FirstScheduleDate, 120) AS FirstScheduleDateTime,
--    CONVERT(VARCHAR(19), L.LastScheduleDate, 120) AS LastScheduleDateTime,

--    CASE
--        WHEN ISNULL(L.ScheduledQty,0) = 0 THEN 'Not Scheduled'
--        WHEN ISNULL(L.ScheduledQty,0) < N.TotalQty THEN 'Partially Scheduled'
--        ELSE 'Fully Scheduled'
--    END AS ProductionStatus,

--    CASE
--        WHEN L.LastScheduleDate IS NULL THEN NULL
--        WHEN CONVERT(date, L.LastScheduleDate) = CONVERT(date, GETDATE())
--            THEN 'Scheduled Today'
--        ELSE 'Scheduled'
--    END AS ScheduleStatus

--FROM NUMBERED N
--LEFT JOIN Loading L
--    ON L.ProductionPlanId = N.ID

--WHERE @ShowRecords = 0
--   OR N.RN <= @ShowRecords

--ORDER BY N.ID DESC;


WITH WorkOrders AS
(
    SELECT *
    FROM tbl_ProductionInatial
    WHERE WorkOrderNo LIKE
        CASE
            WHEN ISNULL(@WorkOrderNo,'') <> ''
                THEN @WorkOrderNo
            ELSE '%'
        END
),

NUMBERED AS
(
    SELECT *,
           ROW_NUMBER() OVER(ORDER BY ID DESC) AS RN
    FROM WorkOrders
),

-- ?? SAFE STAGE AGGREGATION
LoadingBase AS
(
    SELECT
        l.ProductionPlanId,
        l.AllocatedStage,

        SUM(TRY_CAST(l.PlannedQty AS FLOAT)) AS ScheduledQty,
        SUM(TRY_CAST(l.ProducedQty AS FLOAT)) AS ProducedQty,

        MIN(l.ScheduleDate) AS FirstScheduleDateTime,
        MAX(l.ScheduleDate) AS LastScheduleDateTime
    FROM tbl_ProductionMachineLoading l
    GROUP BY
        l.ProductionPlanId,
        l.AllocatedStage
),

-- ?? SAP STAGE COMPLETION FLAG
StageStatus AS
(
    SELECT *,
        CASE 
            WHEN ISNULL(ProducedQty,0) >= ISNULL(ScheduledQty,0)
                THEN 1
            ELSE 0
        END AS IsCompleted
    FROM LoadingBase
),

DailyLoad AS
(
    SELECT
        CONVERT(DATE, ScheduleDate) AS ScheduleDay,
        SUM(TRY_CAST(PlannedQty AS FLOAT)) AS UsedQty,
        COUNT(*) AS JobCount
    FROM tbl_ProductionMachineLoading
    GROUP BY CONVERT(DATE, ScheduleDate)
),

Capacity AS
(
    SELECT 
        SUM(
            TRY_CAST(MachinePerHRQty AS FLOAT) *
            TRY_CAST(MachineRunningHR AS FLOAT)
        ) AS DailyCapacity
    FROM tbl_MachineMaster
    WHERE IsActive = 1 AND IsDeleted = 0
),

AvailableDays AS
(
    SELECT
        C.WorkDay,
        ISNULL(D.UsedQty,0) AS UsedQty,
        CAP.DailyCapacity,
        (CAP.DailyCapacity - ISNULL(D.UsedQty,0)) AS AvailableQty
    FROM
    (
        SELECT TOP 60
            DATEADD(DAY,
                ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) - 1,
                CAST(GETDATE() AS DATE)
            ) AS WorkDay
        FROM master..spt_values
    ) C
    CROSS JOIN Capacity CAP
    LEFT JOIN DailyLoad D
        ON D.ScheduleDay = C.WorkDay
),

NextAvailable AS
(
    SELECT TOP 1 WorkDay
    FROM AvailableDays
    WHERE AvailableQty > 0
      AND WorkDay >= DATEADD(DAY, 1, CAST(GETDATE() AS DATE))
    ORDER BY WorkDay ASC
)

SELECT
    N.ID,
    N.WorkOrderNo,
    N.Size,

    -- ?? FIX: SAFE NUMERIC CONVERSION
    CAST(TRY_CAST(N.TotalQty AS FLOAT) AS INT) AS TotalQty,

    S.AllocatedStage AS Stage,

    CAST(ISNULL(S.ScheduledQty,0) AS INT) AS ScheduledQty,

    -- ?? SAP DEPENDENCY CONTROLLED PRODUCED QTY
    CAST(
        CASE
            WHEN S.AllocatedStage = 'Stage 1'
                THEN ISNULL(S.ProducedQty,0)

            WHEN S.AllocatedStage = 'Stage 2'
                 AND EXISTS (
                    SELECT 1
                    FROM StageStatus S1
                    WHERE S1.ProductionPlanId = S.ProductionPlanId
                      AND S1.AllocatedStage = 'Stage 1'
                      AND S1.IsCompleted = 1
                 )
                THEN ISNULL(S.ProducedQty,0)

            ELSE 0
        END
    AS INT) AS ProducedQty,

    -- ?? FIX: SAFE CALCULATION (NO NVARCHAR ERROR)
    CAST(
        TRY_CAST(N.TotalQty AS FLOAT)
        - ISNULL(SUM(S.ScheduledQty) OVER (PARTITION BY N.ID),0)
    AS INT) AS PendingQty,

    CONVERT(VARCHAR(19), S.FirstScheduleDateTime, 120) AS FirstScheduleDateTime,
    CONVERT(VARCHAR(19), S.LastScheduleDateTime, 120) AS LastScheduleDateTime,

    DL.ScheduleDay,
    DL.UsedQty,
    DL.JobCount,

    -- ?? AUTO SCHEDULE DATE
    CASE
        WHEN ISNULL(SUM(S.ScheduledQty) OVER (PARTITION BY N.ID),0) = 0
            THEN CONVERT(VARCHAR(19), NA.WorkDay, 120)

        WHEN ISNULL(SUM(S.ScheduledQty) OVER (PARTITION BY N.ID),0)
             < TRY_CAST(N.TotalQty AS FLOAT)
            THEN CONVERT(VARCHAR(19), NA.WorkDay, 120)

        ELSE CONVERT(VARCHAR(19), S.LastScheduleDateTime, 120)
    END AS AutoScheduleDate,

    -- ?? PRODUCTION STATUS
    CASE
        WHEN ISNULL(SUM(S.ScheduledQty) OVER (PARTITION BY N.ID),0) = 0
            THEN 'Not Scheduled'

        WHEN ISNULL(SUM(S.ScheduledQty) OVER (PARTITION BY N.ID),0)
             < TRY_CAST(N.TotalQty AS FLOAT)
            THEN 'Partially Scheduled'

        ELSE 'Fully Scheduled'
    END AS ProductionStatus,

    -- ?? SCHEDULE STATUS
    CASE
        WHEN S.LastScheduleDateTime IS NULL THEN NULL
        WHEN CONVERT(DATE, S.LastScheduleDateTime) = CONVERT(DATE, GETDATE())
            THEN 'Scheduled Today'
        ELSE 'Scheduled'
    END AS ScheduleStatus

FROM NUMBERED N
LEFT JOIN StageStatus S
    ON S.ProductionPlanId = N.ID

OUTER APPLY
(
    SELECT TOP 1 *
    FROM DailyLoad DL2
    ORDER BY DL2.ScheduleDay DESC
) DL

CROSS APPLY NextAvailable NA

WHERE @ShowRecords = 0
   OR N.RN <= @ShowRecords

ORDER BY N.ID DESC;

     END

-- IF @SP_Action = 'StartProduction_Stage2'
--BEGIN

--    DECLARE @CurrentStage NVARCHAR(50) = 'Stage 2';
--    DECLARE @WorkOrderIdd INT;
--    DECLARE @RemainingQtyy FLOAT;
--    DECLARE @MachineIdLocall INT;
--    DECLARE @AvailableQtyy FLOAT;
--    DECLARE @AllocateQtyy FLOAT;

--    ---------------------------------------------------
--    -- STEP 1: GET WORK ORDER
--    ---------------------------------------------------
--    SELECT 
--        @WorkOrderIdd = WorkOrderId,
--        @RemainingQtyy = TotalQty
--    FROM tbl_ProductionInatial
--    WHERE ID = @Id;

--    ---------------------------------------------------
--    -- STEP 2: MACHINE CURSOR (STAGE 2 CAPACITY)
--    ---------------------------------------------------
--    DECLARE TransferCursor CURSOR FOR

--    SELECT 
--        M.ID,
--        (
--            (TRY_CAST(M.MachinePerHRQty AS FLOAT) *
--             TRY_CAST(M.MachineRunningHR AS FLOAT))
--            - ISNULL(SUM(TRY_CAST(PM.PlannedQty AS FLOAT)),0)
--        ) AS AvailableQty
--    FROM tbl_MachineMaster M
--    LEFT JOIN tbl_ProductionMachineLoading PM
--        ON M.ID = PM.MachineId
--        AND PM.Status = 'In-Process'
--        AND PM.AllocatedStage = @CurrentStage
--    WHERE M.IsDeleted = 0
--      AND M.IsActive = 1
--      AND M.AllocatedStage = @CurrentStage
--    GROUP BY
--        M.ID,
--        M.MachinePerHRQty,
--        M.MachineRunningHR
--    HAVING
--        (
--            (TRY_CAST(M.MachinePerHRQty AS FLOAT) *
--             TRY_CAST(M.MachineRunningHR AS FLOAT))
--            - ISNULL(SUM(TRY_CAST(PM.PlannedQty AS FLOAT)),0)
--        ) > 0
--    ORDER BY AvailableQty DESC;

--    OPEN TransferCursor;

--    FETCH NEXT FROM TransferCursor
--    INTO @MachineIdLocall, @AvailableQtyy;

--    WHILE @@FETCH_STATUS = 0 AND @RemainingQtyy > 0
--    BEGIN

--        SET @AllocateQtyy =
--            CASE 
--                WHEN @RemainingQtyy >= @AvailableQtyy THEN @AvailableQtyy
--                ELSE @RemainingQtyy
--            END;

--        ---------------------------------------------------
--        -- STEP 3: DEDUCT FROM STAGE 1 PROPERLY (FIFO SAFE)
--        ---------------------------------------------------
--        ;WITH Stage1 AS
--        (
--            SELECT TOP 1 Id, PlannedQty
--            FROM tbl_ProductionMachineLoading
--            WHERE ProductionPlanId = @Id
--              AND AllocatedStage = 'Stage 1'
--              AND PlannedQty > 0
--            ORDER BY Id
--        )
--        UPDATE Stage1
--        SET PlannedQty = PlannedQty - @AllocateQtyy;

--        ---------------------------------------------------
--        -- STEP 4: INSERT INTO STAGE 2
--        ---------------------------------------------------
--        INSERT INTO tbl_ProductionMachineLoading
--        (
--            ProductionPlanId,
--            WorkOrderId,
--            MachineId,
--            AllocatedStage,
--            ScheduleDate,
--            PlannedQty,
--            ProducedQty,
--            Status
--        )
--        VALUES
--        (
--            @Id,
--            @WorkOrderIdd,
--            @MachineIdLocall,
--            @CurrentStage,
--            GETDATE(),
--            @AllocateQtyy,
--            0,
--            'In-Process'
--        );

--        SET @RemainingQtyy = @RemainingQtyy - @AllocateQtyy;

--        FETCH NEXT FROM TransferCursor
--        INTO @MachineIdLocall, @AvailableQtyy;
--    END

--    CLOSE TransferCursor;
--    DEALLOCATE TransferCursor;

--    ---------------------------------------------------
--    -- FINAL OUTPUT
--    ---------------------------------------------------
--    SELECT 
--        @Id AS ProductionPlanId,
--        @RemainingQtyy AS RemainingQty,
--        @CurrentStage AS Stage,
--        'Stage 2 allocation completed correctly' AS Message;

--END


IF @SP_Action = 'StartProduction_Stage2'
BEGIN

    DECLARE @CurrentStage NVARCHAR(50) = 'Stage 2';

    DECLARE @MachineIdLocall INT;
    DECLARE @AvailableQtyy FLOAT;
    DECLARE @AllocateQtyy FLOAT;

    DECLARE @ProdId INT;
   

    ---------------------------------------------------
    -- STEP 1: WORK ORDER FIFO QUEUE
    ---------------------------------------------------
    DECLARE @WorkQueue TABLE
    (
        RowNum INT IDENTITY(1,1),
        ProductionId INT,
        WorkOrderId INT,
        RemainingQty FLOAT
    );

INSERT INTO @WorkQueue (ProductionId, WorkOrderId, RemainingQty)
SELECT
    PI.ID,
    PI.WorkOrderId,
    ISNULL(
    (
        SELECT SUM(PlannedQty)
        FROM tbl_ProductionMachineLoading
        WHERE ProductionPlanId = PI.ID
          AND AllocatedStage = 'Stage 1'
          AND PlannedQty > 0
    ),0)
FROM tbl_ProductionInatial PI
WHERE PI.ID = @Id;

    ---------------------------------------------------
    -- STEP 2: MACHINE CURSOR
    ---------------------------------------------------
    DECLARE TransferCursor CURSOR FOR

    SELECT 
        M.ID,
        (
            (TRY_CAST(M.MachinePerHRQty AS FLOAT) *
             TRY_CAST(M.MachineRunningHR AS FLOAT))
            - ISNULL(SUM(TRY_CAST(PM.PlannedQty AS FLOAT)),0)
        ) AS AvailableQty
    FROM tbl_MachineMaster M
    LEFT JOIN tbl_ProductionMachineLoading PM
        ON M.ID = PM.MachineId
        AND PM.Status = 'In-Process'
        AND PM.AllocatedStage = @CurrentStage
    WHERE M.IsDeleted = 0
      AND M.IsActive = 1
      AND M.AllocatedStage = @CurrentStage
    GROUP BY
        M.ID,
        M.MachinePerHRQty,
        M.MachineRunningHR
    HAVING
        (
            (TRY_CAST(M.MachinePerHRQty AS FLOAT) *
             TRY_CAST(M.MachineRunningHR AS FLOAT))
            - ISNULL(SUM(TRY_CAST(PM.PlannedQty AS FLOAT)),0)
        ) > 0
    ORDER BY M.ID;

    OPEN TransferCursor;

    FETCH NEXT FROM TransferCursor
    INTO @MachineIdLocall, @AvailableQtyy;

    ---------------------------------------------------
    -- STEP 3: LOOP WORK ORDERS
    ---------------------------------------------------
    DECLARE @i INT = 1;
    DECLARE @Max INT;

    SELECT @Max = COUNT(*) FROM @WorkQueue;

    WHILE @@FETCH_STATUS = 0 AND @i <= @Max
    BEGIN

        SELECT 
            @ProdId = ProductionId,
            @WorkOrderId = WorkOrderId,
            @RemainingQty = RemainingQty
        FROM @WorkQueue
        WHERE RowNum = @i;

        ---------------------------------------------------
        -- SKIP IF NO QTY
        ---------------------------------------------------
        IF @RemainingQty <= 0
        BEGIN
            SET @i = @i + 1;
            CONTINUE;
        END

        ---------------------------------------------------
        -- STEP 4: MACHINE ALLOCATION LOOP
        ---------------------------------------------------
        WHILE @RemainingQty > 0 AND @@FETCH_STATUS = 0
        BEGIN

            ---------------------------------------------------
            -- TAKE MIN OF MACHINE CAPACITY & REMAINING QTY
            ---------------------------------------------------
            SET @AllocateQtyy =
                CASE 
                    WHEN @RemainingQty >= @AvailableQtyy
                        THEN @AvailableQtyy
                    ELSE @RemainingQty
                END;

            ---------------------------------------------------
            -- DEDUCT FROM STAGE 1 FIFO
            ---------------------------------------------------
            ;WITH Stage1 AS
            (
                SELECT TOP 1 Id, PlannedQty
                FROM tbl_ProductionMachineLoading
                WHERE ProductionPlanId = @ProdId
                  AND AllocatedStage = 'Stage 1'
                  AND PlannedQty > 0
                ORDER BY Id
            )
            UPDATE Stage1
            SET PlannedQty = PlannedQty - @AllocateQtyy;

            ---------------------------------------------------
            -- INSERT STAGE 2 ALLOCATION
            ---------------------------------------------------
            INSERT INTO tbl_ProductionMachineLoading
            (
                ProductionPlanId,
                WorkOrderId,
                MachineId,
                AllocatedStage,
                ScheduleDate,
                PlannedQty,
                ProducedQty,
                Status
            )
            VALUES
            (
                @ProdId,
                @WorkOrderId,
                @MachineIdLocall,
                @CurrentStage,
                GETDATE(),
                @AllocateQtyy,
                0,
                'In-Process'
            );

            ---------------------------------------------------
            -- UPDATE REMAINING WORK ORDER QTY
            ---------------------------------------------------
            SET @RemainingQty = @RemainingQty - @AllocateQtyy;

            ---------------------------------------------------
            -- MOVE TO NEXT MACHINE IF CURRENT IS FULL
            ---------------------------------------------------
            IF @AllocateQtyy = @AvailableQtyy
            BEGIN
                FETCH NEXT FROM TransferCursor
                INTO @MachineIdLocall, @AvailableQtyy;

                IF @@FETCH_STATUS <> 0
                    BREAK;
            END

        END

        SET @i = @i + 1;

    END

    CLOSE TransferCursor;
    DEALLOCATE TransferCursor;

    ---------------------------------------------------
    -- FINAL OUTPUT
    ---------------------------------------------------
    SELECT 
        @Id AS ProductionPlanId,
        'Stage 2 allocation completed successfully with proper machine chaining' AS Message;

END




END


-- Script for SP_AuthorizationMaster
GO
CREATE PROCEDURE dbo.SP_AuthorizationMaster
 @ShowRecords int =0
,@Id int =0
,@MenuName nvarchar(200) = null
,@PageName nvarchar(200) = null
,@UserID int = 0
,@UserName nvarchar(200)= null
,@MenuId int = 0
,@PageAccess bit = 0
,@PagesButtonAccess bit = 0
,@ActionBy nvarchar(200) = null
,@SP_Action nvarchar(100) =null
AS
BEGIN
  IF @SP_Action='GetAuthList'
   BEGIN
     SELECT * FROM tbl_AuthPages
   END

  IF @SP_Action='CreateAuth'
   BEGIN
     INSERT INTO tbl_AuthPages(MenuName,PageName)
     VALUES(@MenuName,@PageName)
   END

  IF @SP_Action='AuthorizationInsert'
   BEGIN
     INSERT INTO tbl_UserRoleAuthorization(UserID,UserName,MenuId,MenuName,
			PageName,PageAccess,PagesButtonAccess,CreatedBy,CreatedOn)
     VALUES(@UserID,@UserName,@MenuId,@MenuName,
			@PageName,@PageAccess,@PagesButtonAccess,@ActionBy,GETDATE())
   END

   IF @SP_Action='AuthorizationDelete'
   BEGIN
     DELETE FROM tbl_UserRoleAuthorization WHERE UserID = @UserID
   END

END



-- Script for SP_UserMaster
GO
CREATE PROCEDURE [dbo].[SP_UserMaster] 
     @ShowRecords INT = 0
	,@Id int =0
	,@UserCode NVARCHAR(100) = NULL
	,@FullName NVARCHAR(500) = NULL
	,@MobileNo NVARCHAR(100) = NULL
	,@EmialId NVARCHAR(100) = NULL
	,@Password NVARCHAR(100) = NULL
	,@UserRole NVARCHAR(100) = NULL
	,@IsActive NVARCHAR(100) = NULL
	,@IsDeleted NVARCHAR(100) = NULL
	,@ActionBy NVARCHAR(100) = NULL
	,@SP_Action NVARCHAR(100) = NULL
AS
BEGIN
	IF (@SP_Action = 'UserList')
	BEGIN
		WITH UserMaster
		AS (
			SELECT UM.ID AS ID,UserCode,FullName,EmailId,CASE WHEN Departments = 'In-House' THEN 'Acryshade - '+Roles 
			WHEN Departments = 'Packaging_Dispatch' THEN 'Packaging/Dispatch - '+ Roles
			ELSE Departments+' - '+Roles END AS  UserRole,IsActivate,LoginPass
			FROM tbl_UserMaster UM
			INNER JOIN tbl_RoleMaster RM ON RM.Roles = UM.UserRole 
			WHERE UM.IsDeleted = 0 AND RM.Departments != 'Outsourcing'
			)
			,NUMBERED
		AS (
			SELECT *
				,ROW_NUMBER() OVER (
					ORDER BY Id DESC
					) AS RN
			FROM UserMaster
			)
		SELECT *
		FROM NUMBERED
		WHERE @ShowRecords = 0
			OR RN <= @ShowRecords 
			AND (
				 @FullName = '' 
					OR FullName LIKE '%' + @FullName + '%'
					OR UserCode LIKE '%' + @FullName + '%'
					OR EmailId LIKE '%' + @FullName + '%'
					OR UserRole LIKE '%' + @FullName + '%'
					OR LoginPass LIKE '%' + @FullName + '%'

					)
		ORDER BY ID DESC
	END

	IF (@SP_Action = 'UserById')
	BEGIN
		SELECT * FROM tbl_UserMaster WHERE ID = @Id
	END

	IF (@SP_Action = 'UpdateData')
	BEGIN
		UPDATE tbl_UserMaster
		SET FullName = @FullName
			,MobileNo = @MobileNo
			,EmailId = @EmialId
			,LoginPass = @Password
			,UserRole=@UserRole
			,UpdatedBy = @ActionBy
			,UpdatedOn = GETDATE()
		WHERE ID = @Id
	END

	IF (@SP_Action = 'InsertData')
	BEGIN
		INSERT INTO tbl_UserMaster (
			UserCode
			,FullName
			,MobileNo
			,EmailId
			,LoginPass
			,UserRole
			,CreatedOn
			,CreatedBy
			,IsActivate
			,IsDeleted
			)
		VALUES (
			dbo.FN_GenerateUserCode()
			,@FullName
			,@MobileNo
			,@EmialId
			,@Password
			,@UserRole
			,GETDATE()
			,@ActionBy
			,1
			,0
			)
	END

	IF (@SP_Action = 'DeleteData')
	BEGIN
		UPDATE tbl_UserMaster
		SET IsDeleted = 1
		WHERE ID = @Id
	END

	IF(@SP_Action = 'VerifyRole')
	BEGIN
	  SELECT * FROM tbl_RoleMaster WHERE UPPER(Roles) = @UserRole AND IsDeleted = 0
	END

	IF(@SP_Action = 'RoleList')
	BEGIN
	  SELECT * FROM tbl_RoleMaster WHERE IsDeleted = 0 ORDER BY ID DESC
	END

	IF(@SP_Action = 'RoleListForUser')
	BEGIN
	  SELECT Roles,
		CASE WHEN Departments = 'In-House' THEN 'Acryshade - '+Roles 
		WHEN Departments = 'Packaging_Dispatch' THEN 'Packaging/Dispatch - '+ Roles
		ELSE Departments+' - '+Roles END AS DepRoles
		FROM tbl_RoleMaster WHERE IsDeleted = 0 AND Departments !='Outsourcing' ORDER BY ID DESC
	END

	IF(@SP_Action = 'InsertRole')
	BEGIN
	  INSERT INTO tbl_RoleMaster(Roles,Departments,IsDeleted) VALUES(@UserRole,@FullName,0)
	END

	IF(@SP_Action = 'DeleteRole')
	BEGIN
	 UPDATE tbl_RoleMaster SET IsDeleted = 1 WHERE ID =@Id
	END
END

-- Script for SP_CompanyMaster
GO
CREATE PROCEDURE [dbo].[SP_CompanyMaster]
 @ShowRecords int = 0
,@Id int =0 
,@HeaderId nvarchar(100) =null 
,@CompanyCode nvarchar(100) = null
,@CompanyName nvarchar(500) = null
,@OwnerName nvarchar(500) = null
,@CompanyOrigin nvarchar(100) = null
,@CompanyEmialId nvarchar(100) = null
,@CompanyPanCard nvarchar(100) = null
,@PaymentTerms nvarchar(500) = null
,@UDYAMNo nvarchar(100) = null
,@CINNo nvarchar(100) = null
,@WebsiteLink nvarchar(500) = null
,@ActionBy nvarchar(500) = null
,@BillAddress nvarchar(max) = null
,@BillArea nvarchar(max) = null
,@BillPinCode nvarchar(100) = null
,@BillCity nvarchar(200) = null
,@BillState nvarchar(200) = null
,@BillCountry nvarchar(200) = null
,@BillGSTNo nvarchar(200) = null
,@ShipAddress nvarchar(max) = null
,@ShipArea nvarchar(max) = null
,@ShipPinCode nvarchar(100) = null
,@ShipCity nvarchar(200) = null
,@ShipState nvarchar(200) = null
,@ShipCountry nvarchar(200) = null
,@ShipGSTNo nvarchar(200) = null
,@FName nvarchar(500) = null
,@MobileNo nvarchar(100) = null
,@EmialID nvarchar(100) = null
,@Department nvarchar(100) = null
,@Designation nvarchar(100) = null
,@SP_Action nvarchar(100) = null
,@Result int output
AS
BEGIN
        -- Company Main Table
  	  IF @SP_Action = 'MainCompanyList'
	   BEGIN
		 WITH CompanyMain
			AS (
			    SELECT * FROM tbl_CompanyMain WHERE IsDeleted = 0  
			       AND (
				        @CompanyName = '' 
						OR CompanyCode LIKE '%' + @CompanyName + '%'
						OR CompanyName LIKE '%' + @CompanyName + '%'
						OR OwnerName LIKE '%' + @CompanyName + '%'
						OR CompanyOrigin LIKE '%' + @CompanyName + '%'

				         
						--CompanyName LIKE CASE 
						--	WHEN @CompanyName != ''
						--		THEN @CompanyName
						--	ELSE '%%'
						--	END
			          )
			   ),NUMBERED
		AS (
			SELECT *
				,ROW_NUMBER() OVER (
					ORDER BY Id DESC
					) AS RN
			FROM CompanyMain
			)
		SELECT *
		FROM NUMBERED
		WHERE @ShowRecords = 0
			OR RN <= @ShowRecords
		ORDER BY ID DESC
		 SET @Result = 0
	   END

	  IF @SP_Action = 'MainCompanyListById'
	   BEGIN
		  SELECT * FROM tbl_CompanyMain WHERE ID = @Id
		  SET @Result = @Id
	   END
	 
	  IF @SP_Action = 'InsertMainCompany'
	   BEGIN
	     INSERT INTO tbl_CompanyMain (
		     CompanyCode
			,CompanyName
			,OwnerName
			,CompanyOrigin
			,CompanyEmialId
			,CompanyPanCard
			,PaymentTerms
			,UDYAMNo
			,CINNo
			,WebsiteLink
			,IsDeleted
			,CreatedBy
			,CreatedOn
			)
		VALUES (
		     [dbo].[FN_CompanyCode]() 
			,@CompanyName
            ,@OwnerName
			,@CompanyOrigin
			,@CompanyEmialId
			,@CompanyPanCard
			,@PaymentTerms
			,@UDYAMNo
			,@CINNo
			,@WebsiteLink
			,0
			,@ActionBy
			,GETDATE()
			)
        SET @Result = SCOPE_IDENTITY()
	   END

      IF @SP_Action = 'UpdateMainCompany'
	   BEGIN
	    UPDATE tbl_CompanyMain
		SET CompanyName =@CompanyName
			,OwnerName = @OwnerName
			,CompanyOrigin = @CompanyOrigin
			,CompanyEmialId = @CompanyEmialId
			,CompanyPanCard = @CompanyPanCard
			,PaymentTerms = @PaymentTerms
			,UDYAMNo= @UDYAMNo
			,CINNo = @CINNo
			,WebsiteLink = @WebsiteLink
			,UpdatedBy = @ActionBy
			,UpdatedOn = GETDATE()
		WHERE ID = @Id
		SET @Result = @Id
	   END

      IF (@SP_Action = 'DeleteMainCompany')
		BEGIN
			UPDATE tbl_CompanyMain
			SET IsDeleted = 1
			WHERE ID = @Id
			SET @Result = @Id
		END

     -- Company Details Table
      IF @SP_Action = 'CompDetailsListById'
	   BEGIN
	     SELECT * FROM tbl_CompanyDetails WHERE HeaderId =@Id
		 SET @Result = @Id
 	   END 
     
      IF @SP_Action = 'InsertCompDetails'
	   BEGIN
	     INSERT INTO tbl_CompanyDetails (
			 HeaderId
			,BillAddress
			,BillArea
			,BillPinCode
			,BillCity
			,BillState
			,BillCountry
			,BillGSTNo
			,ShipAddress
			,ShipArea
			,ShipPinCode
			,ShipCity
			,ShipState
			,ShipCountry
			,ShipGSTNo
			)
		VALUES (
			 @HeaderId
            ,@BillAddress
			,@BillArea
			,@BillPinCode
			,@BillCity
			,@BillState
			,@BillCountry
			,@BillGSTNo
			,@ShipAddress
			,@ShipArea
			,@ShipPinCode
			,@ShipCity
			,@ShipState
			,@ShipCountry
			,@ShipGSTNo
			)
			 SET @Result = SCOPE_IDENTITY()
	   END
      
	  IF (@SP_Action = 'DeleteCompDetails')
		BEGIN
			DELETE tbl_CompanyDetails WHERE HeaderId = @Id
			SET @Result = @Id
		END

       -- Company Contact Details Table
      IF @SP_Action = 'CompCntDetailsListById'
	   BEGIN
	     SELECT * FROM tbl_CompanyContactDtls WHERE HeaderId =@Id
		 SET @Result = @Id
 	   END 
     
      IF @SP_Action = 'InsertCompCntDetails'
	   BEGIN
	     INSERT INTO tbl_CompanyContactDtls (
			 HeaderId
			,FName
			,MobileNo
			,EmialID
			,Department
			,Designation
			)
		VALUES (
			 @HeaderId
            ,@FName
			,@MobileNo
			,@EmialID
			,@Department
			,@Designation
			)
			 SET @Result = SCOPE_IDENTITY()
	   END
      
	  IF (@SP_Action = 'DeleteCompCntDetails')
		BEGIN
			DELETE tbl_CompanyContactDtls WHERE HeaderId = @Id
			SET @Result = @Id
		END
END


-- Script for SP_AssignedMachines
GO
CREATE PROCEDURE [dbo].[SP_AssignedMachines]
 @ShowRecords int =0
,@Id int =0
,@MachineID nvarchar(100)= null
,@OperatorID nvarchar(100)= null
,@FromDate date= null
,@ToDate date= null
,@FromTime time(0)= null
,@ToTime time(0)= null
,@ActionBy nvarchar(100)= null
,@SP_Action nvarchar(100)= null
AS
BEGIN
    IF @SP_Action ='GetList'
     BEGIN
        SELECT AM.ID AS ID,(MM.AllocatedStage+'- '+MM.MachineName )AS MachineID, UM.FullName AS OperatorID,
        CONVERT(nvarchar(10),AM.FromDate,105) AS FromDate,CONVERT(nvarchar(10),AM.ToDate,105) AS ToDate,
        LTRIM(RIGHT(CONVERT(varchar, CAST(FromTime AS datetime), 100), 7))  AS FromTime, 
         LTRIM(RIGHT(CONVERT(varchar, CAST(ToTime AS datetime), 100), 7)) AS ToTime
        FROM tbl_AssignedMachines AM
        INNER JOIN tbl_MachineMaster MM ON MM.ID = AM.MachineID
        INNER JOIN tbl_UserMaster UM ON UM.ID = AM.OperatorID 
        WHERE AM.IsDeleted = 0
        ORDER BY AM.ID DESC
     END

    IF @SP_Action ='InsertMachine'
     BEGIN
       INSERT INTO tbl_AssignedMachines(MachineID,OperatorID,FromDate,ToDate,FromTime,ToTime,CreatedBy,CreatedOn,IsDeleted)
       VALUES (@MachineID,@OperatorID,@FromDate,@ToDate,@FromTime,@ToTime,@ActionBy,GETDATE(),0)
     END

    IF @SP_Action ='DeleteAssiMachine'
     BEGIN
       UPDATE tbl_AssignedMachines SET IsDeleted = 1,DeletedBy = @ActionBy,DeletedOn=GETDATE() WHERE ID = @Id
     END

    IF @SP_Action = 'CheckMCAvailability'
     BEGIN
       SELECT ID,CONVERT(nvarchar(10),ToDate,105) AS ToDate
       ,LTRIM(RIGHT(CONVERT(varchar, CAST(ToTime AS datetime), 100), 7)) AS ToTime
       FROM tbl_AssignedMachines WHERE IsDeleted = 0 AND MachineID = @MachineID AND CAST(ToDate AS datetime) + CAST(ToTime AS datetime) > GETDATE()
     END

    IF @SP_Action = 'CheckOPAvailability'
     BEGIN
       SELECT ID,CONVERT(nvarchar(10),ToDate,105) AS ToDate
       ,LTRIM(RIGHT(CONVERT(varchar, CAST(ToTime AS datetime), 100), 7)) AS ToTime
       FROM tbl_AssignedMachines WHERE OperatorID = @OperatorID AND CAST(ToDate AS datetime) + CAST(ToTime AS datetime) > GETDATE()
     END
END



					













-- Script for SP_DashboardDetails
GO

CREATE PROCEDURE [dbo].[SP_DashboardDetails] 
@SP_Action nvarchar(100) = NULL,
@FromDate NVARCHAR(100)= NULL,
@ToDate NVARCHAR(100)=NULL,
@Type NVARCHAR(100) = NULL
AS
BEGIN

    IF @SP_Action = 'CardsDetails'
     BEGIN
        SELECT
            (
                SELECT COUNT(*)
                FROM tbl_UserMaster
                WHERE UserRole = 'Dealer'
                      AND IsDeleted = 0
            ) AS DealersCount,
            (
                SELECT COUNT(*) FROM tbl_StageMaster WHERE IsDeleted = 0
            ) AS StageCount,
            (
                SELECT COUNT(*) FROM tbl_MachineMaster WHERE IsDeleted = 0
            ) AS MachineCount,
            (
                SELECT SUM(TRY_CAST(MachinePerHRQty AS FLOAT) * TRY_CAST(MachineRunningHR AS FLOAT)) AS StageDailyCapacity
                FROM tbl_MachineMaster
                WHERE IsActive = 1
                      AND IsDeleted = 0
            ) AS UnitCapacity;
    END

    IF @SP_Action = 'Dealers'
     BEGIN
        SELECT UserCode AS 'User Code',
               FullName AS 'Distributer Name',
               EmailId AS 'Email Id',
               LoginPass AS 'Password'
        FROM tbl_UserMaster
        WHERE UserRole = 'Dealer'
              AND IsDeleted = 0
    END

    IF @SP_Action = 'Stages'
     BEGIN
        SELECT SatgeName AS 'Stage Name',
               SatgeCapacity AS 'Stage Capacity',
               CapacityUnit AS 'Unit'
        FROM tbl_StageMaster
        WHERE IsDeleted = 0
    END

    IF @SP_Action = 'Machines'
     BEGIN
        SELECT AllocatedStage AS 'Stage Name',
               MachineName AS 'Machine Name',
               MachineRunningHR AS 'Running Hours',
               MachinePerHRQty AS 'Per Hour Capacity'
        FROM tbl_MachineMaster
        WHERE IsDeleted = 0
    END

    IF @SP_Action = 'Capacity'
     BEGIN
        SELECT AllocatedStage AS 'Stages',
               SUM(TRY_CAST(MachinePerHRQty AS FLOAT) * TRY_CAST(MachineRunningHR AS FLOAT)) AS 'Stage Capacity'
        FROM tbl_MachineMaster
        WHERE IsActive = 1
              AND IsDeleted = 0
        GROUP BY AllocatedStage;
    END

    IF @SP_Action = 'Currentmonthproductions'
     BEGIN
      SELECT ISNULL(SUM(TRY_CONVERT(INT, D.SqFeet)), 0) AS CurrentMonthProduction
        FROM tbl_MachineProductionHDR H
        INNER JOIN tbl_MachineProductionDTLS D
            ON H.ID = D.HeaderID
        WHERE   -- Date Range Filter
                            (
                                @FromDate IS NOT NULL 
                                AND @ToDate IS NOT NULL
                                --AND CAST(H.AssignedDate AS DATE) BETWEEN @FromDate AND @ToDate
                                AND H.AssignedDate >= DATEFROMPARTS(YEAR(@FromDate), MONTH(@FromDate), 1)
                                AND H.AssignedDate < DATEADD(MONTH, 1, DATEFROMPARTS(YEAR(@ToDate), MONTH(@ToDate), 1))
                            )

                            OR

                            -- All Records
                            (
                                @FromDate IS NULL
                                AND @ToDate IS NULL
                            )
    END

    IF @SP_Action ='Todaysproductionsstage1'
	 BEGIN
      WITH MachineData AS
            (
                SELECT 
                    M.ID,
                    M.MachineName,
                    CAST(H.AssignedDate AS DATE) AS AssignedDate,
                    ISNULL(TRY_CAST(L.AllocatedQty AS INT),0) AS AllocatedQty,
                    ISNULL(TRY_CAST(L.AllocatedSqFeet AS INT),0) AS AllocatedSqFt,
                    ISNULL(TRY_CAST(L.CompletedQty AS INT),0) AS CompletedQty,
                    ISNULL(TRY_CAST(L.CompletedSqFeet AS INT),0) AS CompletedSqFeet
                FROM tbl_MachineMaster M
                LEFT JOIN tbl_MachineProductionAllocation L
                    ON M.ID = L.MachineID
                LEFT JOIN tbl_MachineProductionDTLS D
                    ON D.ID = L.ProductDtlID
                LEFT JOIN tbl_MachineProductionHDR H
                    ON H.ID = D.HeaderID
                WHERE 
                    M.AllocatedStage = 'Stage 1'
                    AND M.IsDeleted = 0
            ),
            FilteredData AS
            (
                SELECT *
                FROM MachineData
                WHERE

                     -- Date Range Filter
                    (
                        @FromDate IS NOT NULL 
                        AND @ToDate IS NOT NULL
                        AND AssignedDate BETWEEN @FromDate AND @ToDate
                    )

                    OR

                    -- All Records
                    (
                        @FromDate IS NULL
                        AND @ToDate IS NULL
                    )
            ),
            Summary AS
            (
                SELECT
                    ID,
                    MachineName,
                    MIN(AssignedDate) AS AssignedDate,


                    SUM(AllocatedSqFt) AS AllocatedSqFt,

                    SUM(CompletedSqFeet) AS CompletedSqFeet,


                    SUM(AllocatedQty) AS AllocatedQty,

                    SUM(CompletedQty) AS CompletedQty,


                    CONCAT(
                        MachineName,
                        '<br/><i class="mc-back-color"><b>Sq.Ft</b> (',
                        SUM(CompletedSqFeet),
                        '/',
                        SUM(AllocatedSqFt),
                        ')&nbsp;&nbsp;',
                        '  <b>Qty</b> (',
                        SUM(CompletedQty),
                        '/',
                        SUM(AllocatedQty),
                        ')</i>'
                    ) AS DisplayText

                FROM FilteredData

                GROUP BY
                    ID,
                    MachineName
            )


            SELECT
                M.ID,
                M.MachineName,

                ISNULL(S.AssignedDate,NULL) AS AssignedDate,

                ISNULL(S.AllocatedSqFt,0) AS AllocatedSqFt,

                ISNULL(S.CompletedSqFeet,0) AS CompletedSqFeet,

                ISNULL(
                    S.DisplayText,
                    M.MachineName + ' (0/0)'
                ) AS DisplayText,

                SUM(ISNULL(S.AllocatedSqFt,0)) OVER() AS TotalAllocatedSqFt,
                SUM(ISNULL(S.CompletedSqFeet,0)) OVER() AS TotalCompletedSqFt,
                
                CAST(
                    CASE
                        WHEN SUM(ISNULL(S.AllocatedSqFt,0)) OVER() = 0 THEN 0
                        ELSE ROUND(
                            SUM(ISNULL(S.CompletedSqFeet,0)) OVER() * 100.0 /
                            SUM(ISNULL(S.AllocatedSqFt,0)) OVER(),2
                        )
                    END AS DECIMAL(10,2)
                ) AS ProgressPercentage


            FROM tbl_MachineMaster M

            LEFT JOIN Summary S
                ON M.ID = S.ID

            WHERE 
                M.AllocatedStage = 'Stage 1'
                AND M.IsDeleted = 0;
	 END

    IF @SP_Action ='Todaysproductionsstage2'
	 BEGIN
     WITH MachineData AS
        (
            SELECT 
                M.ID,
                M.MachineName,
                CAST(H.AssignedDate AS DATE) AS AssignedDate,
                ISNULL(TRY_CAST(L.AllocatedQty AS INT),0) AS AllocatedQty,
                ISNULL(TRY_CAST(L.AllocatedSqFeet AS INT),0) AS AllocatedSqFt,
                ISNULL(TRY_CAST(L.CompletedQty AS INT),0) AS CompletedQty,
                ISNULL(TRY_CAST(L.CompletedSqFeet AS INT),0) AS CompletedSqFeet
            FROM tbl_MachineMaster M
            LEFT JOIN tbl_MachineProductionAllocation L
                ON M.ID = L.MachineID
            LEFT JOIN tbl_MachineProductionDTLS D
                ON D.ID = L.ProductDtlID
            LEFT JOIN tbl_MachineProductionHDR H
                ON H.ID = D.HeaderID
            WHERE 
                M.AllocatedStage = 'Stage 2'
                AND M.IsDeleted = 0
        ),


        FilteredData AS
        (
            SELECT *
            FROM MachineData
            WHERE
                  -- Date Range Filter
                    (
                        @FromDate IS NOT NULL 
                        AND @ToDate IS NOT NULL
                        AND AssignedDate BETWEEN @FromDate AND @ToDate
                    )

                    OR

                    -- All Records
                    (
                        @FromDate IS NULL
                        AND @ToDate IS NULL
                    )
        ),


        Summary AS
        (
            SELECT
                ID,
                MachineName,
                MIN(AssignedDate) AS AssignedDate,

                    SUM(AllocatedSqFt) AS AllocatedSqFt,

                    SUM(CompletedSqFeet) AS CompletedSqFeet,


                    SUM(AllocatedQty) AS AllocatedQty,

                    SUM(CompletedQty) AS CompletedQty,


                    CONCAT(
                        MachineName,
                        '<br/><i class="mc-back-color"><b>Sq.Ft</b> (',
                        SUM(CompletedSqFeet),
                        '/',
                        SUM(AllocatedSqFt),
                        ')&nbsp;&nbsp; ',
                        ' <b>Qty</b> (',
                        SUM(CompletedQty),
                        '/',
                        SUM(AllocatedQty),
                        ')</i>'
                    ) AS DisplayText


            FROM FilteredData

            GROUP BY
                ID,
                MachineName
        )
        SELECT
            M.ID,
            M.MachineName,

            ISNULL(S.AssignedDate,NULL) AS AssignedDate,

            ISNULL(S.AllocatedSqFt,0) AS AllocatedSqFt,

            ISNULL(S.CompletedSqFeet,0) AS CompletedSqFeet,

            ISNULL(
                S.DisplayText,
                M.MachineName + ' (0/0)'
            ) AS DisplayText, 

            SUM(ISNULL(S.AllocatedSqFt,0)) OVER() AS TotalAllocatedSqFt,
            SUM(ISNULL(S.CompletedSqFeet,0)) OVER() AS TotalCompletedSqFt,
                
            CAST(
                 CASE
                    WHEN SUM(ISNULL(S.AllocatedSqFt,0)) OVER() = 0 THEN 0
                    ELSE ROUND(
                            SUM(ISNULL(S.CompletedSqFeet,0)) OVER() * 100.0 /
                            SUM(ISNULL(S.AllocatedSqFt,0)) OVER(),2
                 )END AS DECIMAL(10,2)
             ) AS ProgressPercentage


        FROM tbl_MachineMaster M

        LEFT JOIN Summary S
            ON M.ID = S.ID

        WHERE 
            M.AllocatedStage = 'Stage 2'
            AND M.IsDeleted = 0;
	END

    IF @SP_Action ='TodaysPackaging'
     BEGIN
            SELECT

                SUM(ISNULL(TRY_CAST(L.CompletedSqFeet AS INT),0)) AS AllocatedSqFeet,


                CAST(
                    SUM(
                        (
                            ISNULL(TRY_CAST(L.CompletedSqFeet AS DECIMAL(18,2)),0)
                            /
                            NULLIF(ISNULL(TRY_CAST(L.CompletedQty AS DECIMAL(18,2)),0),0)
                        )
                        *
                        ISNULL(TRY_CAST(L.PackagingQty AS DECIMAL(18,2)),0)
                    )
                AS INT) AS PackagingSqFeet,


                CONCAT(

                    CAST(
                        SUM(
                            (
                                ISNULL(TRY_CAST(L.CompletedSqFeet AS DECIMAL(18,2)),0)
                                /
                                NULLIF(ISNULL(TRY_CAST(L.CompletedQty AS DECIMAL(18,2)),0),0)
                            )
                            *
                            ISNULL(TRY_CAST(L.PackagingQty AS DECIMAL(18,2)),0)
                        )
                    AS INT),

                    '/',

                    SUM(ISNULL(TRY_CAST(L.CompletedSqFeet AS INT),0))

                ) AS DisplayText,


                CONCAT(
                    CAST(
                        (
                            SUM(
                                (
                                    ISNULL(TRY_CAST(L.CompletedSqFeet AS DECIMAL(18,2)),0)
                                    /
                                    NULLIF(ISNULL(TRY_CAST(L.CompletedQty AS DECIMAL(18,2)),0),0)
                                )
                                *
                                ISNULL(TRY_CAST(L.PackagingQty AS DECIMAL(18,2)),0)
                            )
                            /
                            NULLIF(
                                SUM(ISNULL(TRY_CAST(L.CompletedSqFeet AS DECIMAL(18,2)),0)),
                                0
                            )
                        ) * 100
                    AS DECIMAL(5,2)),
                    '%'
                ) AS PackagingPercentage


            FROM tbl_MachineProductionAllocation L

            LEFT JOIN tbl_MachineProductionDTLS D
                ON D.ID = L.ProductDtlID

            LEFT JOIN tbl_MachineProductionHDR H
                ON H.ID = D.HeaderID


            WHERE
            L.StageName = 'Stage 2' AND
             -- Date Range Filter
               (
                        @FromDate IS NOT NULL 
                        AND @ToDate IS NOT NULL
                        AND AssignedDate BETWEEN @FromDate AND @ToDate
                    )

                    OR

                    -- All Records
                    (
                        @FromDate IS NULL
                        AND @ToDate IS NULL
                    );
        END

    IF @SP_Action ='GetBreakdown'
     BEGIN
        WITH BreakDown AS
            (
                SELECT
                    MachineID,
                    BDStatus,
                    BDDate,
                    BDReason,
                    LEAD(BDDate) OVER
                    (
                        PARTITION BY MachineID 
                        ORDER BY BDDate
                    ) AS EndTime
                FROM tbl_MachineBreakDown
                WHERE 
                  -- Date Range Filter
                            (
                                @FromDate IS NOT NULL 
                                AND @ToDate IS NOT NULL
                                AND CAST(BDDate AS DATE) BETWEEN @FromDate AND @ToDate
                            )

                            OR

                            -- All Records
                            (
                                @FromDate IS NULL
                                AND @ToDate IS NULL
                            )     
            ), CurrentStatus AS
            (
                        SELECT
                            MachineID,
                            BDStatus,
                            BDReason,
                            ROW_NUMBER() OVER
                            (
                                PARTITION BY MachineID
                                ORDER BY BDDate DESC
                            ) AS RN
                        FROM tbl_MachineBreakDown
             )
            SELECT
                MM.ID AS MachineID,
                CONCAT(CASE 
                        WHEN MM.AllocatedStage = 'Stage 1'
                        THEN '<b>S1</b>'
                        ELSE '<b>S2</b>'
                        END,'-',MM.MachineName) AS MachineName,

                ISNULL(SUM(
                    CASE 
                        WHEN BD.BDStatus = 0 
                        THEN DATEDIFF(SECOND, BD.BDDate, BD.EndTime)
                        ELSE 0
                    END
                ),0) AS TotalDownSeconds,

              '<small class="badge bg-' +
                   CASE
                       WHEN CS.BDStatus = 1 THEN 'success'
                       WHEN CS.BDStatus = 0 THEN 'danger reason-badge'   -- extra class only for clickable ones
                       ELSE 'success'
                   END +
                   '" style="' + CASE WHEN CS.BDStatus = 0 THEN 'cursor:pointer;' ELSE '' END + '"' +
                   '" data-reason="' +
                   CASE
                       WHEN CS.BDStatus = 0 THEN REPLACE(ISNULL(CS.BDReason, ''), '"', '&quot;')
                       ELSE ''
                   END +
                   '">' +
                   CASE
                       WHEN MM.AllocatedStage = 'Stage 1' THEN 'S1'
                       WHEN MM.AllocatedStage = 'Stage 2' THEN 'S2'
                       ELSE 'S'
                   END +
                   ' M' +  
                   SUBSTRING(
                       MM.MachineName,
                       CHARINDEX(' ', MM.MachineName) + 1,
                       CHARINDEX(' (', MM.MachineName) - CHARINDEX(' ', MM.MachineName) - 1
                   ) +
                 '</small>' AS MachineStatus,

                RIGHT('0' + CAST(
                    ISNULL(SUM(
                        CASE 
                            WHEN BD.BDStatus = 0 
                            THEN DATEDIFF(SECOND, BD.BDDate, BD.EndTime)
                            ELSE 0
                        END
                    ),0) / 3600 AS VARCHAR(10)),2)
                + ':' +
                RIGHT('0' + CAST(
                    (
                        ISNULL(SUM(
                            CASE 
                                WHEN BD.BDStatus = 0 
                                THEN DATEDIFF(SECOND, BD.BDDate, BD.EndTime)
                                ELSE 0
                            END
                        ),0) % 3600
                    ) / 60 AS VARCHAR(10)),2)
                + ':' +
                RIGHT('0' + CAST(
                    ISNULL(SUM(
                        CASE 
                            WHEN BD.BDStatus = 0 
                            THEN DATEDIFF(SECOND, BD.BDDate, BD.EndTime)
                            ELSE 0
                        END
                    ),0) % 60 AS VARCHAR(10)),2)
                AS TotalDownTime

            FROM tbl_MachineMaster MM

            LEFT JOIN BreakDown BD
                ON MM.ID = BD.MachineID

            LEFT JOIN CurrentStatus CS
                ON MM.ID = CS.MachineID
               AND CS.RN = 1

            WHERE 
                MM.IsDeleted = 0

            GROUP BY
                MM.ID,
                MM.MachineName,
                MM.AllocatedStage,
                CS.BDStatus,
                CS.BDReason

            ORDER BY
                MM.ID;
     END

    IF @SP_Action ='Dispatchedcount'
     BEGIN
        SELECT COUNT(*) AS DispatchedCount
        FROM tbl_WorkOrderHdr
         WHERE IsDispatched = 1 
         AND 
               -- Date Range Filter
                    (
                        @FromDate IS NOT NULL 
                        AND @ToDate IS NOT NULL
                        AND CAST(DispatchedDate as date) BETWEEN @FromDate AND @ToDate
                    )

                    OR

                    -- All Records
                    (
                        @FromDate IS NULL
                        AND @ToDate IS NULL
                    );
     END

    IF @SP_Action ='Returncount'
     BEGIN
      WITH ReturnData AS
        (
            SELECT
                DTLS.Size,
                COUNT(*) AS ReturnCount,

                SUM(CASE 
                        WHEN LOGS.Mistaken = 'True' 
                        THEN 1 
                        ELSE 0 
                    END) AS MistakenCount,

                SUM(CASE 
                        WHEN LOGS.Faulty = 'True' 
                        THEN 1 
                        ELSE 0 
                    END) AS FaultyCount

            FROM tbl_MachineReturnQtyLogs AS LOGS

            INNER JOIN tbl_MachineProductionAllocation AS MP 
                ON MP.ID = LOGS.DetailsID

            INNER JOIN tbl_MachineProductionDTLS AS DTLS  
                ON DTLS.ID = MP.ProductDtlID

            WHERE

            -- Date Range Filter
                    (
                        @FromDate IS NOT NULL 
                        AND @ToDate IS NOT NULL
                        AND CAST(LOGS.CreatedDate as date) BETWEEN @FromDate AND @ToDate
                    )

                    OR

                    -- All Records
                    (
                        @FromDate IS NULL
                        AND @ToDate IS NULL
                    )

            GROUP BY DTLS.Size
        )

        SELECT
            ISNULL(Size,'No Size') AS Size,
            ISNULL(ReturnCount,0) AS ReturnCount,
            ISNULL(MistakenCount,0) AS MistakenCount,
            ISNULL(FaultyCount,0) AS FaultyCount
        FROM ReturnData

        UNION ALL

        SELECT
            'No Data' AS Size,
            0 AS ReturnCount,
            0 AS MistakenCount,
            0 AS FaultyCount
        WHERE NOT EXISTS
        (
            SELECT 1 FROM ReturnData
        );
     END

    IF @SP_Action = 'TodaysProductivity'
     BEGIN
      SELECT
        CONCAT(
            UM.FullName,' - ',
            '&nbsp;<b>Sq.Ft</b> (',
            CAST(SUM(CASE WHEN H.ID IS NOT NULL
                          THEN ISNULL(TRY_CAST(L.CompletedSqFeet AS INT),0)
                          ELSE 0 END) AS VARCHAR(20)),
            '/',
            CAST(SUM(CASE WHEN H.ID IS NOT NULL
                          THEN ISNULL(TRY_CAST(L.AllocatedSqFeet AS INT),0)
                          ELSE 0 END) AS VARCHAR(20)),
            ')&nbsp;&nbsp;<b>Qty</b> (',
            CAST(SUM(CASE WHEN H.ID IS NOT NULL
                          THEN ISNULL(TRY_CAST(L.CompletedQty AS INT),0)
                          ELSE 0 END) AS VARCHAR(20)),
            '/',
            CAST(SUM(CASE WHEN H.ID IS NOT NULL
                          THEN ISNULL(TRY_CAST(L.AllocatedQty AS INT),0)
                          ELSE 0 END) AS VARCHAR(20)),
            ')'
        ) AS DisplayText,

        UM.ID AS OperatorID,

        SUM(CASE WHEN H.ID IS NOT NULL
                 THEN ISNULL(TRY_CAST(L.AllocatedSqFeet AS INT),0)
                 ELSE 0 END) AS AllocatedSqFeet,

        SUM(CASE WHEN H.ID IS NOT NULL
                 THEN ISNULL(TRY_CAST(L.CompletedSqFeet AS INT),0)
                 ELSE 0 END) AS CompletedSqFeet

        FROM tbl_AssignedMachines AM
        INNER JOIN tbl_UserMaster UM
            ON AM.OperatorID = UM.ID

        LEFT JOIN tbl_MachineProductionAllocation L
            ON AM.MachineID = L.MachineID

        LEFT JOIN tbl_MachineProductionDTLS D
            ON D.ID = L.ProductDtlID

        LEFT JOIN tbl_MachineProductionHDR H
            ON D.HeaderID = H.ID
           AND (
                (@FromDate IS NOT NULL
                 AND @ToDate IS NOT NULL
                 AND CAST(H.AssignedDate AS DATE) BETWEEN @FromDate AND @ToDate)
                OR
                (@FromDate IS NULL AND @ToDate IS NULL)
               )

        WHERE AM.IsDeleted = 0

        GROUP BY
            UM.ID,
            UM.FullName

        ORDER BY
            UM.ID;
    END

    IF(@SP_Action = 'OrderCount')
     BEGIN
      WITH Orders AS
        (
            SELECT
                CAST(CreatedOn AS DATE) AS CreatedDate,
                CAST(DeliveryDate AS DATE) AS DeliveryDate,
                ISNULL(IsAllCompleted,0) AS IsAllCompleted,
                ISNULL(IsAllCompleted,0) AS IsAllCompletedFlag
            FROM tbl_WorkOrderHdr
            WHERE ISNULL(IsDeleted,0) = 0
        )

       SELECT
            -- New Orders (today's records only, regardless of date filter)
            ISNULL(SUM(
                CASE
                    WHEN CreatedDate = CAST(GETDATE() AS DATE)
                    THEN 1
                    ELSE 0
                END
            ),0) AS NewOrders,
            -- Pending Orders (no date filter, just incomplete)
            ISNULL(SUM(
                CASE
                    WHEN DeliveryDate > @ToDate
                     AND IsAllCompleted = 0
                    THEN 1
                    ELSE 0
                END
            ),0) AS PendingOrders,
            -- Overdue Orders (unchanged, still filtered by @ToDate)
            ISNULL(SUM(
                CASE
                    WHEN DeliveryDate < @ToDate
                     AND IsAllCompleted = 0
                    THEN 1
                    ELSE 0
                END
            ),0) AS OverDueOrders
        FROM Orders;
    END

    IF (@SP_Action = 'GetOrderDetails')
     BEGIN
      WITH Orders AS
        (
         SELECT
            WH.Id,
            
            TallyRefNo,
            
            CAST(CreatedOn AS DATE) AS CreatedDate,
            
            CAST(DeliveryDate AS DATE) AS DeliveryDate,
            
            CASE 
             WHEN HoldStatus = 1 AND CancelStatus = 0
             THEN 'W/O On Hold' 
             WHEN CancelStatus = 1 AND HoldStatus = 0
             THEN 'W/O Canceled'
             ELSE 'N/A' 
            END AS IsHoldCancelFlag,
            
            CASE 
             WHEN SendForDesign = 1 AND isdesignapproved = 0
             THEN 'Send For Design Approval' 
             WHEN SendForDesign = 1 AND isdesignapproved = 1
             THEN 'Approved From Designer'
             ELSE 'Rejected From Designer' 
            END AS IsSendForDesignFlag,
            
            CASE 
             WHEN isdesignapproved = 0 AND SendForDesign = 0
             THEN 'Rejected' 
             WHEN SendForDesign = 1 AND isdesignapproved = 1
             THEN 'Approved'
             ELSE 'Pending' 
            END AS IsDesignFlag,
            
            CASE 
             WHEN isdesignapproved = 0 AND ScheduledDate IS NULL 
             THEN 'N/A'
             WHEN isdesignapproved = 1 AND ScheduledDate IS NULL 
             THEN 'Not Scheduled'
             ELSE 'Scheduled' 
            END AS IsScheduledDateFlag,
            
            ISNULL(CAST(ScheduledDate AS DATE), NULL) AS ScheduledDate,

            CASE 
             WHEN MH.S1Status IS NULL 
             THEN CASE WHEN (MH.S1Status IS NULL OR MH.S1Status ='') THEN 'N/A' ELSE MH.S1Status END
             WHEN MH.S1Status IS NOT NULL AND MH.S1Status != 'Completed'
             THEN MH.S1Status
             WHEN MH.S1Status = 'Completed' AND (MIN(MA.CompletedDate) IS NULL AND MAX(StageName) = 'Stage 1')
             THEN 'Work Started'
             ELSE MH.S1Status 
            END AS Stage1,

            CASE 
             WHEN MH.S1Status ='Machine Allocated' AND MH.S2Status IS NULL 
             THEN 'W/O Not Allocated'
             WHEN MH.S1Status !='Completed' AND (MH.S2Status IS NULL OR MH.S2Status != 'Completed')
             THEN 'Partially Active'
             WHEN MH.S1Status !='Completed' AND SUM(CAST(MA.CompletedQty as int)) != 0
             THEN 'Work Started'
             WHEN MH.S1Status ='Completed' AND (MH.S2Status IS NULL OR MH.S2Status != 'Completed')
             THEN 'Active'
             ELSE CASE WHEN (MH.S2Status IS NULL OR MH.S2Status ='') THEN 'N/A' ELSE MH.S2Status END
            END AS S2Status,

            CASE 
             WHEN SUM(CAST(ISNULL(MA.PackagingQty,0) as int)) = 0 AND MH.PackagingStatus IS NULL 
             THEN 'N/A'
             WHEN SUM(CAST(ISNULL(MA.PackagingQty,0) as int)) != 0 AND MH.PackagingStatus IS NULL 
             THEN 'Packing Started'
             WHEN SUM(CAST(ISNULL(MD.TotalQty,0) as int)) = SUM(CAST(ISNULL(MA.PackagingQty,0) as int)) AND MH.PackagingStatus IS NULL 
             THEN 'Not Packed'
             ELSE 'Packed' 
            END AS PackagingStatus,

            CASE 
             WHEN isproductioncompleted = 0 AND (MH.S2Status IS NULL OR MH.S2Status = '')
             THEN 'N/A'
             ELSE 'Production Completed' 
            END AS IsProductionFlag,

            CASE 
             WHEN MH.PackagingStatus IS NULL AND IsDispatched = 0
             THEN 'N/A'
             WHEN MH.PackagingStatus IS NOT NULL AND IsDispatched = 0
             THEN 'Ready To Dispatch' 
             ELSE 'Dispatched' 
            END AS IsDispatchedFlag,

            CASE 
             WHEN IsDispatched = 0 AND ISNULL(IsAllCompleted,0) = 0
             THEN 'N/A' 
             WHEN IsDispatched = 1 AND ISNULL(IsAllCompleted,0) = 0
             THEN 'N/A' 
             WHEN IsAllCompleted = 1 AND DeliveredDate IS NOT NULL
             THEN 'Delivered'
             ELSE 'Out For Delivery' 
            END AS IsAllCompletedFlag,

            ISNULL(IsAllCompleted,0) AS IsAllCompleted,

            DeliveredDate

        FROM tbl_WorkOrderHdr WH
        LEFT JOIN tbl_MachineProductionHDR MH
        ON WH.ID = MH.WorkOrderID
        LEFT JOIN tbl_MachineProductionDTLS MD
        ON MH.ID = MD.HeaderID
        LEFT JOIN tbl_MachineProductionAllocation MA
        ON MD.ID = MA.ProductDtlID
        WHERE ISNULL(IsDeleted, 0) = 0
        GROUP BY WH.Id,TallyRefNo,CreatedOn,DeliveryDate,HoldStatus,CancelStatus
        ,SendForDesign,isdesignapproved,ScheduledDate,MH.S1Status,MH.S2Status
        ,MH.PackagingStatus,isproductioncompleted,IsDispatched,IsAllCompleted,DeliveredDate
        )
        SELECT
            TallyRefNo AS 'W/O No.',
            CONVERT(NVARCHAR(10),CreatedDate,105) AS 'W/O Date',
            CONVERT(NVARCHAR(10),DeliveryDate,105) AS 'Estimated Delivery Date',
            ISHoldCancelFlag AS 'Hold/Cancel Status',
            IsSendForDesignFlag AS 'W/O Status',
            IsDesignFlag AS 'Designer Status',
            IsScheduledDateFlag AS 'Scheduled Status',
            CONVERT(NVARCHAR(10),ScheduledDate,105) AS 'Scheduled Date',
            Stage1 AS 'Stage 1',
            S2Status AS 'Stage 2',
            IsProductionFlag AS 'Production Status',
            PackagingStatus AS 'Packaging Status',
            IsDispatchedFlag AS 'Dispatch Status',
            IsAllCompletedFlag AS 'Delivery Status'
        FROM Orders
        WHERE
           (
               @Type = 'New Orders'
               AND CreatedDate = CAST(GETDATE() AS DATE)
           )
           OR
           (
               @Type = 'Pending Orders'
               AND IsAllCompleted = 0
           )
           OR
           (
               @Type = 'Over Due Orders'
               AND DeliveryDate < @ToDate
               AND IsAllCompleted = 0
           )
           OR
           (
               @Type = 'Total Orders'
               AND (
                       CreatedDate = CAST(GETDATE() AS DATE)
                       OR IsAllCompleted = 0
                   )
           )
        ORDER BY CreatedDate DESC;    

      --WITH Orders AS
      --  (
      --     SELECT
      --      Id,
      --      TallyRefNo,
      --      CAST(CreatedOn AS DATE) AS CreatedDate,
      --      CAST(DeliveryDate AS DATE) AS DeliveryDate,
      --      ISNULL(IsAllCompleted, 0) AS IsAllCompletedFlag,
      --      DeliveredDate,
      --      CASE
      --          WHEN ISNULL(IsAllCompleted, 0) = 0
      --          THEN 'Not Dispatched'
      --          WHEN IsAllCompleted = 1 AND DeliveredDate IS NOT NULL
      --          THEN 'Delivered'
      --          ELSE 'Dispatched'
      --      END AS Status
      --  FROM tbl_WorkOrderHdr
      --  WHERE ISNULL(IsDeleted, 0) = 0
      --  )
      --  SELECT
      --      TallyRefNo AS 'W/O No.',
      --      CreatedDate AS 'W/O Date',
      --      DeliveryDate AS 'Delivery Date',
      --      Status
      --  FROM Orders
      --  WHERE
      --      (
      --          @Type = 'New Orders'
      --          AND CreatedDate BETWEEN @FromDate AND @ToDate
      --      )
      --      OR
      --      (
      --          @Type = 'Pending Orders'
      --           AND CreatedDate <= @ToDate
      --          AND IsAllCompletedFlag = 0
      --      )
      --      OR
      --      (
      --          @Type = 'Over Due Orders'
      --          AND DeliveryDate < @ToDate
      --          AND IsAllCompletedFlag = 0
      --      )
      --      OR
      --      (
      --          @Type = 'Total Orders'
      --          AND CreatedDate BETWEEN @FromDate AND @ToDate
      --      )
      --  ORDER BY CreatedDate DESC;  
     END 

    IF (@SP_Action = 'ProductionGraph')
     BEGIN
       DECLARE @MonthStart DATE = DATEFROMPARTS(YEAR(@FromDate), MONTH(@FromDate), 1),
        @MonthEnd   DATE = EOMONTH(@FromDate);
        WITH DaySeries AS
            (
                SELECT @MonthStart AS TheDate
                UNION ALL
                SELECT DATEADD(DAY, 1, TheDate)
                FROM DaySeries
                WHERE DATEADD(DAY, 1, TheDate) <= @MonthEnd
            ),
            BaseData AS
            (
                SELECT
                    WH.ID,
                    CAST(WH.CreatedOn AS DATE) AS CreatedDate,
                    ISNULL(CAST(WD.Qty AS INT), 0) AS Qty,
                    ISNULL(CAST(MA.CompletedQty AS INT), 0) AS CompletedQty
                FROM tbl_WorkOrderHdr WH
                LEFT JOIN tbl_WorkOrderDetails WD
                    ON WH.ID = WD.HeaderID
                LEFT JOIN tbl_MachineProductionHDR MH
                    ON WH.ID = MH.WorkOrderID
                LEFT JOIN tbl_MachineProductionDTLS MD
                    ON MH.ID = MD.HeaderID
                LEFT JOIN tbl_MachineProductionAllocation MA
                    ON MD.ID = MA.ProductDtlID AND MA.StageName = 'Stage 2'
                WHERE ISNULL(WH.IsDeleted, 0) = 0
                  AND CAST(WH.CreatedOn AS DATE) BETWEEN @MonthStart AND @MonthEnd
            ),
            DailyAgg AS
            (
                SELECT
                    CreatedDate,
                    SUM(Qty)          AS TotalQty,
                    SUM(CompletedQty) AS ProductionQty
                FROM BaseData
                GROUP BY CreatedDate
            )
            SELECT
                DS.TheDate                    AS ProductionDate,
                ISNULL(DA.TotalQty, 0)        AS TotalQty,
                ISNULL(DA.ProductionQty, 0)   AS ProductionQty
            FROM DaySeries DS
            LEFT JOIN DailyAgg DA
                ON DS.TheDate = DA.CreatedDate
            ORDER BY DS.TheDate
            OPTION (MAXRECURSION 32);

        --       WITH BaseData AS
        --(
        --    SELECT
        --        WH.ID,
        --        CAST(WH.CreatedOn AS DATE) AS CreatedDate,
        --        DATEADD(DAY, - (DATEPART(WEEKDAY, WH.CreatedOn) + 5) % 7, CAST(WH.CreatedOn AS DATE)) AS WeekStartDate,
        --        ISNULL(CAST(WD.Qty AS INT), 0) AS Qty,
        --        ISNULL(CAST(MA.CompletedQty AS INT), 0) AS CompletedQty
        --    FROM tbl_WorkOrderHdr WH
        --    LEFT JOIN tbl_WorkOrderDetails WD
        --        ON WH.ID = WD.HeaderID
        --    LEFT JOIN tbl_MachineProductionHDR MH
        --        ON WH.ID = MH.WorkOrderID
        --    LEFT JOIN tbl_MachineProductionDTLS MD
        --        ON MH.ID = MD.HeaderID
        --    LEFT JOIN tbl_MachineProductionAllocation MA
        --        ON MD.ID = MA.ProductDtlID AND MA.StageName = 'Stage 2'
        --    WHERE ISNULL(WH.IsDeleted, 0) = 0
        --      AND CAST(WH.CreatedOn AS DATE) BETWEEN @MonthStart AND @MonthEnd
        --)
        --SELECT
        --    WeekStartDate,
        --    DATEADD(DAY, 6, WeekStartDate) AS WeekEndDate,
        --    SUM(Qty)            AS TotalQty,
        --    SUM(CompletedQty)   AS ProductionQty
        --FROM BaseData
        --GROUP BY WeekStartDate
        --ORDER BY WeekStartDate;
     END
END

-- Script for SP_AUTH_TOKEN_MASTER
GO
CREATE PROCEDURE [dbo].[SP_AUTH_TOKEN_MASTER]
    @UserName NVARCHAR(MAX)=NULL,
    @AuthToken NVARCHAR(MAX) = NULL,
    @TokenExpiry DATETIME = NULL,
    @Sek NVARCHAR(MAX) = NULL,
    @ClientId NVARCHAR(MAX) = NULL,
    @Action NVARCHAR(50) 
AS
BEGIN
    SET NOCOUNT ON;

    IF @Action = 'GetToken'
    BEGIN
        SELECT UserName, AuthToken As AuthKey, CONVERT(NVARCHAR, TokenExpiry, 120) AS TokenExpiry, Sek, ClientId
        FROM AUTH_TOKEN_MASTER
        WHERE UserName = @UserName
    END

   IF @Action = 'UpsertToken'
    BEGIN
            INSERT INTO AUTH_TOKEN_MASTER(UserName, AuthToken, TokenExpiry, Sek, ClientId)
            VALUES(@UserName, @AuthToken, @TokenExpiry, @Sek, @ClientId);
    END

   IF @Action = 'DeleteOldToken'
   BEGIN
    DELETE AUTH_TOKEN_MASTER
   END
END

-- Script for SP_WorkOrderMaster
GO

CREATE PROCEDURE [dbo].[SP_WorkOrderMaster]
(   @ShowRecords int =0,
    @Id int  = 0,
    @TallyRefNo NVARCHAR(20) = Null ,
	@WorkOrderNo Nvarchar(200) = Null,
    @WorkOrderDate  datetime = Null,
    @Dealer NVARCHAR(200) = Null,
    @CustomerName NVARCHAR(500) = Null,
    @CustomerRefNo NVARCHAR(100) = Null,
    @BillingGstNo Nvarchar(200) = Null,
    @BillingAddress NVARCHAR(max) = Null,
    @BillingPincode NVARCHAR(100) = Null,
    @ShippingGstNo Nvarchar(200) = Null,
    @ShippingAddress nvarchar(max) = null,
    @ShippingPincode nvarchar(100) = null,
    @DeliveryDate datetime = null,
	@AttachmentPath nvarchar(max) = null,
    @ActionBy nvarchar(100) = null,
  
    -- DETAIL PARAMETERS
    @ProductId nvarchar(100) = NULL,
	@HeaderID nvarchar(200) = null,
    @ProductName NVARCHAR(500) = NULL,
	@SqFeet NVARCHAR(100) = NULL,
	@UploadedImage NVARCHAR(500) = NULL,
    @PartNo NVARCHAR(300) = NULL,
	@Type NVARCHAR(300) = NULL,
    @Description NVARCHAR(max) = NULL,
    @Size NVARCHAR(50) = NULL,
    @Qty NVARCHAR(50) = NULL,
    @Unit NVARCHAR(20) = NULL,

    @SP_Action NVARCHAR(20) = Null,
    @Result int output
)
AS
BEGIN
      -- HDR Table
  	  IF @SP_Action = 'WoHdrList'
	   BEGIN
		 WITH WorkOrderMaster
			AS (
			    SELECT ID,TallyRefNo,CONVERT(nvarchar(10),WorkOrderDate,105) AS WorkOrderDate
				,Dealer,CustomerName,isdesignapproved,AttachmentPath,HoldStatus,CancelStatus,IsAllCompleted
				,CASE 
				  WHEN (isdesignapproved = 1 AND SendForDesign = 1)
				  THEN '<i><small>Design Approved</small></i>'
				  WHEN (isdesignapproved = 0 AND SendForDesign = 1) 
				  THEN '<i><small>Sent for Design Approval</small></i>'
				  ELSE '<i><small>Rejected from Designer</small></i>'
				  END DesignerStatus
				 ,SendForDesign
				,CASE
					WHEN EXISTS
					(
						SELECT 1
						FROM tbl_MachineProductionHDR MH
						WHERE MH.WorkOrderID = WH.ID
					)
					THEN 1
					ELSE 0
				END AS ProductionCheck

				FROM tbl_WorkOrderHdr WH
				WHERE IsDeleted = 0 
				AND
					(
						@ActionBy = ''
						OR @ActionBy IS NULL

						-- Sent for Approval
						OR (
							@ActionBy = 'Assigned'
							AND isdesignapproved = 0
							AND SendForDesign = 1
						)

						-- Design Approved
						OR (
							@ActionBy = 'Completed'
							AND isdesignapproved = 1
							AND SendForDesign = 1
						)

						-- Design Rejected
						OR (
							@ActionBy = 'Rejected'
							AND isdesignapproved = 0
							AND ISNULL(SendForDesign,0) = 0
						)
						-- Hold Status
						OR(
						   @ActionBy ='W/O On Hold'
						   AND HoldStatus = 1
						)
						-- Cancel Status
						OR(
						   @ActionBy ='W/O Canceled'
						   AND CancelStatus = 1
						)
					)
			    AND (
				      @Dealer = '' OR @Dealer IS NULL
                      OR TallyRefNo LIKE '%'+ @Dealer + '%'
					  OR Dealer LIKE '%'+ @Dealer + '%'
					  OR CustomerName LIKE '%'+ @Dealer + '%'
			        )
			   ),NUMBERED
		AS (
			SELECT *
				,ROW_NUMBER() OVER (
					ORDER BY Id DESC
					) AS RN
			FROM WorkOrderMaster
			)
		SELECT *
		FROM NUMBERED
		WHERE @ShowRecords = 0
			OR RN <= @ShowRecords
		ORDER BY ID DESC
		 SET @Result = 0
	   END

	  IF @SP_Action = 'WoHdrListById'
	   BEGIN
		  SELECT * FROM tbl_WorkOrderHdr WHERE ID = @Id
		  SET @Result = @Id
	   END
	 
	  IF @SP_Action = 'InsertWoHdr'
	   BEGIN
	     INSERT INTO tbl_WorkOrderHdr (
			 SeriesNo
			,TallyRefNo
			,WorkOrderDate
			,Dealer
			,CustomerName
			,CustomerRefNo
			,BillingGstNo
			,BillingAddress
			,BillingPincode
			,ShippingGstNo
			,ShippingAddress
			,ShippingPincode
			,DeliveryDate
			,CreatedBy
			,CreatedOn
			,IsDeleted
			,isdesignapproved
			,IsDispatched
			,isproductioncompleted
			,AttachmentPath
			,HoldStatus
			,CancelStatus
			,SendForDesign
			)
		VALUES (
			[dbo].[FN_WorkOrderNo]()
			,@TallyRefNo
			,@WorkOrderDate
			,@Dealer
			,@CustomerName
			,@CustomerRefNo
			,@BillingGstNo
			,@BillingAddress
			,@BillingPincode
			,@ShippingGstNo
			,@ShippingAddress
			,@ShippingPincode
			,@DeliveryDate
			,@ActionBy
			,GETDATE()
			,0
			,0
			,0
			,0
			,@AttachmentPath
			,0
			,0
			,1
			)
        SET @Result = SCOPE_IDENTITY()
	   END

      IF @SP_Action = 'UpdateWoHdr'
	   BEGIN
	    UPDATE tbl_WorkOrderHdr
		SET TallyRefNo =@TallyRefNo
			,WorkOrderDate = @WorkOrderDate
			,Dealer = @Dealer
			,CustomerName = @CustomerName
			,CustomerRefNo = @CustomerRefNo
			,BillingGstNo = @BillingGstNo
			,BillingAddress = @BillingAddress
			,BillingPincode = @BillingPincode
			,ShippingGstNo = @ShippingGstNo
			,ShippingAddress = @ShippingAddress
			,ShippingPincode = @ShippingPincode
			,DeliveryDate = @DeliveryDate
			,UpdatedOn =GETDATE()
			,UpdatedBy = @ActionBy
			,AttachmentPath= @AttachmentPath
			,SendForDesign = 1
		WHERE ID = @Id
		SET @Result = @Id
	   END

      IF (@SP_Action = 'DeleteWoHdr')
		BEGIN
			UPDATE tbl_WorkOrderHdr
			SET IsDeleted = 1
			WHERE ID = @Id
			SET @Result = @Id
		END

      IF (@SP_Action = 'HoldWoHdr')
		BEGIN
		   SELECT @HeaderID = PlaceOrderID FROM tbl_WorkOrderHdr WHERE ID = @Id
		    IF(@HeaderID IS NOT NULL OR @HeaderID <> '')
		    BEGIN
			  UPDATE tbl_DealersOrderHDR SET
			          HoldStatus = CASE 
                                        WHEN ISNULL(HoldStatus, 0) = 1 THEN 0
                                        ELSE 1
                                     END
									 , 
					  HoldDate = CASE 
                                        WHEN ISNULL(HoldStatus, 0) = 1 THEN NULL
                                        ELSE GETDATE()
                                   END
			  WHERE ID = @HeaderID
			END

			UPDATE tbl_WorkOrderHdr
			 SET HoldStatus = CASE 
                                    WHEN ISNULL(HoldStatus, 0) = 1 THEN 0
                                     ELSE 1
                              END
									 , 
					  HoldDate = CASE 
                                        WHEN ISNULL(HoldStatus, 0) = 1 THEN NULL
                                        ELSE GETDATE()
                                   END
			WHERE ID = @Id
			SET @Result = @Id
		END

      IF (@SP_Action = 'CancelWoHdr')
		BEGIN
		   SELECT @HeaderID = PlaceOrderID FROM tbl_WorkOrderHdr WHERE ID = @Id
		    IF(@HeaderID IS NOT NULL OR @HeaderID <> '')
		    BEGIN
			  UPDATE tbl_DealersOrderHDR 
			  SET OrderStatus = 'Order Canceled', Canceldate =  GETDATE()
			  WHERE ID = @HeaderID
			END

			 UPDATE tbl_WorkOrderHdr
			 SET CancelStatus =  1, CancelDate = GETDATE()
			 WHERE ID = @Id
			SET @Result = @Id
		END

     -- DTLS Table
      IF @SP_Action = 'WODTLSListById'
	   BEGIN
	     SELECT * FROM tbl_WorkOrderDetails WHERE HeaderID=@Id
		 SET @Result = @Id
 	   END 
     
      IF @SP_Action = 'InsertWODTLS'
	   BEGIN
	     INSERT INTO tbl_WorkOrderDetails (
			 HeaderID
			,ProductId
			,ProductName
			,PartNo
			,Description
			,Size
			,Unit
			,Qty
			,SqFeet
			,UploadedImage
			,Type
			)
		VALUES (
			 @HeaderId
            ,@ProductId
			,@ProductName
			,@PartNo
			,@Description
			,@Size
			,@Unit
			,@Qty
			,@SqFeet
			,@UploadedImage
			,@Type
			)
			 SET @Result = SCOPE_IDENTITY()
	   END
      
	  IF (@SP_Action = 'DeleteWODTLS')
		BEGIN
			DELETE tbl_WorkOrderDetails WHERE HeaderID = @Id
			SET @Result = @Id
		END

     --W/O For Production
	  IF (@SP_Action = 'SendForProduction')
	 BEGIN
			INSERT INTO tbl_ProductionInatial
			(
				WorkOrderId,
				WorkOrderNo,
				TotalQty,
				Size
			)
			SELECT
				hdr.ID,
				hdr.TallyRefNo,
				SUM(CAST(dtls.Qty as decimal)) AS Qty,
				dtls.Size
			FROM tbl_WorkOrderDetails dtls
			INNER JOIN tbl_WorkOrderHdr hdr
				ON hdr.ID = dtls.HeaderID
			WHERE hdr.ID = @Id
			GROUP BY
				hdr.ID,
				hdr.TallyRefNo,
				dtls.Size;

      SET @Result = @Id
	END

	  IF (@SP_Action ='approveworkorder')
	  BEGIN
	   SELECT @Dealer = PlaceOrderID FROM tbl_WorkOrderHdr WHERE ID=@Id
		 IF(@Dealer <> '' OR @Dealer  IS NOT NULL)
		   BEGIN
		     UPDATE tbl_DealersOrderHDR SET DesginStatus='Design Approved' WHERE ID = @Dealer
		   END

	       UPDATE tbl_WorkOrderHdr SET isdesignapproved = 1 WHERE ID=@Id
	  END
		
	  IF (@SP_Action ='DisApprove')
	  BEGIN
	    update tbl_WorkOrderHdr set SendForDesign = 0 where ID=@Id
	  END

	  IF (@SP_Action ='Revoke')
	  BEGIN
	    update tbl_WorkOrderHdr set isdesignapproved = 0,SendForDesign = 1 where ID=@Id
	  END

	  IF (@SP_Action = 'PlaceorderHDR')
	   BEGIN 
	     INSERT INTO tbl_DealersOrderHDR(OrderID,DealerID,CreatedDate,OrderStatus,InvoicePath,HoldStatus)
		 VALUES ('ORD' + RIGHT('000000' + CAST(NEXT VALUE FOR dbo.OrderSequence AS VARCHAR(6)), 6)
		 ,@Dealer,GETDATE(),CASE WHEN @Unit = 'Direct' THEN 'Order Approved'ELSE 'Order Placed' END,@UploadedImage,0);
		 SET @Result = SCOPE_IDENTITY();
	   END

      IF (@SP_Action = 'PlaceorderDtls')
	   BEGIN 
	     INSERT INTO tbl_DealersOrderDTLs(HeaderID,ProductID,ProductName,ProductType,Size,Qty,ProductNote,ImagePathName)
		 VALUES (@HeaderID,@ProductId,@ProductName,@Type,@Size,@Qty,@Description,@UploadedImage);
		 SET @Result = SCOPE_IDENTITY();
	   END 

      IF @SP_Action = 'GetOrderID'
	   BEGIN
	    SELECT 'ORD' + RIGHT('000000' + CAST(NEXT VALUE FOR dbo.OrderSequence AS VARCHAR(10)), 6) AS OrderID;
	   END
END

-- Script for SP_ProductionsPlanning
GO
CREATE PROCEDURE [dbo].[SP_ProductionsPlanning]
    @ShowRecords INT = 0,
    @Id INT = 0,
    @MachineID  NVARCHAR(200) = null,
    @Qty NVARCHAR(200) = null,
    @WOHeaderId NVARCHAR(100)= null,
    @ProductName NVARCHAR(500)= null,
    @PartNo NVARCHAR(100)= null,
    @Size NVARCHAR(100)= null,
    @ReceivedQty NVARCHAR(100)= null,
    @WorkOrderNo NVARCHAR(200) = NULL,
    @SP_Action NVARCHAR(100) = NULL,
    @sheduledate DATE = Null,
    @HeaderID nvarchar(100)= Null
   ,@TotalQty nvarchar(100)= null
   ,@AllocatedQty nvarchar(100)= null
   ,@AllocatedSqFeet nvarchar(200)= null
   ,@SqFeet nvarchar(100)= null
   ,@Stage1MachineID nvarchar(100)= null
   ,@Stage1CompletedQty nvarchar(100)= null
   ,@Stage1CompletedDate datetime = null
   ,@Stage2MachineID nvarchar(100)= null
   ,@Stage2CompletedQty nvarchar(100)= null
   ,@Stage2CompletedDate datetime= null
   ,@Remark nvarchar(max) = null
   ,@IsLRAttached nvarchar(max) = null
   ,@IsInvoiceAttached nvarchar(max) = null
   ,@Result INT OUTPUT

AS
BEGIN
     
    --old working action
    IF @SP_Action = 'GetOperatorDetailsS1'
     BEGIN
        SELECT UM.FullName as OperatorName,MM.ID as MachineID ,MM.MachineName as MachineName,MM.AllocatedStage as StageName
        ,SUM(ISNULL(CAST(MPD.AllocatedQty as decimal),0)) as TargetQty
        ,SUM(ISNULL(CAST(MPD.Stage1CompletedQty as decimal),0)) as CompletedQty
        FROM tbl_AssignedMachines AM
        LEFT JOIN tbl_UserMaster UM ON AM.OperatorID = UM.ID
        LEFT JOIN tbl_MachineMaster MM ON AM.MachineId = MM.ID   
        LEFT JOIN tbl_MachineProductionDTLS MPD ON AM.MachineID = MPD.Stage1MachineID
        WHERE (@WOHeaderId = 'Admin'OR AM.OperatorID = @Id) AND MM.AllocatedStage = 'Stage 1'
        GROUP BY UM.FullName,MM.ID,MM.MachineName,MM.AllocatedStage
     END

    IF @SP_Action = 'GetOperatorDetailsS2'
     BEGIN
        SELECT UM.FullName as OperatorName,MM.ID as MachineID ,MM.MachineName as MachineName,MM.AllocatedStage as StageName
        ,SUM(ISNULL(CAST(MPD.AllocatedQty as decimal),0)) as TargetQty
        ,SUM(ISNULL(CAST(MPD.Stage2CompletedQty as decimal),0)) as CompletedQty
        FROM tbl_AssignedMachines AM
        LEFT JOIN tbl_UserMaster UM ON AM.OperatorID = UM.ID
        LEFT JOIN tbl_MachineMaster MM ON AM.MachineId = MM.ID   
        LEFT JOIN tbl_MachineProductionDTLS MPD ON AM.MachineID = MPD.Stage2MachineID
        WHERE (@WOHeaderId = 'Admin'OR AM.OperatorID = @Id) AND MM.AllocatedStage = 'Stage 2'
        GROUP BY UM.FullName,MM.ID,MM.MachineName,MM.AllocatedStage
     END
  
    IF @SP_Action= 'GetMachineCapacity'
     BEGIN
       SELECT M.ID as MachineID,
               M.AllocatedStage,
               M.MachineName,
               (TRY_CAST(M.MachinePerHRQty AS FLOAT) * TRY_CAST(M.MachineRunningHR AS FLOAT)) AS MachineCapacity,
               ISNULL(SUM(TRY_CAST(MPD.AllocatedSqFeet AS FLOAT)), 0) - ISNULL(SUM(TRY_CAST(MPD.Stage1CompetedSqFeet AS FLOAT)), 0) AS MachineLoad,
               ((TRY_CAST(M.MachinePerHRQty AS FLOAT) * TRY_CAST(M.MachineRunningHR AS FLOAT))
                - (ISNULL(SUM(TRY_CAST(MPD.AllocatedSqFeet AS FLOAT)), 0) - ISNULL(SUM(TRY_CAST(MPD.Stage1CompetedSqFeet AS FLOAT)), 0))
               ) AS MachineAvailable,

               -- ✔ LOAD %
               CASE
                   WHEN (TRY_CAST(M.MachinePerHRQty AS FLOAT) * TRY_CAST(M.MachineRunningHR AS FLOAT)) = 0 THEN
                       0
                   ELSE
                       ROUND(
                                ((ISNULL(SUM(TRY_CAST(MPD.AllocatedSqFeet AS FLOAT)), 0) - 
                                ISNULL(SUM(TRY_CAST(MPD.Stage1CompetedSqFeet AS FLOAT)), 0)) * 100.0)
                                / (TRY_CAST(M.MachinePerHRQty AS FLOAT) * TRY_CAST(M.MachineRunningHR AS FLOAT)),
                                2
                            )
               END AS LoadPercentage
        FROM tbl_MachineMaster M
            LEFT JOIN tbl_MachineProductionDTLS MPD 
            ON MPD.Stage1MachineID = M.ID 
            --AND MPH.Status = 'In-Process'
        WHERE M.IsDeleted = 0
              AND M.IsActive = 1 AND M.AllocatedStage ='Stage 1'
        GROUP BY M.ID,
                 M.AllocatedStage,
                 M.MachineName,
                 M.MachinePerHRQty,
                 M.MachineRunningHR;
     END
    
    IF @SP_Action = 'GetWorkOrder'
     BEGIN
       WITH WorkOrder AS(
            SELECT 
                hdr.RankNo,
                hdr.ScheduledDate,
                hdr.ID AS MainID,
                hdr.TallyRefNo,
                hdr.Dealer,
                hdr.CustomerName,
                hdr.isdesignapproved,

                dtls.ID AS DetailedID,
                dtls.ProductName,
                dtls.PartNo,
                dtls.Size,
                dtls.Qty AS Qty,
                dtls.SqFeet AS SqFeet,

                mph.ID AS ProductionID,
                mph.S1Status as Status,
                mpd.Stage1MachineId as MachineID,

                ISNULL(mpd.AllocatedQty,0) AS AllocatedQty,
                ISNULL(mpd.AllocatedSqFeet,0) AS AllocatedSqFeet,

                dtls.Qty - ISNULL(CAST(mpd.AllocatedQty as FLOAT),0) AS RemainingQty,
                dtls.SqFeet - ISNULL(CAST(mpd.AllocatedSqFeet as FLOAT),0) AS RemainingSqFeet

            FROM tbl_WorkOrderDetails dtls
            INNER JOIN tbl_WorkOrderHDR hdr
                ON hdr.ID = dtls.HeaderID

            LEFT JOIN tbl_MachineProductionHDR mph
                ON mph.WorkOrderID = hdr.ID

            LEFT JOIN tbl_MachineProductionDTLS mpd
                ON mpd.HeaderID = mph.ID
                AND mpd.ProductName = dtls.ProductName
                AND mpd.Size = dtls.Size

            WHERE hdr.isdesignapproved = 1
            AND hdr.IsDeleted = 0 AND (mph.S1Status IS NULL OR mph.S1Status <> 'Completed') 
          ),NUMBERED AS(
            SELECT *,ROW_NUMBER() OVER(ORDER BY MainID DESC) AS RN
            FROM WorkOrder
          )
          SELECT * FROM NUMBERED
              WHERE @ShowRecords = 0
			    OR RN <= @ShowRecords
          ORDER BY MainID DESC
     END

    IF @SP_Action = 'AssignWorkOrderS1'
      BEGIN
        WITH WorkOrder AS (
           SELECT
                mph.RankSrNo AS RankNo,
                mph.WorkOrderNo AS WorkOrderNo,
                mph.AssignedDate AS ScheduledDate,
                hdr.Dealer,
                hdr.isdesignapproved,

                mpd.ID AS DetailedID,
                mpd.ProductName,
                mpd.Size,
                mpd.TotalQty AS totQty,
                mpd.SqFeet AS SqFeet,

                mph.ID AS ProductionID,
                mph.S1Status as Status,
                mpd.Stage1MachineId as MachineID,

                ISNULL(mpd.AllocatedQty,0) AS AllocatedQty,
                ISNULL(mpd.AllocatedSqFeet,0) AS AllocatedSqFeet,

                ISNULL(mpd.Stage2CompletedQty,0) AS Stage2CompletedQty,
                ISNULL(mpd.Stage1CompletedQty,0) AS Stage1CompletedQty,
                ISNULL(mpd.Stage1CompetedSqFeet,0) AS Stage1CompetedSqFeet,
               CONVERT(nvarchar(10),mpd.Stage1CompletedDate,105) AS Stage1CompletedDate

            FROM tbl_MachineProductionDTLS mpd
            INNER JOIN tbl_MachineProductionHDR mph
                ON mph.ID = mpd.HeaderID

            LEFT JOIN tbl_WorkOrderHdr hdr
                ON hdr.ID = mph.WorkOrderID

            WHERE hdr.isdesignapproved = 1
            AND hdr.IsDeleted = 0 AND mpd.Stage1MachineID = @Id
       ),
         NUMBERED AS (SELECT *, ROW_NUMBER() OVER (ORDER BY CASE WHEN RankNo IS NULL THEN 1 ELSE 0 END, RankNo ASC) AS RN
           FROM WorkOrder
       )
        SELECT *
            FROM NUMBERED
            WHERE @ShowRecords = 0
                  OR RN <= @ShowRecords
            ORDER BY CASE
                         WHEN RankNo IS NULL THEN
                             1
                         ELSE
                             0
                     END,
                     RankNo ASC
      END

    IF @SP_Action = 'InsertToProductionHdrS1'
     BEGIN
       INSERT INTO tbl_MachineProductionHDR (WorkOrderID,WorkOrderNo,RankSrNo,AssignedDate,S1Status)
       VALUES(@WOHeaderId,@WorkOrderNo,NULL,@sheduledate,'Machine Allocated')

       SET @Result = SCOPE_IDENTITY();
     END

    IF @SP_Action = 'InsertToProductionDtlsS1'
     BEGIN
       INSERT INTO tbl_MachineProductionDTLS (HeaderID,ProductName,Size,TotalQty,SqFeet,AllocatedQty,AllocatedSqFeet
       ,Stage1MachineID,Stage1CompletedQty,Stage1CompetedSqFeet)
       VALUES(@HeaderID,@ProductName,@Size,@TotalQty,@SqFeet,@AllocatedQty,@AllocatedSqFeet,@Stage1MachineID,'0','0')

       SET @Result = SCOPE_IDENTITY();
     END

    IF @SP_Action = 'AssignWorkOrderS2'
      BEGIN
        WITH WorkOrder AS (
           SELECT
                mph.RankSrNo AS RankNo,
                mph.WorkOrderNo AS WorkOrderNo,
                mph.AssignedDate AS ScheduledDate,
                hdr.Dealer,
                hdr.isdesignapproved,

                mpd.ID AS DetailedID,
                mpd.ProductName,
                mpd.Size,
                mpd.TotalQty AS totQty,
                mpd.SqFeet AS SqFeet,

                mph.ID AS ProductionID,
                mph.S2Status as Status,
                mpd.Stage2MachineId as MachineID,

                ISNULL(mpd.AllocatedQty,0) AS AllocatedQty,
                ISNULL(mpd.AllocatedSqFeet,0) AS AllocatedSqFeet,

                ISNULL(mpd.Stage1CompletedQty,0) AS Stage1CompletedQty, 
                ISNULL(mpd.Stage2CompletedQty,0) AS Stage2CompletedQty,
                ISNULL(mpd.Stage2CompetedSqFeet,0) AS Stage2CompetedSqFeet,
                CONVERT(nvarchar(10),mpd.Stage2CompletedDate,105) AS Stage2CompletedDate

            FROM tbl_MachineProductionDTLS mpd
            INNER JOIN tbl_MachineProductionHDR mph
                ON mph.ID = mpd.HeaderID

            LEFT JOIN tbl_WorkOrderHdr hdr
                ON hdr.ID = mph.WorkOrderID

            WHERE hdr.isdesignapproved = 1
            AND hdr.IsDeleted = 0 --AND mpd.Stage2MachineID = @Id
       ),
         NUMBERED AS (SELECT *, ROW_NUMBER() OVER (ORDER BY CASE WHEN RankNo IS NULL THEN 1 ELSE 0 END, RankNo ASC) AS RN
           FROM WorkOrder
       )
        SELECT *
            FROM NUMBERED
            WHERE @ShowRecords = 0
                  OR RN <= @ShowRecords
            ORDER BY CASE
                         WHEN RankNo IS NULL THEN
                             1
                         ELSE
                             0
                     END,
                     RankNo ASC
      END

    IF @SP_Action = 'InsertToProductionDtlsS2'
     BEGIN
       INSERT INTO tbl_MachineProductionDTLS (HeaderID,ProductName,Size,TotalQty,SqFeet,AllocatedQty,AllocatedSqFeet
       ,Stage1MachineID,Stage1CompletedQty,Stage1CompetedSqFeet)
       VALUES(@HeaderID,@ProductName,@Size,@TotalQty,@SqFeet,@AllocatedQty,@AllocatedSqFeet,@Stage1MachineID,'0','0')

       SET @Result = SCOPE_IDENTITY();
     END

    IF @SP_Action = 'GetCompletedWOList'
     BEGIN
       WITH WorkOrder AS(
            SELECT WO.ID AS ID,TallyRefNo,CONVERT(nvarchar(10),WorkOrderDate,105) AS WorkOrderDate,Dealer,CustomerName,isdesignapproved,AttachmentPath
				FROM tbl_WorkOrderHdr WO 
				LEFT JOIN tbl_MachineProductionhdr MP
				ON MP.WorkOrderID = WO.ID
				WHERE IsDeleted = 0 AND MP.S2Status ='Completed'
			       AND (
				        @MachineID = ''
                       OR TallyRefNo LIKE '%'+ @MachineID + '%'
					   OR Dealer LIKE '%'+ @MachineID + '%'
					   OR CustomerName LIKE '%'+ @MachineID + '%'
			          )
          ),NUMBERED AS(
            SELECT *,ROW_NUMBER() OVER(ORDER BY ID DESC) AS RN
            FROM WorkOrder
          )
          SELECT * FROM NUMBERED
              WHERE @ShowRecords = 0
			    OR RN <= @ShowRecords
          ORDER BY ID DESC
     END



       -- new created one

     IF @SP_Action= 'GetMachineCapacityss'
     BEGIN
       --SELECT M.ID as MachineID,
       --        M.AllocatedStage,
       --        M.MachineName,
       --        M.MachinePerHRQty,
       --        M.MachineRunningHR,
       --        (TRY_CAST(M.MachinePerHRQty AS FLOAT) * TRY_CAST(M.MachineRunningHR AS FLOAT)) AS MachineCapacity,
       --        ISNULL(SUM(TRY_CAST(MPA.AllocatedSqFeet AS FLOAT)), 0) - ISNULL(SUM(TRY_CAST(MPA.CompletedQty AS FLOAT)), 0) AS MachineLoad,
       --        ((TRY_CAST(M.MachinePerHRQty AS FLOAT) * TRY_CAST(M.MachineRunningHR AS FLOAT))
       --         - (ISNULL(SUM(TRY_CAST(MPA.AllocatedSqFeet AS FLOAT)), 0) - ISNULL(SUM(TRY_CAST(MPA.CompletedSqFeet AS FLOAT)), 0))
       --        ) AS MachineAvailable,

       --        -- ✔ LOAD %
       --        CASE
       --            WHEN (TRY_CAST(M.MachinePerHRQty AS FLOAT) * TRY_CAST(M.MachineRunningHR AS FLOAT)) = 0 THEN
       --                0
       --            ELSE
       --                ROUND(
       --                         ((ISNULL(SUM(TRY_CAST(MPA.AllocatedSqFeet AS FLOAT)), 0) - 
       --                         ISNULL(SUM(TRY_CAST(MPA.CompletedQty AS FLOAT)), 0)) * 100.0)
       --                         / (TRY_CAST(M.MachinePerHRQty AS FLOAT) * TRY_CAST(M.MachineRunningHR AS FLOAT)),
       --                         2
       --                     )
       --        END AS LoadPercentage
       --     FROM tbl_MachineMaster M
       --     LEFT JOIN tbl_MachineProductionAllocation MPA 
       --     ON MPA.MachineID = M.ID AND MPA.CompletedDate IS NULL
       --     LEFT JOIN tbl_MachineProductionDTLS MPD
       --     ON MPA.ProductDtlID = MPD.ID
       --     --AND MPH.Status = 'In-Process'
       -- WHERE M.IsDeleted = 0
       --       AND M.IsActive = 1 AND M.AllocatedStage ='Stage 1'
       -- GROUP BY M.ID,
       --          M.AllocatedStage,
       --          M.MachineName,
       --          M.MachinePerHRQty,
       --          M.MachineRunningHR,
       --          M.MachinePerHRQty,
       --          M.MachineRunningHR;

       SELECT M.ID as MachineID,
               M.AllocatedStage,
               M.MachineName,
               M.MachinePerHRQty,
               M.MachineRunningHR,
               (TRY_CAST(M.MachinePerHRQty AS FLOAT) * TRY_CAST(M.MachineRunningHR AS FLOAT)) AS MachineCapacity,
               ISNULL(
                    SUM(
                        CASE
                            WHEN ISNULL(WH.HoldStatus,0)=0
                             AND ISNULL(WH.CancelStatus,0)=0
                            THEN TRY_CAST(MPA.AllocatedSqFeet AS FLOAT)
                            ELSE 0
                        END
                    ),0)
                -
                ISNULL(
                    SUM(
                        CASE
                            WHEN ISNULL(WH.HoldStatus,0)=0
                             AND ISNULL(WH.CancelStatus,0)=0
                            THEN TRY_CAST(MPA.CompletedSqFeet AS FLOAT)
                            ELSE 0
                        END
                    ),0
                ) AS MachineLoad,
                (
                    (TRY_CAST(M.MachinePerHRQty AS FLOAT) * TRY_CAST(M.MachineRunningHR AS FLOAT))
                    -
                    (
                        ISNULL(
                            SUM(
                                CASE
                                    WHEN ISNULL(WH.HoldStatus,0)=0
                                     AND ISNULL(WH.CancelStatus,0)=0
                                    THEN TRY_CAST(MPA.AllocatedSqFeet AS FLOAT)
                                    ELSE 0
                                END
                            ),0)
                        -
                        ISNULL(
                            SUM(
                                CASE
                                    WHEN ISNULL(WH.HoldStatus,0)=0
                                     AND ISNULL(WH.CancelStatus,0)=0
                                    THEN TRY_CAST(MPA.CompletedSqFeet AS FLOAT)
                                    ELSE 0
                                END
                            ),0)
                    )
                ) AS MachineAvailable,

              CASE
                WHEN (TRY_CAST(M.MachinePerHRQty AS FLOAT) * TRY_CAST(M.MachineRunningHR AS FLOAT)) = 0
                THEN 0
                ELSE ROUND(
                    (
                        (
                            ISNULL(
                                SUM(
                                    CASE
                                        WHEN ISNULL(WH.HoldStatus,0)=0
                                         AND ISNULL(WH.CancelStatus,0)=0
                                        THEN TRY_CAST(MPA.AllocatedSqFeet AS FLOAT)
                                        ELSE 0
                                    END
                                ),0)
                            -
                            ISNULL(
                                SUM(
                                    CASE
                                        WHEN ISNULL(WH.HoldStatus,0)=0
                                         AND ISNULL(WH.CancelStatus,0)=0
                                        THEN TRY_CAST(MPA.CompletedSqFeet AS FLOAT)
                                        ELSE 0
                                    END
                                ),0)
                        ) * 100.0
                    )
                    / (TRY_CAST(M.MachinePerHRQty AS FLOAT) * TRY_CAST(M.MachineRunningHR AS FLOAT))
                ,2)
            END AS LoadPercentage
            FROM tbl_MachineMaster M
            LEFT JOIN tbl_MachineProductionAllocation MPA 
            ON MPA.MachineID = M.ID AND MPA.CompletedDate IS NULL
            LEFT JOIN tbl_MachineProductionDTLS MPD
            ON MPA.ProductDtlID = MPD.ID
            LEFT JOIN tbl_MachineProductionHDR MPH
            ON MPH.ID = MPD.HeaderID
            LEFT JOIN tbl_WorkOrderHdr WH
            ON WH.ID = MPH.WorkOrderID
        WHERE M.IsDeleted = 0
              AND M.IsActive = 1 AND M.AllocatedStage ='Stage 1'
        GROUP BY M.ID,
                 M.AllocatedStage,
                 M.MachineName,
                 M.MachinePerHRQty,
                 M.MachineRunningHR,
                 M.MachinePerHRQty,
                 M.MachineRunningHR;

     END
    
     IF @SP_Action = 'GetWorkOrdersss'
     BEGIN
       WITH WorkOrder AS(
             SELECT 
                hdr.RankNo,
                hdr.ScheduledDate,
                hdr.ID AS MainID,
                hdr.TallyRefNo,
                hdr.Dealer,
                hdr.Dealer as CustomerName,
                hdr.isdesignapproved,

                dtls.ID AS DetailedID,
                dtls.ProductName,
                dtls.PartNo,
                dtls.Size,
                dtls.Qty AS Qty,
                dtls.SqFeet AS SqFeet,

                mph.ID AS ProductionID,
                 CASE 
                    WHEN mph.S1Status = 'Partially Completed'
                    THEN 'Work Started'
                    WHEN mph.S1Status = 'Machine Allocated'
                    THEN 'Machine Allocated'
                    WHEN (mph.S2Status IS NULL OR mph.S2Status <> 'Completed') AND mph.S1Status IS NOT NULL
                    THEN 'S1 Completed'
                    WHEN mph.S2Status = 'Completed'
                    THEN 'Job Done'
                    ELSE NULL
                END AS Status,
                mph.S1Status as Statusss,
                STUFF(
                (
                    SELECT ',' + mpa2.MachineID
                    FROM tbl_MachineProductionAllocation mpa2
                    INNER JOIN tbl_MachineProductionDTLS mpd2
                        ON mpd2.ID = mpa2.ProductDtlID
                    WHERE mpd2.HeaderID = mph.ID
                      AND mpd2.ProductName = dtls.ProductName
                      AND mpd2.Size = dtls.Size AND mpa2.StageName = 'Stage 1'
                    FOR XML PATH(''), TYPE
                ).value('.', 'NVARCHAR(MAX)'), 1, 1, '') AS MachineID,

                ISNULL(SUM(CAST(mpa.AllocatedQty as decimal)) ,0) AS AllocatedQty,
                ISNULL(SUM(CAST(mpa.AllocatedSqFeet as decimal)),0) AS AllocatedSqFeet,

                dtls.Qty - ISNULL(SUM(CAST(mpa.AllocatedQty as decimal)),0) AS RemainingQty,
                dtls.SqFeet - ISNULL(SUM(CAST(mpa.AllocatedSqFeet as decimal)),0) AS RemainingSqFeet

            FROM tbl_WorkOrderDetails dtls
            INNER JOIN tbl_WorkOrderHDR hdr
                ON hdr.ID = dtls.HeaderID

            LEFT JOIN tbl_MachineProductionHDR mph
                ON mph.WorkOrderID = hdr.ID

            LEFT JOIN tbl_MachineProductionDTLS mpd
                ON mpd.HeaderID = mph.ID
                AND mpd.ProductName = dtls.ProductName
                AND mpd.Size = dtls.Size

            LEFT JOIN tbl_MachineProductionAllocation mpa
                ON mpd.ID = mpa.ProductDtlID

            WHERE hdr.isdesignapproved = 1
            AND hdr.IsDeleted = 0  AND mpa.NextStageId IS NULL 
            AND hdr.isproductioncompleted = 0 AND hdr.CancelStatus=0 
            And hdr.HoldStatus = 0 AND (mph.S2Status IS NULL OR mph.S2Status <> 'Completed')
            GROUP BY  hdr.RankNo,
                hdr.ScheduledDate,
                hdr.ID,
                hdr.TallyRefNo,
                hdr.Dealer,
                hdr.CustomerName,
                hdr.isdesignapproved,

                dtls.ID ,
                dtls.ProductName,
                dtls.PartNo,
                dtls.Size,
                dtls.Qty,
                dtls.SqFeet,

                mph.ID,
                mph.S1Status,
                mph.S2Status
          ),NUMBERED AS(
            SELECT *,ROW_NUMBER() OVER(ORDER BY MainID DESC) AS RN
            FROM WorkOrder
          )
          SELECT * FROM NUMBERED
              WHERE @ShowRecords = 0
			    OR RN <= @ShowRecords
          ORDER BY MainID DESC
     END
        
     IF @SP_Action = 'InsertToProductionHdr'
     BEGIN
       INSERT INTO tbl_MachineProductionHDR (WorkOrderID,WorkOrderNo,RankSrNo,AssignedDate,S1Status)
       VALUES(@WOHeaderId,@WorkOrderNo,NULL,@sheduledate,'Machine Allocated')

       SET @Result = SCOPE_IDENTITY();
     END

     IF @SP_Action = 'InsertToProductionDtls'
     BEGIN
       INSERT INTO tbl_MachineProductionDTLS (HeaderID,ProductName,Size,TotalQty,SqFeet)
       VALUES(@HeaderID,@ProductName,@Size,@TotalQty,@SqFeet)

       SET @Result = SCOPE_IDENTITY();
     END

     IF @SP_Action = 'InsertToProductionDtlsAllocation'
     BEGIN
       INSERT INTO tbl_MachineProductionAllocation (ProductDtlID,MachineID,AllocatedQty,AllocatedSqFeet,CompletedQty,CompletedSqFeet,StageName)
       VALUES(@HeaderID,@MachineID,@AllocatedQty,@AllocatedSqFeet,'0','0','Stage 1')

       SET @Result = SCOPE_IDENTITY();
     END

     IF @SP_Action = 'AssignWorkOrders'
      BEGIN
        WITH WorkOrder AS (
           SELECT
                mph.RankSrNo AS RankNo,
                mph.WorkOrderNo AS WorkOrderNo,
                mph.AssignedDate AS ScheduledDate,
                hdr.Dealer,
                mpa.ID AS DetailedID,
                mpd.ProductName,
                mpd.Size,
                mpd.TotalQty AS totQty,
                mpd.SqFeet AS SqFeet,

               CASE
                    WHEN SUM(ISNULL(CAST(mpa.CompletedQty AS decimal(18,2)),0)) = 0
                        THEN 'Machine Allocated'

                    WHEN SUM(ISNULL(CAST(mpa.CompletedQty AS decimal(18,2)),0))
                         < SUM(ISNULL(CAST(mpa.AllocatedQty AS decimal(18,2)),0))
                        THEN 'Work Started'

                    ELSE 'Completed'
                END AS Status1,

                 CASE
                    WHEN SUM(ISNULL(CAST(mpa.AllocatedQty AS decimal),0)) = 0 
                        THEN ''

                    WHEN (SUM(ISNULL(CAST(mpa.AllocatedQty AS decimal),0)) != 0 
                         AND SUM(ISNULL(CAST(mpa.AllocatedQty AS decimal),0)) <= SUM(ISNULL(CAST(mpd.TotalQty AS decimal),0)))
                        THEN 'Partially Active'

                    WHEN SUM(ISNULL(CAST(mpa.AllocatedQty AS decimal),0)) = SUM(ISNULL(CAST(mpd.TotalQty AS decimal),0))
                        THEN 'Active'

                    ELSE 'Completed'
                END AS Status2,

                mpd.HeaderID AS ProductionID,
                MAX(mpa.MachineID) as MachineID,

                ISNULL(SUM(CAST(mpa.AllocatedQty as decimal)),0) AS AllocatedQty,
                ISNULL(SUM(CAST(mpa.AllocatedSqFeet as decimal)),0) AS AllocatedSqFeet,

                ISNULL(SUM(CAST(mpa.CompletedQty as decimal)),0) AS CompletedQty,
                ISNULL(SUM(CAST(mpa.CompletedSqFeet as decimal)),0) AS CompetedSqFeet,
                CONVERT(nvarchar(10),MAX(mpa.CompletedDate),105) AS CompletedDate,

                ISNULL(SUM(CAST(mpa.RevertQty as decimal)),0) AS RevertQty,
                ISNULL(SUM(CAST(mpa.PackagingRevertQty as decimal)),0) AS PackagingRevertQty
            
            FROM tbl_MachineProductionAllocation mpa
            INNER JOIN tbl_MachineProductionDTLS mpd
                ON mpd.ID = mpa.ProductDtlID
            INNER JOIN tbl_MachineProductionHDR mph
                ON mph.ID = mpd.HeaderID

            LEFT JOIN tbl_WorkOrderHdr hdr
                ON hdr.ID = mph.WorkOrderID

            WHERE hdr.isdesignapproved = 1
            AND hdr.IsDeleted = 0 AND mpa.MachineID = @Id
            AND hdr.CancelStatus=0 AND hdr.HoldStatus = 0
            AND (hdr.IsAllCompleted IS NULL OR hdr.IsAllCompleted = 0)
            AND (mph.S2Status IS NULL OR mph.S2Status <> 'Completed')
            GROUP BY   mph.RankSrNo ,
                mph.WorkOrderNo,
                mph.AssignedDate,
                hdr.Dealer,
                mpa.ID,
                mpd.ProductName,
                mpd.Size,
                mpd.TotalQty,
                mpd.SqFeet,

                mph.S1Status,
                mpd.HeaderID
       ),
         NUMBERED AS (SELECT *, ROW_NUMBER() OVER (ORDER BY CASE WHEN RankNo IS NULL THEN 1 ELSE 0 END, RankNo ASC) AS RN
           FROM WorkOrder
       )
        SELECT *
            FROM NUMBERED
            WHERE @ShowRecords = 0
                  OR RN <= @ShowRecords
            ORDER BY CASE
                         WHEN RankNo IS NULL THEN
                             1
                         ELSE
                             0
                     END,
                     RankNo ASC
      END
     
     IF @SP_Action = 'GetOperatorDetailsSs1'
     BEGIN
        SELECT MAX(UM.FullName)  as OperatorName,MM.ID as MachineID ,MM.MachineName as MachineName,MM.AllocatedStage as StageName
        ,SUM(ISNULL(CAST(MPA.AllocatedQty as decimal),0)) as TargetQty
        ,SUM(ISNULL(CAST(MPA.CompletedQty as decimal),0)) as CompletedQty
        ,STUFF((
        SELECT DISTINCT ',' + CAST(MPH2.ID AS VARCHAR(20))
        FROM tbl_MachineProductionAllocation MPA2
        INNER JOIN tbl_MachineProductionDTLS MPD2
            ON MPD2.ID = MPA2.ProductDtlID
        INNER JOIN tbl_MachineProductionHDR MPH2
            ON MPH2.ID = MPD2.HeaderID
        WHERE MPA2.MachineID = MM.ID
        FOR XML PATH(''), TYPE
        ).value('.', 'NVARCHAR(MAX)'), 1, 1, '') AS WorkOrderIDs
        FROM tbl_AssignedMachines AM
        LEFT JOIN tbl_UserMaster UM ON AM.OperatorID = UM.ID
        LEFT JOIN tbl_MachineMaster MM ON AM.MachineId = MM.ID   
        LEFT JOIN tbl_MachineProductionAllocation MPA ON MPA.MachineID = AM.MachineId
        LEFT JOIN tbl_MachineProductionDTLS MPD ON MPD.ID = MPA.ProductDtlID
        LEFT JOIN tbl_MachineProductionHDR MPH ON MPH.ID = MPD.HeaderID
        WHERE (@WOHeaderId = 'Admin'OR AM.OperatorID = @Id) 
        AND MM.AllocatedStage = 'Stage 1' --AND (MPH.S1Status IS NULL OR MPH.S1Status<>'Completed')
        GROUP BY MM.ID,MM.MachineName,MM.AllocatedStage
     END

     IF @SP_Action = 'GetOperatorDetailsSs2'
     BEGIN
        SELECT MAX(UM.FullName) as OperatorName,MM.ID as MachineID ,MM.MachineName as MachineName,MM.AllocatedStage as StageName
        ,SUM(ISNULL(CAST(MPA.AllocatedQty as decimal),0)) as TargetQty
        ,SUM(ISNULL(CAST(MPA.CompletedQty as decimal),0)) as CompletedQty
        ,STUFF((
        SELECT DISTINCT ',' + CAST(MPH2.ID AS VARCHAR(20))
        FROM tbl_MachineProductionAllocation MPA2
        INNER JOIN tbl_MachineProductionDTLS MPD2
            ON MPD2.ID = MPA2.ProductDtlID
        INNER JOIN tbl_MachineProductionHDR MPH2
            ON MPH2.ID = MPD2.HeaderID
        WHERE MPA2.MachineID = MM.ID
        FOR XML PATH(''), TYPE
        ).value('.', 'NVARCHAR(MAX)'), 1, 1, '') AS WorkOrderIDs
        FROM tbl_AssignedMachines AM
        LEFT JOIN tbl_UserMaster UM ON AM.OperatorID = UM.ID
        LEFT JOIN tbl_MachineMaster MM ON AM.MachineId = MM.ID   
        LEFT JOIN tbl_MachineProductionAllocation MPA ON MPA.MachineID = AM.MachineId
        LEFT JOIN tbl_MachineProductionDTLS MPD ON MPD.ID = MPA.ProductDtlID
        LEFT JOIN tbl_MachineProductionHDR MPH ON MPH.ID = MPD.HeaderID
        WHERE (@WOHeaderId = 'Admin'OR AM.OperatorID = @Id) 
        AND MM.AllocatedStage = 'Stage 2' --AND (MPH.S2Status IS NULL OR MPH.S2Status<>'Completed')
        GROUP BY MM.ID,MM.MachineName,MM.AllocatedStage
     END

     IF @SP_Action = 'PackagingList'
      BEGIN
        WITH WorkOrder AS (
           SELECT
                mph.RankSrNo AS RankNo,
                mph.WorkOrderNo AS WorkOrderNo,
                mph.AssignedDate AS ScheduledDate,
                hdr.Dealer,
                mph.PackagingStatus,
                mph.PackagingFinalDate,
                mpa.ID AS DetailedID,
                mpd.ProductName,
                mpd.Size,
                mpd.TotalQty AS totQty,
                mpd.SqFeet AS SqFeet,
               
                mpd.HeaderID AS ProductionID,


                ISNULL(SUM(CAST(mpa.CompletedQty as decimal)),0) AS CompletedQty,
                ISNULL(SUM(CAST(mpa.CompletedSqFeet as decimal)),0) AS CompetedSqFeet,

                ISNULL(SUM(CAST(mpa.PackagingQty as decimal)),0) AS PackagingQty,     
                CONVERT(nvarchar(10),MAX(mpa.PackagingDate),105) AS PackagingDate,
                ISNULL(SUM(CAST(mpa.PackagingRevertQty as decimal)),0) AS PackagingRevertQty,
                wdr.UploadedImage as ImageName
            
            FROM tbl_MachineProductionAllocation mpa
            INNER JOIN tbl_MachineProductionDTLS mpd
                ON mpd.ID = mpa.ProductDtlID

            INNER JOIN tbl_MachineProductionHDR mph
                ON mph.ID = mpd.HeaderID

            LEFT JOIN tbl_WorkOrderHdr hdr
                ON hdr.ID = mph.WorkOrderID

            INNER JOIN tbl_WorkOrderDetails wdr
                ON wdr.HeaderID = hdr.ID
               AND wdr.ProductName = mpd.ProductName


            LEFT JOIN tbl_AssignedMachines AM ON AM.MachineId = mpa.MachineID 

            LEFT JOIN tbl_MachineMaster MM ON AM.MachineId = MM.ID  
            WHERE hdr.isdesignapproved = 1 AND MM.AllocatedStage = 'Stage 2' 
            AND mpa.CompletedQty <>0 AND hdr.isproductioncompleted = 0
            AND hdr.IsDeleted = 0 AND hdr.CancelStatus=0 AND hdr.HoldStatus = 0
            GROUP BY   mph.RankSrNo ,
                mph.WorkOrderNo,
                mph.AssignedDate,
                hdr.Dealer,
                mph.PackagingStatus,
                mph.PackagingFinalDate,
                mpa.ID,
                mpd.ProductName,
                mpd.Size,
                mpd.TotalQty,
                mpd.SqFeet,

                mph.S1Status,
                mpd.HeaderID,
                wdr.UploadedImage 
       ),
         NUMBERED AS (SELECT *, ROW_NUMBER() OVER (ORDER BY CASE WHEN RankNo IS NULL THEN 1 ELSE 0 END, RankNo ASC) AS RN
           FROM WorkOrder
       )
        SELECT *
            FROM NUMBERED
            WHERE @ShowRecords = 0
                  OR RN <= @ShowRecords
            ORDER BY CASE
                         WHEN RankNo IS NULL THEN
                             1
                         ELSE
                             0
                     END,
                     RankNo ASC
      END

     IF @SP_Action = 'GetDeliveryList'
      BEGIN 
         WITH WorkOrderMaster
			AS (
			    SELECT ID,TallyRefNo,CONVERT(nvarchar(10),WorkOrderDate,105) AS WorkOrderDate,DeliveredDate as OrderDelivered,
                CONVERT(nvarchar(10),DeliveryDate,105) AS DeliveryDate,DeliveryDate AS OgForDate,LRUplodedDate AS OgForLRUplodedDate,
                CONVERT(nvarchar(10),LRUplodedDate,105) AS LRUplodedDate,Dealer,CustomerName,isdesignapproved
                ,AttachmentPath,IsDispatched,isproductioncompleted,IsAllCompleted,AttachmentLR,InvoiceAttached
				FROM tbl_WorkOrderHdr WHERE IsDeleted = 0  AND CancelStatus=0 AND HoldStatus = 0
                   AND isproductioncompleted = 1 
                    AND
					   (
							@Remark IS NULL
						 OR @Remark = ''
						 OR (@Remark = 'Ready to Dispatch' AND IsDispatched = 0 AND IsAllCompleted IS NULL AND DeliveredDate IS NULL)
						 OR (@Remark = 'Dispatched' AND IsDispatched = 1 AND IsAllCompleted IS NULL AND DeliveredDate IS NULL)
						 OR (@Remark = 'Out For Delivery' AND IsAllCompleted = 1)
						 OR (@Remark = 'Delivered' AND DeliveredDate IS NOT NULL)
					   )
			       AND (
				        @ProductName = ''
                       OR TallyRefNo LIKE '%'+ @ProductName + '%'
					   OR Dealer LIKE '%'+ @ProductName + '%'
					   OR CustomerName LIKE '%'+ @ProductName + '%'
			          )
			   ),NUMBERED
		AS (
			SELECT *
				,ROW_NUMBER() OVER (
					ORDER BY Id DESC
					) AS RN
			FROM WorkOrderMaster
			)
		SELECT *
		FROM NUMBERED
		WHERE @ShowRecords = 0
			OR RN <= @ShowRecords
		ORDER BY ID DESC
      END

     IF @SP_Action = 'IsDipatchedStatus'
      BEGIN 
        UPDATE tbl_WorkOrderHdr SET IsDispatched = 1,DispatchedDate =GETDATE() WHERE ID = @Id
      END

     IF @SP_Action = 'IsDeliveredDate'
      BEGIN 
        UPDATE tbl_WorkOrderHdr SET DeliveredDate =GETDATE() WHERE ID = @Id
      END

     IF @SP_Action = 'IsCompletedStatus'
      BEGIN 
        UPDATE tbl_WorkOrderHdr SET IsAllCompleted = 1,AttachmentLR = @IsLRAttached,IsLRAttached = 1,DeliveryRemark=@Remark
        ,LRUplodedBy=@MachineID,LRUplodedDate= GETDATE(),InvoiceAttached=@IsInvoiceAttached WHERE ID = @Id
      END

     IF @SP_Action = 'PackagingListnew'
      BEGIN
         WITH WorkOrder AS 
        (
            SELECT
                mph.RankSrNo AS RankNo,
                mph.WorkOrderNo AS WorkOrderNo,
                mph.AssignedDate AS ScheduledDate,
                hdr.Dealer,
                mph.PackagingStatus,
                mph.PackagingFinalDate,

                MAX(mpa.ID) AS DetailedID,

                mpd.ProductName,
                mpd.Size,

                mpd.TotalQty AS totQty,
                mpd.SqFeet AS SqFeet,

                mpd.HeaderID AS ProductionID,

                CASE 
                    WHEN ISNULL(SUM(CAST(mpa.CompletedQty AS DECIMAL(18,2))),0) > mpd.TotalQty
                    THEN mpd.TotalQty
                    ELSE ISNULL(SUM(CAST(mpa.CompletedQty AS DECIMAL(18,2))),0)
                END AS CompletedQty,


                CASE 
                    WHEN ISNULL(SUM(CAST(mpa.CompletedSqFeet AS DECIMAL(18,2))),0) > mpd.SqFeet
                    THEN mpd.SqFeet
                    ELSE ISNULL(SUM(CAST(mpa.CompletedSqFeet AS DECIMAL(18,2))),0)
                END AS CompetedSqFeet,


                CASE 
                    WHEN ISNULL(SUM(CAST(mpa.PackagingQty AS DECIMAL(18,2))),0) > mpd.TotalQty
                    THEN mpd.TotalQty
                    ELSE ISNULL(SUM(CAST(mpa.PackagingQty AS DECIMAL(18,2))),0)
                END AS PackagingQty,


                CONVERT(NVARCHAR(10), MAX(mpa.PackagingDate), 105) AS PackagingDate,


                ISNULL(SUM(CAST(mpa.PackagingRevertQty AS DECIMAL(18,2))),0) AS PackagingRevertQty,


                MAX(wdr.UploadedImage) AS ImageName


            FROM tbl_MachineProductionAllocation mpa


            INNER JOIN tbl_MachineProductionDTLS mpd
                ON mpd.ID = mpa.ProductDtlID


            INNER JOIN tbl_MachineProductionHDR mph
                ON mph.ID = mpd.HeaderID


            LEFT JOIN tbl_WorkOrderHdr hdr
                ON hdr.ID = mph.WorkOrderID


            INNER JOIN tbl_WorkOrderDetails wdr
                ON wdr.HeaderID = hdr.ID
                AND wdr.ProductName = mpd.ProductName


            -- Removed tbl_AssignedMachines join because it was duplicating rows
            INNER JOIN tbl_MachineMaster MM
                ON MM.ID = mpa.MachineID



            WHERE 
                hdr.isdesignapproved = 1

                AND MM.AllocatedStage = 'Stage 2'

                AND mpa.StageName = 'Stage 2'

                AND hdr.CancelStatus=0 AND hdr.HoldStatus = 0

                AND ISNULL(mpa.CompletedQty,0) > 0

                AND mph.PackagingStatus IS NULL

                --AND ISNULL(hdr.isproductioncompleted,0) = 1

                AND hdr.IsDeleted = 0



            GROUP BY
                mph.RankSrNo,
                mph.WorkOrderNo,
                mph.AssignedDate,
                hdr.Dealer,
                mph.PackagingStatus,
                mph.PackagingFinalDate,
                mpd.ProductName,
                mpd.Size,
                mpd.TotalQty,
                mpd.SqFeet,
                mpd.HeaderID
        ),


        NUMBERED AS
        (
            SELECT *,
                ROW_NUMBER() OVER
                (
                    ORDER BY 
                        CASE 
                            WHEN RankNo IS NULL THEN 1 
                            ELSE 0 
                        END,
                        RankNo ASC
                ) AS RN
            FROM WorkOrder
        )


        SELECT *
        FROM NUMBERED

        WHERE 
            @ShowRecords = 0
            OR RN <= @ShowRecords


        ORDER BY
            CASE 
                WHEN RankNo IS NULL THEN 1 
                ELSE 0 
            END,
            RankNo ASC;
      END
END


-- Script for SP_DealerMaster
GO
CREATE PROCEDURE [dbo].[SP_DealerMaster]
     @ShowRecords INT = 0
	,@Id int =0
	,@UserCode NVARCHAR(100) = NULL
	,@FullName NVARCHAR(500) = NULL
	,@CompanyName NVARCHAR(500) = NULL
	,@MobileNo NVARCHAR(100) = NULL
	,@EmialId NVARCHAR(100) = NULL
	,@Password NVARCHAR(100) = NULL
	,@Type NVARCHAR(100) =NULL
	,@GstNo NVARCHAR(100) =NULL
	,@PanCardNo NVARCHAR(100) =NULL
	,@UANNo NVARCHAR(100) =NULL
	,@BillAddress NVARCHAR(max) =NULL
	,@BillArea NVARCHAR(max) =NULL
	,@BillPinCode NVARCHAR(100) =NULL
	,@BillState NVARCHAR(100) =NULL
	,@BillCity NVARCHAR(100) =NULL
	,@BillCountry NVARCHAR(100) = NULL
	,@ShipAddress NVARCHAR(max) =NULL
	,@ShipArea NVARCHAR(max) =NULL
	,@ShipPinCode NVARCHAR(100) =NULL
	,@ShipState NVARCHAR(100) =NULL
	,@ShipCity NVARCHAR(100) =NULL
	,@ShipCountry NVARCHAR(100) = NULL
	,@UserRole NVARCHAR(100) = NULL
	,@RelationId NVARCHAR(100) = NULL
	,@IsActive NVARCHAR(100) = NULL
	,@IsDeleted NVARCHAR(100) = NULL
	,@ActionBy NVARCHAR(100) = NULL
	,@SP_Action NVARCHAR(100) = NULL
	AS 
	BEGIN
	  IF @SP_Action = 'DealerList'
	   BEGIN
		   WITH UserMaster
			AS (
			    SELECT UM.ID AS ID,UserCode,FullName,CompanyName,EmailId,IsActivate,LoginPass FROM tbl_UserMaster UM 
				INNER JOIN tbl_RoleMaster RM ON RM.Roles = UM.UserRole 
				WHERE UM.IsDeleted = 0 AND RM.Departments = 'Outsourcing'
			       AND (
				    @FullName = '' 
					OR FullName LIKE '%' + @FullName + '%'
					OR UserCode LIKE '%' + @FullName + '%'
					OR CompanyName LIKE '%' + @FullName + '%'
					OR EmailId LIKE '%' + @FullName + '%'
					OR LoginPass LIKE '%' + @FullName + '%'

						--FullName LIKE CASE 
						--	WHEN @FullName != ''
						--		THEN @FullName
						--	ELSE '%%'
						--	END
			          )
			   ),NUMBERED
		AS (
			SELECT *
				,ROW_NUMBER() OVER (
					ORDER BY Id DESC
					) AS RN
			FROM UserMaster
			)
		SELECT *
		FROM NUMBERED
		WHERE @ShowRecords = 0
			OR RN <= @ShowRecords
		ORDER BY ID DESC
	   END

	  IF @SP_Action = 'DealerListById'
	   BEGIN
		  SELECT * FROM tbl_UserMaster WHERE ID = @Id
	   END

      IF @SP_Action = 'CheckEmialId'
	   BEGIN
	     SELECT EmailId FROM tbl_UserMaster WHERE IsDeleted=0 AND EmailId =@EmialId
 	   END
	 
	  IF @SP_Action = 'InsertDealer'
	   BEGIN
	     INSERT INTO tbl_UserMaster (
			UserCode
			,FullName
			,CompanyName
			,MobileNo
			,EmailId
			,LoginPass
			,Type
			,GstNo
			,PanCardNo
			,UANNo
			,BillAddress
			,BillArea
			,BillPinCode
			,BillState
			,BillCity
			,BillCountry
			,ShipAddress
			,ShipArea
			,ShipPinCode
			,ShipState
			,ShipCity
			,ShipCountry
			,UserRole
			,IsActivate
			,IsDeleted
			,CreatedOn
			,CreatedBy
			)
		VALUES (
			dbo.FN_GenerateUserCode()
			,@FullName
			,@CompanyName
			,@MobileNo
			,@EmialId
			,@Password
			,@Type
			,@GstNo
			,@PanCardNo
			,@UANNo
			,@BillAddress
			,@BillArea
			,@BillPinCode
			,@BillState
			,@BillCity
			,@BillCountry
			,@ShipAddress
			,@ShipArea
			,@ShipPinCode
			,@ShipState
			,@ShipCity
			,@ShipCountry
			,@UserRole	
			,1
			,0
			,GETDATE()
			,@ActionBy
			)
	   END

      IF @SP_Action = 'UpdateDealer'
	   BEGIN
	    UPDATE tbl_UserMaster
		SET FullName = @FullName
		    ,CompanyName = @CompanyName
			,MobileNo = @MobileNo
			,EmailId = @EmialId
			,LoginPass = @Password
			,Type = @Type
			,GstNo=@GstNo
			,PanCardNo = @PanCardNo
			,UANNo = @UANNo
			,BillAddress= @BillAddress
			,BillArea = @BillArea
			,BillPinCode = @BillPinCode
			,BillState = @BillState
			,BillCity =@BillCity
			,BillCountry=@BillCountry
			,ShipAddress= @ShipAddress
			,ShipArea = @ShipArea
			,ShipPinCode = @ShipPinCode
			,ShipState = @ShipState
			,ShipCity = @ShipCity
			,ShipCountry = @ShipCountry
			,UserRole=@UserRole
			,UpdatedBy = @ActionBy
			,UpdatedOn = GETDATE()
		WHERE ID = @Id
	   END

      IF (@SP_Action = 'DeleteDealer')
		BEGIN
			UPDATE tbl_UserMaster
			SET IsDeleted = 1
			WHERE ID = @Id
		END

      IF(@SP_Action = 'RoleListForDealer')
		BEGIN
		  SELECT * FROM tbl_RoleMaster WHERE IsDeleted = 0 AND Departments='Outsourcing' ORDER BY ID DESC
		END
	END

-- Script for SP_StageMaster
GO
CREATE PROCEDURE [dbo].[SP_StageMaster]
	 @ShowRecords INT = 0
	,@Id int =0
	,@SatgeName nvarchar(500) = null
	,@SatgeDescription nvarchar(MAX) = null
	,@SatgeCapacity nvarchar(100) = null
	,@CapacityUnit nvarchar(100) = null
	,@IsDeleted bit  = 0
	,@ActionBy nvarchar(500)= null
	,@SP_Action nvarchar(500) = null
AS
BEGIN
  IF @SP_Action = 'GetStageList'
   BEGIN
      WITH StageMaster
			AS (
			    SELECT * FROM tbl_StageMaster WHERE IsDeleted = 0 
			       AND (
				         @SatgeName = '' 
						OR SatgeName LIKE '%' + @SatgeName + '%'
						OR SatgeDescription LIKE '%' + @SatgeName + '%'
						OR SatgeCapacity LIKE '%' + @SatgeName + '%'
						OR CapacityUnit LIKE '%' + @SatgeName + '%'
						--SatgeName LIKE CASE 
						--	WHEN @SatgeName != ''
						--		THEN @SatgeName
						--	ELSE '%%'
						--	END
			          )
			   ),NUMBERED
		AS (
			SELECT *
				,ROW_NUMBER() OVER (
					ORDER BY ID DESC
					) AS RN
			FROM StageMaster
			)
		SELECT *
		FROM NUMBERED
		WHERE @ShowRecords = 0
			OR RN <= @ShowRecords
		ORDER BY ID DESC
   END

  IF @SP_Action = 'StageListById'
	   BEGIN
		  SELECT * FROM tbl_StageMaster WHERE ID = @Id
	   END
	 
  IF @SP_Action = 'InsertStage'
	   BEGIN
	     INSERT INTO tbl_StageMaster (
			 SatgeName
			,SatgeDescription
			,SatgeCapacity
			,CapacityUnit
			,IsDeleted
			,CreatedBy
			,CreatedOn
			)
		VALUES (
			@SatgeName
			,@SatgeDescription
			,@SatgeCapacity
			,@CapacityUnit
			,0
			,@ActionBy
			,GETDATE()
			)
	   END

  IF @SP_Action = 'UpdateStage'
	   BEGIN
	    UPDATE tbl_StageMaster
		SET SatgeName = @SatgeName
		    ,SatgeDescription = @SatgeDescription
			,SatgeCapacity = @SatgeCapacity
			,CapacityUnit = @CapacityUnit
			,UpdatedBy = @ActionBy
			,UpdatedOn = GETDATE()
		WHERE ID = @Id
	   END
	   
  IF (@SP_Action = 'DeleteStage')
		BEGIN
			UPDATE tbl_StageMaster
			SET IsDeleted = 1
			WHERE ID = @Id
		END
END





-- Script for SP_MachineMaster
GO
CREATE PROCEDURE [dbo].[SP_MachineMaster]
  @ShowRecords INT = 0
 ,@Id int =0
 ,@MachineName nvarchar(max)= null
 ,@MachineDescription nvarchar(max)= null
 ,@MachinePerHRQty nvarchar(100) =null
 ,@MachineRunningHR nvarchar(10)= null
 ,@MachineImageName nvarchar(max)= null
 ,@AllocatedStage nvarchar(10)= null
 ,@IsActive bit = 0
 ,@IsActivateDate datetime = null
 ,@IsDeactiveDate datetime = null
 ,@ActionBy nvarchar(100) =null
 ,@SP_Action nvarchar(100) = null
AS
BEGIN
      IF @SP_Action = 'MachineList'
	   BEGIN
		   WITH MachineMaster
			AS (
			    SELECT ID,MachineName,MachineDescription,MachinePerHRQty,MachineRunningHR,AllocatedStage,IsActive,IsActivateDate,IsDeactiveDate,MachineImageName
				FROM tbl_MachineMaster WHERE IsDeleted = 0 
			       AND (
				         @MachineName = '' 
							OR MachineName LIKE '%' + @MachineName + '%'
							OR AllocatedStage LIKE '%' + @MachineName + '%'
							OR MachineDescription LIKE '%' + @MachineName + '%'
							OR MachinePerHRQty LIKE '%' + @MachineName + '%'
						    OR MachineRunningHR LIKE '%' + @MachineName + '%'
				       
						--MachineName LIKE CASE 
						--	WHEN @MachineName != ''
						--		THEN @MachineName
						--	ELSE '%%'
						--	END
			          )
			   ),NUMBERED
		AS (
			SELECT *
				,ROW_NUMBER() OVER (
					ORDER BY Id DESC
					) AS RN
			FROM MachineMaster
			)
		SELECT *
		FROM NUMBERED
		WHERE @ShowRecords = 0
			OR RN <= @ShowRecords
		ORDER BY ID DESC
	   END

	  IF @SP_Action = 'MachineListById'
	   BEGIN
		  SELECT * FROM tbl_MachineMaster WHERE ID = @Id
	   END
	 
	  IF @SP_Action = 'InsertMachine'
	   BEGIN
	      DECLARE @SCOPEID nvarchar(100) = NULL;
	     INSERT INTO tbl_MachineMaster (
			 MachineName
			,MachineDescription
			,MachinePerHRQty
			,MachineRunningHR
			,AllocatedStage
			,MachineImageName
			,IsActive
			,IsActivateDate
			,IsDeleted
			,CreatedBy
			,CreatedOn
			)
		VALUES (
			 @MachineName
			,@MachineDescription
			,@MachinePerHRQty
			,@MachineRunningHR
			,@AllocatedStage
			,@MachineImageName
			,1
			,GETDATE()
			,0
			,@ActionBy
			,GETDATE()
			)
			SET @SCOPEID = SCOPE_IDENTITY()
	     INSERT INTO tbl_MachineCapacityLog(MachineID,MachinePerHRCap,MachineHRQt,CreatedOn,CreatedBy)
		   VALUES(@SCOPEID,@MachineRunningHR,@MachinePerHRQty,GETDATE(),@ActionBy)
	   END

      IF @SP_Action = 'UpdateMachine'
	   BEGIN
	   DECLARE @MachineHrQty INT = 0,@MachineCapacity INT = 0;

	   SELECT @MachineHrQty = ISNULL(TRY_CAST(MachinePerHRQty as int),0) FROM tbl_MachineMaster WHERE ID=@Id
 	   SELECT @MachineCapacity = ISNULL(TRY_CAST(MachineRunningHR as int),0) FROM tbl_MachineMaster WHERE ID=@Id

	   IF(@MachineHrQty != CAST(@MachinePerHRQty as int) OR @MachineCapacity!= CAST(@MachineRunningHR as int))
		BEGIN
		  INSERT INTO tbl_MachineCapacityLog(MachineID,MachinePerHRCap,MachineHRQt,CreatedOn,CreatedBy)
		   VALUES(@ID,@MachineRunningHR,@MachinePerHRQty,GETDATE(),@ActionBy)
		END

	    UPDATE tbl_MachineMaster
		SET MachineName = @MachineName
		    ,MachineDescription = @MachineDescription
			,MachinePerHRQty = @MachinePerHRQty
			,MachineRunningHR = @MachineRunningHR
			,MachineImageName = @MachineImageName
			,AllocatedStage = @AllocatedStage
			,UpdatedBy = @ActionBy
			,UpdatedOn = GETDATE()
		WHERE ID = @Id
	   END

      IF (@SP_Action = 'DeleteMachine')
		BEGIN
			UPDATE tbl_MachineMaster
			SET IsDeleted = 1
			WHERE ID = @Id
		END

      IF(@SP_Action = 'StageList')
		BEGIN
		  SELECT * FROM tbl_StageMaster WHERE IsDeleted = 0 ORDER BY ID DESC
		END
END




-- Script for Sp_TransporterMaster
GO
CREATE PROCEDURE [dbo].[Sp_TransporterMaster]
(
    @transporter_code NVARCHAR(20) = Null ,
    @transporter_name NVARCHAR(100) = Null,
    @gst_no NVARCHAR(20) = Null,
    @pan_no NVARCHAR(20) = Null,
    @contact_person NVARCHAR(100) = Null,
    @mobile NVARCHAR(15) = Null,
    @email NVARCHAR(100) = Null,
    @ActionBy NVARCHAR(100) = Null,
    @address NVARCHAR(MAX) = Null,
    @city NVARCHAR(50) = Null,
    @state NVARCHAR(50) = Null,
    @pincode NVARCHAR(10) = Null,
    @vehicle_type NVARCHAR(50) = Null,
    @rate_per_km DECIMAL(10,2) = Null,
    @service_route NVARCHAR(200) = Null,
    @bank_name NVARCHAR(100) = Null,
    @account_no NVARCHAR(30) = Null,
    @ifsc_code NVARCHAR(20) = Null,
    @status NVARCHAR(10) = Null,
    @SP_Action NVARCHAR(20) = Null,
    @ShowRecords INT = 0,
    @id Bigint = 0
)
AS
BEGIN

    SET NOCOUNT ON;

     IF(@SP_Action='InsertDealer')

    BEGIN

    INSERT INTO tbl_Transportermaster
    (
        transporter_code,
        transporter_name,
        gst_no,
        pan_no,

        contact_person,
        mobile,
        email,

        address,
        city,
        state,
        pincode,

        vehicle_type,
        rate_per_km,

       

        bank_name,
        account_no,
        ifsc_code,

        status,
        serviceRoute,
        IsDeleted,
        CreatedBy,
        CreatedOn
    )
    VALUES
    (
        @transporter_code,
        @transporter_name,
        @gst_no,
        @pan_no,

        @contact_person,
        @mobile,
        @email,

        @address,
        @city,
        @state,
        @pincode,

        @vehicle_type,
        @rate_per_km,

       

        @bank_name,
        @account_no,
        @ifsc_code,

        1,
        @service_route,
        0,
        @ActionBy,
        GETDATE()
    );
    END

     IF (@SP_Action = 'TransporterList')
    BEGIN

        WITH CTE_Transporter AS
        (
            SELECT *
            FROM tbl_Transportermaster
            WHERE IsDeleted = 0
            AND (@transporter_name IS NULL OR transporter_name LIKE '%' + @transporter_name + '%')
            AND (@city IS NULL OR city LIKE '%' + @city + '%')
            AND (@mobile IS NULL OR mobile LIKE '%' + @mobile + '%')
            AND (@status IS NULL OR status = @status)
        ),

        CTE_Numbered AS
        (
            SELECT *,
                   ROW_NUMBER() OVER (ORDER BY id DESC) AS RN
            FROM CTE_Transporter
        )

        SELECT *
        FROM CTE_Numbered
        WHERE @ShowRecords = 0 OR RN <= @ShowRecords
        ORDER BY id DESC;

END

     IF(@SP_Action ='GetByTransporterbyId')
     BEGIN
      select * from tbl_Transportermaster where id = @id and IsDeleted = 0 
     END

     IF (@SP_Action = 'UpdateTransporter')
      BEGIN
          UPDATE tbl_Transportermaster
    SET
        transporter_code = @transporter_code,
        transporter_name = @transporter_name,
        gst_no = @gst_no,
        pan_no = @pan_no,
        contact_person = @contact_person,
        mobile = @mobile,
        email = @email,
        address = @address,
        city = @city,
        state = @state,
        pincode = @pincode,
        vehicle_type = @vehicle_type,
        rate_per_km = @rate_per_km,
        bank_name = @bank_name,
        account_no = @account_no,
        ifsc_code = @ifsc_code,
        serviceRoute = @service_route,
        UpdatedBy = @ActionBy,
        UpdatedOn = GETDATE()

     WHERE id = @Id
         AND IsDeleted = 0;
       END

    IF (@SP_Action = 'DeleteTransporter')
     BEGIN

    UPDATE tbl_Transportermaster
    SET IsDeleted = 1
    WHERE id = @Id;

END
END

-- Script for SP_RawMaterialMaster
GO
CREATE PROCEDURE [dbo].[SP_RawMaterialMaster]
 @ShowRecords INT = 0
,@Id int =0
,@SupplierName nvarchar(500)= null
,@PurchaseNo nvarchar(500) =null
,@PurchaseDate datetime =null
,@HeaderId nvarchar(20) =null
,@RawMaterialName nvarchar(200)= null
,@RawMaterialCode nvarchar(100) =null
,@RawMaterialCategory nvarchar(200) =null
,@RawMaterialDesc nvarchar(max) =null
,@RawMaterialQty nvarchar(20) =null
,@Unit nvarchar(20)= null
,@PerQtyRate nvarchar(20)= null
,@GstPercentage nvarchar(20)= null
,@GstAmount nvarchar(20)= null
,@ActionBy NVARCHAR(100) = NULL
,@SP_Action NVARCHAR(100) = NULL
,@Result INT OUTPUT 
AS 
BEGIN
     -- HDR Table
  	  IF @SP_Action = 'RawMatHDRList'
	   BEGIN
		 WITH RawMaterialMaster
			AS (
			    SELECT ID,SupplierName,PurchaseNo,CONVERT(nvarchar(10),PurchaseDate,105) AS PurchaseDate FROM tbl_RawMaterial_HDR WHERE IsDeleted = 0  
			       AND (
				         @PurchaseNo = '' 
							OR SupplierName LIKE '%' + @PurchaseNo + '%'
							OR PurchaseNo LIKE '%' + @PurchaseNo + '%'
							
						--PurchaseNo LIKE CASE 
						--	WHEN @PurchaseNo != ''
						--		THEN @PurchaseNo
						--	ELSE '%%'
						--	END
			          )
			   ),NUMBERED
		AS (
			SELECT *
				,ROW_NUMBER() OVER (
					ORDER BY Id DESC
					) AS RN
			FROM RawMaterialMaster
			)
		SELECT *
		FROM NUMBERED
		WHERE @ShowRecords = 0
			OR RN <= @ShowRecords
		ORDER BY ID DESC
		 SET @Result = 0
	   END

	  IF @SP_Action = 'RawMatHDRListById'
	   BEGIN
		  SELECT * FROM tbl_RawMaterial_HDR WHERE ID = @Id
		  SET @Result = @Id
	   END
	 
	  IF @SP_Action = 'InsertRawMatHDR'
	   BEGIN
	     INSERT INTO tbl_RawMaterial_HDR (
			 SupplierName
			,PurchaseNo
			,PurchaseDate
			,IsActive
			,IsDeleted
			,CreatedBy
			,CreatedOn
			)
		VALUES (
			 @SupplierName
            ,@PurchaseNo
			,@PurchaseDate
			,1
			,0
			,@ActionBy
			,GETDATE()
			)
        SET @Result = SCOPE_IDENTITY()
	   END

      IF @SP_Action = 'UpdateRawMatHDR'
	   BEGIN
	    UPDATE tbl_RawMaterial_HDR
		SET SupplierName =@SupplierName
			,PurchaseNo = @PurchaseNo
			,PurchaseDate = @PurchaseDate
			,IsActive = 1
			,UpdatedBy = @ActionBy
			,UpdatedOn = GETDATE()
		WHERE ID = @Id
		SET @Result = @Id
	   END

      IF (@SP_Action = 'DeleteRawMatHDR')
		BEGIN
			UPDATE tbl_RawMaterial_HDR
			SET IsDeleted = 1
			WHERE ID = @Id
			SET @Result = @Id
		END

     -- DTLS Table
      IF @SP_Action = 'RawMatDTLSListById'
	   BEGIN
	     SELECT * FROM tbl_RawMaterial_DTLS WHERE HeaderId =@Id
		 SET @Result = @Id
 	   END 
     
      IF @SP_Action = 'InsertRawMatDTLS'
	   BEGIN
	     INSERT INTO tbl_RawMaterial_Dtls (
			 HeaderId
			,RawMaterialName
			,RawMaterialCode
			,RawMaterialCategory
			,RawMaterialDesc
			,RawMaterialQty
			,Unit
			,PerQtyRate
			,GstPercentage
			,GstAmount
			)
		VALUES (
			 @HeaderId
            ,@RawMaterialName
			,@RawMaterialCode
			,@RawMaterialCategory
			,@RawMaterialDesc
			,@RawMaterialQty
			,@Unit
			,@PerQtyRate
			,@GstPercentage
			,@GstAmount
			)
			 SET @Result = SCOPE_IDENTITY()
	   END
      
	  IF (@SP_Action = 'DeleteRawMatDTLS')
		BEGIN
			DELETE tbl_RawMaterial_Dtls WHERE HeaderId = @Id
			SET @Result = @Id
		END
END










































-- Script for SP_Reports
GO
CREATE PROCEDURE [dbo].[SP_Reports]
    @ShowRecords INT = 0,
    @ID INT = 0,
    @SP_Action NVARCHAR(100) = NULL,
    @ProductName NVARCHAR(max) = NULL,
     @MachineName NVARCHAR(100) = NULL,
     @DeliveryStatus  NVARCHAR(100) = NULL,
     @DealerName NVARCHAR(200) = NULL,
     @State NVARCHAR(100) = NULL,
     @DispatchStatus  NVARCHAR(100) = NULL
     

AS
BEGIN
--    IF @SP_Action = 'ProductionsTrackingReports'
--    BEGIN
       

--;WITH FinalResult AS
--(
--    SELECT
--        MDtls.ID AS ID,
--        hdr.ID AS WorkOrderID,
--        hdr.SeriesNo AS WorkOrderNo,
--        hdr.TallyRefNo,
--        MDtls.ProductName,
--        MDtls.Size,

--        TRY_CAST(MDtls.TotalQty AS DECIMAL(18,2)) AS TotalQty,

--        mch.S1Status,
--        mch.S2Status,
--        mch.PackagingStatus,
--        mch.AssignedDate,

--        ROW_NUMBER() OVER
--        (
--            PARTITION BY
--                hdr.SeriesNo,
--                hdr.TallyRefNo,
--                MDtls.ProductName,
--                MDtls.Size
--            ORDER BY MDtls.ID
--        ) AS RN

--    FROM tbl_WorkOrderHdr hdr

--    INNER JOIN tbl_WorkOrderDetails Dtls
--        ON hdr.ID = Dtls.HeaderID

--    INNER JOIN tbl_machineproductionhdr mch
--        ON mch.WorkOrderID = hdr.ID

--    INNER JOIN tbl_MachineProductionDTLS MDtls
--        ON MDtls.HeaderID = mch.ID
--),


--AllocationCTE AS
--(
--    SELECT

--        MPA.ProductDtlID,


--        STUFF
--        (
--            (
--                SELECT ', ' + X.StageName
--                FROM
--                (
--                    SELECT DISTINCT

--                    CASE 

--                        WHEN ISNULL(MPA2.PackagingQty,0) >
--                             ISNULL(MPA2.PackagingRevertQty,0)

--                        AND ISNULL(MPA2.PackagingQty,0) > 0

--                        THEN 'Packaging'


--                        WHEN ISNULL(MPA2.CompletedQty,0) <
--                             ISNULL(MPA2.AllocatedQty,0)

--                        THEN LTRIM(RTRIM(MM2.AllocatedStage))

--                    END AS StageName,


--                    CASE

--                        WHEN ISNULL(MPA2.PackagingQty,0) > 0
--                        THEN 99

--                        ELSE TRY_CAST
--                        (
--                            REPLACE
--                            (
--                                LOWER(MM2.AllocatedStage),
--                                'stage ',
--                                ''
--                            ) AS INT
--                        )

--                    END AS SortOrder


--                    FROM tbl_MachineProductionAllocation MPA2

--                    INNER JOIN tbl_MachineMaster MM2
--                        ON MM2.ID = MPA2.MachineID

--                    WHERE MPA2.ProductDtlID = MPA.ProductDtlID

--                ) X

--                WHERE X.StageName IS NOT NULL

--                ORDER BY X.SortOrder

--                FOR XML PATH('')
--            ),1,2,''
--        ) AS AllocatedStage,


--        STUFF
--        (
--            (
--                SELECT DISTINCT ', ' + MM2.MachineName

--                FROM tbl_MachineProductionAllocation MPA2

--                INNER JOIN tbl_MachineMaster MM2
--                    ON MM2.ID = MPA2.MachineID

--                WHERE MPA2.ProductDtlID = MPA.ProductDtlID

--                FOR XML PATH('')
--            ),1,2,''
--        ) AS MachineNames,


--        SUM(CASE WHEN MM.MachineName='Machine 1'
--        THEN CAST(MPA.AllocatedQty AS DECIMAL(18,2))
--        ELSE 0 END) AS Machine1Qty,


--        SUM(CASE WHEN MM.MachineName='Machine 1'
--        THEN CAST(MPA.CompletedQty AS DECIMAL(18,2))
--        ELSE 0 END) AS Machine1CompletedQty,


--        SUM(CASE WHEN MM.MachineName='Machine 1'
--        THEN CAST(MPA.CompletedSqFeet AS DECIMAL(18,2))
--        ELSE 0 END) AS Machine1CompletedSqFeet,


--        SUM(CASE WHEN MM.MachineName='Machine 2'
--        THEN CAST(MPA.AllocatedQty AS DECIMAL(18,2))
--        ELSE 0 END) AS Machine2Qty,


--        SUM(CASE WHEN MM.MachineName='Machine 2'
--        THEN CAST(MPA.CompletedQty AS DECIMAL(18,2))
--        ELSE 0 END) AS Machine2CompletedQty,


--        SUM(CASE WHEN MM.MachineName='Machine 2'
--        THEN CAST(MPA.CompletedSqFeet AS DECIMAL(18,2))
--        ELSE 0 END) AS Machine2CompletedSqFeet,


--        SUM(CASE WHEN MM.MachineName='Machine 3'
--        THEN CAST(MPA.AllocatedQty AS DECIMAL(18,2))
--        ELSE 0 END) AS Machine3Qty,


--        SUM(CASE WHEN MM.MachineName='Machine 3'
--        THEN CAST(MPA.CompletedQty AS DECIMAL(18,2))
--        ELSE 0 END) AS Machine3CompletedQty,


--        SUM(CASE WHEN MM.MachineName='Machine 3'
--        THEN CAST(MPA.CompletedSqFeet AS DECIMAL(18,2))
--        ELSE 0 END) AS Machine3CompletedSqFeet,


--        SUM(ISNULL(CAST(MPA.PackagingQty AS DECIMAL(18,2)),0))
--        AS PackagingQty,


--        MAX(MPA.PackagingDate)
--        AS PackagingDate,


--        SUM(ISNULL(CAST(MPA.PackagingRevertQty AS DECIMAL(18,2)),0))
--        AS PackagingRevertQty


--    FROM tbl_MachineProductionAllocation MPA

--    INNER JOIN tbl_MachineMaster MM
--        ON MM.ID = MPA.MachineID


--    GROUP BY
--        MPA.ProductDtlID
--),


--FinalSum AS
--(
--    SELECT

--        MIN(F.ID) AS ID,

--        MIN(F.WorkOrderID) AS WorkOrderID,

--        F.WorkOrderNo,

--        F.TallyRefNo,

--        F.ProductName,

--        F.Size,


--        MAX(F.AssignedDate) AS AssignedDate,


--        MAX(F.S1Status) AS S1Status,

--        MAX(F.S2Status) AS S2Status,

--        MAX(F.PackagingStatus) AS PackagingStatus,


--        SUM(F.TotalQty) AS TotalQty,


--        SUM(ISNULL(A.Machine1Qty,0)) AS Machine1Qty,

--        SUM(ISNULL(A.Machine1CompletedQty,0)) AS Machine1CompletedQty,

--        SUM(ISNULL(A.Machine1CompletedSqFeet,0)) AS Machine1CompletedSqFeet,


--        SUM(ISNULL(A.Machine2Qty,0)) AS Machine2Qty,

--        SUM(ISNULL(A.Machine2CompletedQty,0)) AS Machine2CompletedQty,

--        SUM(ISNULL(A.Machine2CompletedSqFeet,0)) AS Machine2CompletedSqFeet,


--        SUM(ISNULL(A.Machine3Qty,0)) AS Machine3Qty,

--        SUM(ISNULL(A.Machine3CompletedQty,0)) AS Machine3CompletedQty,

--        SUM(ISNULL(A.Machine3CompletedSqFeet,0)) AS Machine3CompletedSqFeet,


--        SUM(ISNULL(A.PackagingQty,0)) AS PackagingQty,


--        MAX(A.PackagingDate) AS PackagingDate,


--        SUM(ISNULL(A.PackagingRevertQty,0)) AS PackagingRevertQty,


--        MAX(A.MachineNames) AS MachineNames,

--        MAX(A.AllocatedStage) AS AllocatedStage


--    FROM FinalResult F


--    LEFT JOIN AllocationCTE A

--        ON A.ProductDtlID = F.ID


--    WHERE F.RN = 1


--    GROUP BY

--        F.WorkOrderNo,

--        F.TallyRefNo,

--        F.ProductName,

--        F.Size
--)



--SELECT


--    ID,

--    WorkOrderNo,

--    TallyRefNo,

--    ProductName,

--    Size,


--    AssignedDate,


--    MachineNames,

--    AllocatedStage,


--    CASE

--        WHEN AllocatedStage LIKE '%Stage 1%'
--            THEN S1Status

--        WHEN AllocatedStage LIKE '%Stage 2%'
--            THEN S2Status

--        WHEN AllocatedStage LIKE '%Packaging%'
--            THEN PackagingStatus

--        ELSE NULL

--    END AS StageStatus,


--    TotalQty,


--    Machine1Qty,

--    Machine1CompletedQty,

--    Machine1CompletedSqFeet,


--    Machine2Qty,

--    Machine2CompletedQty,

--    Machine2CompletedSqFeet,


--    Machine3Qty,

--    Machine3CompletedQty,

--    Machine3CompletedSqFeet,


--    PackagingQty,

--    PackagingDate,

--    PackagingRevertQty


--FROM FinalSum


--ORDER BY ID
--END
----------------------------------


--;WITH FinalResult AS
--(
--    SELECT
--        MDtls.ID AS ID,
--        hdr.ID AS WorkOrderID,
--        hdr.SeriesNo AS WorkOrderNo,
--        hdr.TallyRefNo,

--        hdr.IsAllCompleted,
--        hdr.DeliveryRemark,
--        hdr.IsLRAttached,

--        MDtls.ProductName,
--        MDtls.Size,

--        TRY_CAST(MDtls.TotalQty AS DECIMAL(18,2)) AS TotalQty,

--        mch.S1Status,
--        mch.S2Status,
--        mch.PackagingStatus,
--        mch.AssignedDate,

--        ROW_NUMBER() OVER
--        (
--            PARTITION BY
--                hdr.SeriesNo,
--                hdr.TallyRefNo,
--                MDtls.ProductName,
--                MDtls.Size
--            ORDER BY MDtls.ID
--        ) AS RN

--    FROM tbl_WorkOrderHdr hdr

--    INNER JOIN tbl_WorkOrderDetails Dtls
--        ON hdr.ID = Dtls.HeaderID

--    INNER JOIN tbl_machineproductionhdr mch
--        ON mch.WorkOrderID = hdr.ID

--    INNER JOIN tbl_MachineProductionDTLS MDtls
--        ON MDtls.HeaderID = mch.ID
--),


--AllocationCTE AS
--(
--    SELECT

--        MPA.ProductDtlID,


--        STUFF
--        (
--            (
--                SELECT ', ' + X.StageName

--                FROM
--                (
--                    SELECT DISTINCT

--                    CASE 

--                        WHEN ISNULL(MPA2.PackagingQty,0) >
--                             ISNULL(MPA2.PackagingRevertQty,0)

--                        AND ISNULL(MPA2.PackagingQty,0) > 0

--                        THEN 'Packaging'


--                        WHEN ISNULL(MPA2.CompletedQty,0) <
--                             ISNULL(MPA2.AllocatedQty,0)

--                        THEN LTRIM(RTRIM(MM2.AllocatedStage))

--                    END AS StageName,


--                    CASE

--                        WHEN ISNULL(MPA2.PackagingQty,0) > 0
--                        THEN 99

--                        ELSE TRY_CAST
--                        (
--                            REPLACE
--                            (
--                                LOWER(MM2.AllocatedStage),
--                                'stage ',
--                                ''
--                            ) AS INT
--                        )

--                    END AS SortOrder


--                    FROM tbl_MachineProductionAllocation MPA2

--                    INNER JOIN tbl_MachineMaster MM2
--                        ON MM2.ID = MPA2.MachineID

--                    WHERE MPA2.ProductDtlID = MPA.ProductDtlID

--                ) X


--                WHERE X.StageName IS NOT NULL

--                ORDER BY X.SortOrder

--                FOR XML PATH('')

--            ),1,2,''

--        ) AS AllocatedStage,


--        STUFF
--        (
--            (
--                SELECT DISTINCT ', ' + MM2.MachineName

--                FROM tbl_MachineProductionAllocation MPA2

--                INNER JOIN tbl_MachineMaster MM2
--                    ON MM2.ID = MPA2.MachineID

--                WHERE MPA2.ProductDtlID = MPA.ProductDtlID

--                FOR XML PATH('')

--            ),1,2,''

--        ) AS MachineNames,


--        SUM(CASE WHEN MM.MachineName='Machine 1'
--        THEN CAST(MPA.AllocatedQty AS DECIMAL(18,2))
--        ELSE 0 END) AS Machine1Qty,


--        SUM(CASE WHEN MM.MachineName='Machine 1'
--        THEN CAST(MPA.CompletedQty AS DECIMAL(18,2))
--        ELSE 0 END) AS Machine1CompletedQty,


--        SUM(CASE WHEN MM.MachineName='Machine 1'
--        THEN CAST(MPA.CompletedSqFeet AS DECIMAL(18,2))
--        ELSE 0 END) AS Machine1CompletedSqFeet,


--        SUM(CASE WHEN MM.MachineName='Machine 2'
--        THEN CAST(MPA.AllocatedQty AS DECIMAL(18,2))
--        ELSE 0 END) AS Machine2Qty,


--        SUM(CASE WHEN MM.MachineName='Machine 2'
--        THEN CAST(MPA.CompletedQty AS DECIMAL(18,2))
--        ELSE 0 END) AS Machine2CompletedQty,


--        SUM(CASE WHEN MM.MachineName='Machine 2'
--        THEN CAST(MPA.CompletedSqFeet AS DECIMAL(18,2))
--        ELSE 0 END) AS Machine2CompletedSqFeet,


--        SUM(CASE WHEN MM.MachineName='Machine 3'
--        THEN CAST(MPA.AllocatedQty AS DECIMAL(18,2))
--        ELSE 0 END) AS Machine3Qty,


--        SUM(CASE WHEN MM.MachineName='Machine 3'
--        THEN CAST(MPA.CompletedQty AS DECIMAL(18,2))
--        ELSE 0 END) AS Machine3CompletedQty,


--        SUM(CASE WHEN MM.MachineName='Machine 3'
--        THEN CAST(MPA.CompletedSqFeet AS DECIMAL(18,2))
--        ELSE 0 END) AS Machine3CompletedSqFeet,


--        SUM(ISNULL(CAST(MPA.PackagingQty AS DECIMAL(18,2)),0))
--        AS PackagingQty,


--        MAX(MPA.PackagingDate)
--        AS PackagingDate,


--        SUM(ISNULL(CAST(MPA.PackagingRevertQty AS DECIMAL(18,2)),0))
--        AS PackagingRevertQty


--    FROM tbl_MachineProductionAllocation MPA

--    INNER JOIN tbl_MachineMaster MM
--        ON MM.ID = MPA.MachineID


--    GROUP BY

--        MPA.ProductDtlID
--),
--FinalSum AS
--(
--    SELECT

--        MIN(F.ID) AS ID,

--        MIN(F.WorkOrderID) AS WorkOrderID,

--        F.WorkOrderNo,

--        F.TallyRefNo,

--        F.ProductName,

--        F.Size,


--        CAST(MAX(CAST(F.IsAllCompleted AS INT)) AS BIT)
--        AS IsAllCompleted,


--        MAX(F.DeliveryRemark)
--        AS DeliveryRemark,


--        CAST(MAX(CAST(F.IsLRAttached AS INT)) AS BIT)
--        AS IsLRAttached,


--        MAX(F.AssignedDate) AS AssignedDate,


--        MAX(F.S1Status) AS S1Status,

--        MAX(F.S2Status) AS S2Status,

--        MAX(F.PackagingStatus) AS PackagingStatus,


--        SUM(F.TotalQty) AS TotalQty,


--        SUM(ISNULL(A.Machine1Qty,0)) AS Machine1Qty,

--        SUM(ISNULL(A.Machine1CompletedQty,0)) AS Machine1CompletedQty,

--        SUM(ISNULL(A.Machine1CompletedSqFeet,0)) AS Machine1CompletedSqFeet,


--        SUM(ISNULL(A.Machine2Qty,0)) AS Machine2Qty,

--        SUM(ISNULL(A.Machine2CompletedQty,0)) AS Machine2CompletedQty,

--        SUM(ISNULL(A.Machine2CompletedSqFeet,0)) AS Machine2CompletedSqFeet,


--        SUM(ISNULL(A.Machine3Qty,0)) AS Machine3Qty,

--        SUM(ISNULL(A.Machine3CompletedQty,0)) AS Machine3CompletedQty,

--        SUM(ISNULL(A.Machine3CompletedSqFeet,0)) AS Machine3CompletedSqFeet,


--        SUM(ISNULL(A.PackagingQty,0)) AS PackagingQty,


--        MAX(A.PackagingDate) AS PackagingDate,


--        SUM(ISNULL(A.PackagingRevertQty,0)) AS PackagingRevertQty,


--        MAX(A.MachineNames) AS MachineNames,


--        MAX(A.AllocatedStage) AS AllocatedStage


--    FROM FinalResult F


--    LEFT JOIN AllocationCTE A

--        ON A.ProductDtlID = F.ID


--    WHERE F.RN = 1


--    GROUP BY

--        F.WorkOrderNo,

--        F.TallyRefNo,

--        F.ProductName,

--        F.Size
--)
--SELECT

--    ID,

--    WorkOrderNo,

--    TallyRefNo,

--    ProductName,

--    Size,


--    IsAllCompleted,

--    DeliveryRemark,

--    IsLRAttached,


--    AssignedDate,


--    MachineNames,

--    AllocatedStage,

--CASE

--    -- If currently in Stage 1 allocation
--    WHEN AllocatedStage LIKE '%Stage 1%'
--    THEN
--        CASE
--            WHEN 
--            (
--                ISNULL(Machine1CompletedQty,0)
--              + ISNULL(Machine2CompletedQty,0)
--              + ISNULL(Machine3CompletedQty,0)
--            ) >= TotalQty
--            THEN 'Stage 1 Completed'
--            ELSE 'Stage 1 Pending'
--        END


--    -- If currently in Stage 2 allocation
--    WHEN AllocatedStage LIKE '%Stage 2%'
--    THEN
--        CASE
--            WHEN 
--            (
--                ISNULL(Machine1CompletedQty,0)
--              + ISNULL(Machine2CompletedQty,0)
--              + ISNULL(Machine3CompletedQty,0)
--            ) >= TotalQty
--            THEN 'Stage 2 Completed'
--            ELSE 'Stage 2 Pending'
--        END


--    -- If currently in Packaging
--    WHEN AllocatedStage LIKE '%Packaging%'
--    THEN
--        CASE
--            WHEN ISNULL(PackagingQty,0) >= TotalQty
--            THEN 'Packaging Completed'
--            ELSE 'Packaging Pending'
--        END


--    -- Dispatch
--    WHEN ISNULL(IsAllCompleted,0)=1
--    THEN 'Dispatched'


--    ELSE 'Pending'

--END AS StageStatus,

--    TotalQty,


--    Machine1Qty,

--    Machine1CompletedQty,

--    Machine1CompletedSqFeet,


--    Machine2Qty,

--    Machine2CompletedQty,

--    Machine2CompletedSqFeet,


--    Machine3Qty,

--    Machine3CompletedQty,

--    Machine3CompletedSqFeet,


--    PackagingQty,

--    PackagingDate,

--    PackagingRevertQty


--FROM FinalSum


--ORDER BY ID;


   IF @SP_Action ='ProductionsReport'
   BEGIN
        SELECT 
        WH.TallyRefNo,
        WH.Dealer,

         STUFF((
            SELECT ', ' + CAST(RN AS VARCHAR(10)) + '. ' + ProductName
            FROM
            (
                SELECT DISTINCT
                    CONCAT(WD2.ProductName,'-',WD2.Size) AS ProductName,
                    ROW_NUMBER() OVER (ORDER BY WD2.ProductName) AS RN
                FROM tbl_WorkOrderDetails WD2
                INNER JOIN tbl_WorkOrderHdr WH2
                    ON WH2.ID = WD2.HeaderID
                WHERE WH2.Dealer = WH.Dealer
                  AND (ISNULL(@ProductName,'') = ''
                       OR WD2.ProductName = @ProductName)
            ) T
            FOR XML PATH(''), TYPE
        ).value('.', 'nvarchar(max)'),1,2,'') AS ProductName,

        STUFF((
            SELECT DISTINCT ', ' + MM2.MachineName
            FROM tbl_WorkOrderHdr WH2
            INNER JOIN tbl_machineproductionhdr MCH2
                ON MCH2.WorkOrderID = WH2.ID
            INNER JOIN tbl_MachineProductionDTLS MDtls2
                ON MDtls2.HeaderID = MCH2.ID
            INNER JOIN tbl_MachineProductionAllocation MAL2
                ON MAL2.ProductDtlID = MDtls2.ID
            INNER JOIN tbl_MachineMaster MM2
                ON MM2.ID = MAL2.MachineID
            WHERE WH2.Dealer = WH.Dealer
              AND (ISNULL(@MachineName,'') = ''
                   OR MM2.MachineName = @MachineName)
            FOR XML PATH('')
        ),1,2,'') AS MachineName,

        SUM(TRY_CAST(WD.Qty AS INT)) AS TotalQty,
        SUM(TRY_CAST(WD.SqFeet AS DECIMAL)) AS TotalSqFeet,

        CASE WHEN MAX(CAST(WH.IsDesignApproved AS INT)) = 1 THEN '<i style="Color:green">Approved</i>' ELSE '<i style="Color:red">Pending</i>' END AS DesignStatus,
        CASE WHEN MAX(CAST(WH.IsProductionCompleted AS INT)) = 1 THEN '<i style="Color:green">Completed</i>' ELSE '<i style="Color:red">Pending</i>' END AS ProductionStatus,
        CASE WHEN MAX(CAST(WH.IsDispatched AS INT)) = 1 THEN '<i style="Color:green">Dispatched</i>' ELSE '<i style="Color:red">Pending</i>' END AS DispatchStatus,
        CASE WHEN MAX(WH.DeliveryDate) < CAST(GETDATE() AS DATE)
                 AND MAX(CAST(ISNULL(WH.IsProductionCompleted,0) AS INT)) = 0
             THEN '<i style="Color:red">Overdue</i>'
             ELSE '<i style="Color:green">Not Overdue</i>'
        END AS DeliveryStatus

    FROM tbl_WorkOrderHdr WH
    INNER JOIN tbl_WorkOrderDetails WD ON WH.ID = WD.HeaderID
    WHERE WH.IsDeleted = 0
    AND (ISNULL(@ProductName,'') = '' OR WD.ProductName = @ProductName)
    AND (ISNULL(@DealerName,'') = '' OR WH.Dealer LIKE '%' + @DealerName + '%')
    AND (ISNULL(@MachineName,'') = '' OR EXISTS (
            SELECT 1
            FROM tbl_machineproductionhdr MCH3
            INNER JOIN tbl_MachineProductionDTLS MDtls3 ON MDtls3.HeaderID = MCH3.ID
            INNER JOIN tbl_MachineProductionAllocation MAL3 ON MAL3.ProductDtlID = MDtls3.ID
            INNER JOIN tbl_MachineMaster MM3 ON MM3.ID = MAL3.MachineID
            WHERE MCH3.WorkOrderID = WH.ID
              AND MM3.MachineName = @MachineName
        )
    )
    GROUP BY WH.TallyRefNo, WH.Dealer
    HAVING
    (
        ISNULL(@DeliveryStatus,'') = ''
        OR (@DeliveryStatus = 'Overdue'
            AND MAX(WH.DeliveryDate) < CAST(GETDATE() AS DATE)
            AND MAX(CAST(ISNULL(WH.IsProductionCompleted,0) AS INT)) = 0)
        OR (@DeliveryStatus = 'Not Overdue'
            AND (MAX(WH.DeliveryDate) >= CAST(GETDATE() AS DATE)
                 OR MAX(CAST(ISNULL(WH.IsProductionCompleted,0) AS INT)) = 1))
    )
    AND
    (
        ISNULL(@DispatchStatus,'') = ''
        OR (@DispatchStatus = 'Dispatched'
            AND MAX(CAST(WH.IsDispatched AS INT)) = 1)
        OR (@DispatchStatus = 'Pending'
            AND MAX(CAST(WH.IsDispatched AS INT)) = 0)
    )
    ORDER BY WH.Dealer;
   END


   IF @SP_Action ='GetOTmachine'
   BEGIN
--   SELECT 
--    m.ID,
--    m.MachineName,
--    l.MachinePerHRCap AS OldRunningHR,
--    m.MachineRunningHR AS CurrentRunningHR,
--    (TRY_CAST(m.MachineRunningHR AS INT) - TRY_CAST(l.MachinePerHRCap AS INT)) AS ExtraHours,
--    CAST(l.CreatedOn AS DATE) AS ExtraWorkDate
--FROM tbl_MachineMaster m
--INNER JOIN tbl_machinecapacityLog l
--    ON m.ID = l.MachineID 
--WHERE TRY_CAST(m.MachineRunningHR AS INT) > TRY_CAST(l.MachinePerHRCap AS INT);


    ;WITH MachineLog AS
(
    SELECT
        m.ID,
        m.MachineName,
        l.MachinePerHRCap AS OldRunningHR,
        m.MachineRunningHR AS CurrentRunningHR,
        (TRY_CAST(m.MachineRunningHR AS INT) - TRY_CAST(l.MachinePerHRCap AS INT)) AS ExtraHours,
        CAST(l.CreatedOn AS DATE) AS ExtraWorkDate,

        ROW_NUMBER() OVER
        (
            PARTITION BY m.ID
            ORDER BY l.CreatedOn DESC
        ) AS RN

    FROM tbl_MachineMaster m

    INNER JOIN tbl_machinecapacityLog l
        ON m.ID = l.MachineID

    WHERE TRY_CAST(m.MachineRunningHR AS INT) >
          TRY_CAST(l.MachinePerHRCap AS INT)
)

SELECT
    ID,
    MachineName,
    OldRunningHR,
    CurrentRunningHR,
    ExtraHours,
    ExtraWorkDate
FROM MachineLog
WHERE RN = 1;
   END

   IF @SP_Action ='GetTrendingProduct'
   BEGIN
--   WITH StateWiseProduct AS
--(
--    SELECT
--        TU.BillState AS State,
--        D.ProductId,
--        D.ProductName,
--        SUM(TRY_CAST(D.Qty AS DECIMAL(18,2))) AS TotalQty,
--        SUM(TRY_CAST(D.SqFeet AS DECIMAL(18,2))) AS TotalSqFeet,
--        COUNT(DISTINCT D.HeaderID) AS TotalOrders,
--        ROW_NUMBER() OVER
--        (
--            PARTITION BY TU.BillState
--            ORDER BY SUM(TRY_CAST(D.Qty AS DECIMAL(18,2))) DESC
--        ) AS RankNo
--    FROM tbl_WorkOrderHdr H
--    INNER JOIN tbl_WorkOrderDetails D
--        ON H.ID = D.HeaderID
--    INNER JOIN tbl_UserMaster TU
--        ON TU.CompanyName = H.Dealer
--       AND TU.UserRole = 'Dealer'
--    WHERE H.IsDeleted = 0
--    AND (@State IS NULL OR TU.BillState = @State)
--  AND (@ProductName IS NULL OR D.ProductName = @ProductName)
--    GROUP BY
--        TU.BillState,
--        D.ProductId,
--        D.ProductName
--)
--SELECT
--    State,
--    ProductId,
--    ProductName,
--    TotalQty,
--    TotalSqFeet,
--    TotalOrders
--FROM StateWiseProduct
--WHERE RankNo = 1
--ORDER BY State;

SELECT
    TU.BillState AS State,
    SUM(TRY_CAST(D.Qty AS DECIMAL)) AS TotalQty,
    SUM(TRY_CAST(D.SqFeet AS DECIMAL)) AS TotalSqFeet,
    COUNT(DISTINCT D.HeaderID) AS TotalOrders
FROM tbl_WorkOrderHdr H
INNER JOIN tbl_WorkOrderDetails D
    ON H.ID = D.HeaderID
INNER JOIN tbl_UserMaster TU
    ON TU.CompanyName = H.Dealer
   AND TU.UserRole = 'Dealer'
WHERE H.IsDeleted = 0
  AND (@State IS NULL OR TU.BillState = @State)
 AND (@ProductName IS NULL OR D.ProductName = @ProductName)
GROUP BY
    TU.BillState
ORDER BY
    TotalSqFeet DESC;
   END

   IF @SP_Action ='Getrejectionreport'
   BEGIN
   WITH CTE AS
(
    SELECT 
        ProductName,
        Size,
        RevertedFrom,
        WorkOrderNo,
        CreatedDate AS ReturnDate,
        MachineName,
        ROW_NUMBER() OVER 
        (
            PARTITION BY ProductName 
            ORDER BY CreatedDate DESC
        ) AS RN
    FROM [dbo].[tbl_MachineReturnQtyLogs] AS Logs
    INNER JOIN [dbo].[tbl_MachineProductionDTLS] AS DTLS 
        ON Logs.DetailsID = DTLS.ID
    INNER JOIN [dbo].[tbl_MachineProductionHDR] AS HDR 
        ON HDR.ID = DTLS.HeaderID
    INNER JOIN tbl_MachineProductionAllocation AS AlO 
        ON AlO.ProductDtlID = DTLS.ID
    INNER JOIN tbl_MachineMaster AS MAc 
        ON MAc.ID = AlO.MachineID
    INNER JOIN tbl_WorkOrderHdr AS WHDR 
        ON WHDR.TallyRefNo = WorkOrderNo
    WHERE WHDR.IsDeleted = 0
    AND WHDR.HoldStatus = 0
    AND WHDR.CancelStatus = 0
)
SELECT 
    ProductName,
    Size,
    RevertedFrom,
    WorkOrderNo,
    ReturnDate,
    MachineName
FROM CTE
WHERE RN = 1;
   END

END


-- FUNCTIONS
-- Script for FN_GenerateUserCode
GO
CREATE FUNCTION dbo.FN_GenerateUserCode()
RETURNS VARCHAR(20)
AS
BEGIN
    DECLARE @NextNumber INT
    DECLARE @NewCode VARCHAR(20)
    DECLARE @FinancialYear VARCHAR(10)
    DECLARE @StartYear INT
    DECLARE @EndYear INT

    -- ==============================
    -- FINANCIAL YEAR CALCULATION
    -- APRIL TO MARCH
    -- ==============================
    IF MONTH(GETDATE()) >= 4
    BEGIN
        SET @StartYear = YEAR(GETDATE())
        SET @EndYear = YEAR(GETDATE()) + 1
    END
    ELSE
    BEGIN
        SET @StartYear = YEAR(GETDATE()) - 1
        SET @EndYear = YEAR(GETDATE())
    END

    -- FORMAT : 2026-27
    SET @FinancialYear = 
        CAST(@StartYear AS VARCHAR(4)) + '-' + 
        RIGHT(CAST(@EndYear AS VARCHAR(4)), 2)

    -- ==============================
    -- GET MAX RUNNING NUMBER
    -- ==============================
    SELECT 
        @NextNumber = ISNULL(MAX(
            TRY_CAST(RIGHT(UserCode, 3) AS INT)
        ), 0) + 1
    FROM tbl_UserMaster
    WHERE UserCode LIKE 'AL/' + @FinancialYear + '/%'

    -- ==============================
    -- FINAL CODE FORMAT
    -- AL/2026-27/001
    -- ==============================
    SET @NewCode = 
        'AL/' + @FinancialYear + '/' +
        RIGHT('000' + CAST(@NextNumber AS VARCHAR(3)), 3)

    RETURN @NewCode
END


-- Script for FN_CompanyCode
GO

CREATE FUNCTION [dbo].[FN_CompanyCode]()
RETURNS VARCHAR(20)
AS
BEGIN
    DECLARE @NextNumber INT
    DECLARE @NewCode VARCHAR(20)
    DECLARE @FinancialYear VARCHAR(10)
    DECLARE @StartYear INT
    DECLARE @EndYear INT

    -- ==============================
    -- FINANCIAL YEAR CALCULATION
    -- APRIL TO MARCH
    -- ==============================
    IF MONTH(GETDATE()) >= 4
    BEGIN
        SET @StartYear = YEAR(GETDATE())
        SET @EndYear = YEAR(GETDATE()) + 1
    END
    ELSE
    BEGIN
        SET @StartYear = YEAR(GETDATE()) - 1
        SET @EndYear = YEAR(GETDATE())
    END

    -- FORMAT : 2026-27
    SET @FinancialYear = 
        CAST(@StartYear AS VARCHAR(4)) + '-' + 
        RIGHT(CAST(@EndYear AS VARCHAR(4)), 2)

    -- ==============================
    -- GET MAX RUNNING NUMBER
    -- ==============================
    SELECT 
        @NextNumber = ISNULL(MAX(
            TRY_CAST(RIGHT(CompanyCode, 3) AS INT)
        ), 0) + 1
    FROM tbl_CompanyMain
    WHERE CompanyCode LIKE @FinancialYear + '/%'

    -- ==============================
    -- FINAL CODE FORMAT
    -- 2026-27/001
    -- ==============================
    SET @NewCode = 
        @FinancialYear + '/' +
        RIGHT('000' + CAST(@NextNumber AS VARCHAR(3)), 3)

    RETURN @NewCode
END

-- Script for FN_WorkOrderNo
GO
CREATE FUNCTION dbo.FN_WorkOrderNo()
RETURNS VARCHAR(20)
AS
BEGIN
    DECLARE @NextNumber INT
    DECLARE @NewCode VARCHAR(20)
    DECLARE @FinancialYear VARCHAR(10)
    DECLARE @StartYear INT
    DECLARE @EndYear INT

    IF MONTH(GETDATE()) >= 4
    BEGIN
        SET @StartYear = YEAR(GETDATE())
        SET @EndYear = YEAR(GETDATE()) + 1
    END
    ELSE
    BEGIN
        SET @StartYear = YEAR(GETDATE()) - 1
        SET @EndYear = YEAR(GETDATE())
    END

    SET @FinancialYear =
        CAST(@StartYear AS VARCHAR(4))
        + '-'
        + RIGHT(CAST(@EndYear AS VARCHAR(4)), 2)

    SELECT
        @NextNumber = ISNULL(MAX(
            TRY_CAST(RIGHT(SeriesNo, 3) AS INT)
        ), 0) + 1
    FROM tbl_WorkOrderHdr
    WHERE SeriesNo LIKE 'WO/' + @FinancialYear + '/%'

    SET @NewCode =
        'WO/' + @FinancialYear + '/'
        + RIGHT('000' + CAST(@NextNumber AS VARCHAR(3)), 3)

    RETURN @NewCode
END

-- Script for FN_ProductNo
GO
CREATE FUNCTION [dbo].[FN_ProductNo]()
RETURNS VARCHAR(20)
AS
BEGIN
    DECLARE @NextNumber INT;
    DECLARE @NewCode VARCHAR(20);

    SELECT
        @NextNumber = ISNULL(
            MAX(TRY_CAST(RIGHT(ProductCode, 3) AS INT)),
            0
        ) + 1
    FROM [dbo].[tbl_ProdcutMaster]
    WHERE ProductCode LIKE 'P%';

    SET @NewCode =
        'P' + RIGHT('000' + CAST(@NextNumber AS VARCHAR(3)), 3);

    RETURN @NewCode;
END;



-- TRIGGERS

